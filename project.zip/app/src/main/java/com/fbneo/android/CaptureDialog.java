package com.fbneo.android;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.widget.ImageView;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

/** "Press a button on your controller" dialog: reports the first key or axis movement it sees. */
final class CaptureDialog extends Dialog {
    interface Callback {
        void onCaptured(PadMap.Binding b);
        void onClear();
        void onSkip();
    }

    private final Callback cb;
    private float[] baseline;
    private boolean done;

    CaptureDialog(Context c, String title, String hint, boolean showSkip, Callback cb) {
        super(c);
        this.cb = cb;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setCancelable(true);
        LinearLayout l = Ui.vertical(c);
        l.setBackground(Ui.rounded(c, Ui.SURFACE, 28));
        int p = Ui.dp(c, 24);
        l.setPadding(p, p, p, Ui.dp(c, 14));
        l.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView pad = Ui.icon(c, Icons.GAMEPAD, Ui.ACCENT, 40);
        pad.setBackground(Ui.rounded(c, Ui.ACCENT_DIM, 40));
        int ip = Ui.dp(c, 20);
        pad.setPadding(ip, ip, ip, ip);
        pad.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(c, 80), Ui.dp(c, 80)));
        ObjectAnimator pulse = ObjectAnimator.ofFloat(pad, "alpha", 1f, 0.45f);
        pulse.setDuration(700);
        pulse.setRepeatCount(ValueAnimator.INFINITE);
        pulse.setRepeatMode(ValueAnimator.REVERSE);
        pulse.start();
        setOnDismissListener(d -> pulse.cancel());
        l.addView(pad);
        TextView t = Ui.text(c, title, 20, Ui.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(c, 16), 0, 0);
        l.addView(t);
        TextView h = Ui.text(c, hint, 14, Ui.SUB, false);
        h.setGravity(Gravity.CENTER);
        h.setLineSpacing(0, 1.15f);
        h.setPadding(0, Ui.dp(c, 8), 0, Ui.dp(c, 12));
        l.addView(h);
        LinearLayout bar = Ui.horizontal(c);
        bar.setGravity(Gravity.CENTER);
        bar.addView(Ui.button(c, Lang.t("Cancel"), Ui.TEXTONLY, v -> dismiss()));
        if (showSkip) {
            bar.addView(Ui.button(c, Lang.t("Skip"), Ui.TEXTONLY, v -> { done = true; dismiss(); cb.onSkip(); }));
        }
        bar.addView(Ui.button(c, Lang.t("Clear"), Ui.TEXTONLY, v -> { done = true; dismiss(); cb.onClear(); }));
        l.addView(bar);
        setContentView(l);
        Window w = getWindow();
        w.setBackgroundDrawable(new ColorDrawable(0));
        w.setDimAmount(0.7f);
        w.setLayout(Math.min(Dialogs.screenWidth(c) - Ui.dp(c, 32), Ui.dp(c, 400)), ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private void finish(PadMap.Binding b) {
        if (done) return;
        done = true;
        dismiss();
        cb.onCaptured(b);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean pad = (e.getSource() & (InputDevice.SOURCE_GAMEPAD | InputDevice.SOURCE_JOYSTICK)) != 0
                || KeyEvent.isGamepadButton(code);
        if (code == KeyEvent.KEYCODE_BACK && !pad) return super.dispatchKeyEvent(e);
        if (PadInput.ignoredKey(code) && code != KeyEvent.KEYCODE_BACK) return super.dispatchKeyEvent(e);
        if (e.getAction() == KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            finish(PadMap.Binding.key(code));
        }
        return true;
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        if ((ev.getSource() & InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK
                || ev.getAction() != MotionEvent.ACTION_MOVE) {
            return super.dispatchGenericMotionEvent(ev);
        }
        int[] axes = PadInput.TRACKED_AXES;
        if (baseline == null) {
            baseline = new float[axes.length];
            for (int i = 0; i < axes.length; i++) baseline[i] = ev.getAxisValue(axes[i]);
            return true;
        }
        for (int i = 0; i < axes.length; i++) {
            float d = ev.getAxisValue(axes[i]) - baseline[i];
            if (Math.abs(d) > 0.6f) {
                finish(PadMap.Binding.axis(axes[i], d > 0 ? 1 : -1));
                return true;
            }
        }
        return true;
    }
}
