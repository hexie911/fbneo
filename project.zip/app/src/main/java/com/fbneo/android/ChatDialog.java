package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Text chat with the other player while playing together (local or online). */
final class ChatDialog {
    private ChatDialog() {}

    interface Sender { void send(String text); }

    /** The conversation of this session; the game activity feeds it, the dialog shows it. */
    static final class Log {
        static final List<String[]> lines = new ArrayList<>();   // {who, text}  who = "me" or "friend"
        static volatile int unread;
        static volatile Runnable onChange;

        static synchronized void add(boolean mine, String text) {
            lines.add(new String[]{mine ? "me" : "friend", text});
            while (lines.size() > 200) lines.remove(0);
            if (!mine) unread++;
            Runnable r = onChange;
            if (r != null) r.run();
        }

        static synchronized void clear() { lines.clear(); unread = 0; }
    }

    private static Dialog current;

    static boolean isOpen() { return current != null && current.isShowing(); }

    static void show(final Activity a, final Sender sender) {
        if (isOpen()) return;
        final LinearLayout[] h = new LinearLayout[1];
        final Dialog d = Dialogs.base(a, h);
        current = d;
        LinearLayout card = h[0];
        card.addView(Ui.text(a, Lang.t("Chat"), 22, Ui.TEXT, true));
        final LinearLayout list = Ui.vertical(a);
        list.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 4));
        final ScrollView sv = new Dialogs.MaxHeightScroll(a, (int) (Dialogs.screenHeight(a) * 0.38f));
        sv.addView(list);
        card.addView(sv);
        final Runnable fill = new Runnable() {
            @Override public void run() {
                list.removeAllViews();
                synchronized (Log.class) {
                    if (Log.lines.isEmpty()) {
                        TextView t = Ui.text(a, Lang.t("Say something to your friend."), 13, Ui.SUB, false);
                        list.addView(t);
                    }
                    for (String[] l : Log.lines) {
                        boolean me = l[0].equals("me");
                        TextView t = Ui.text(a, (me ? Lang.t("You: ") : Lang.t("Friend: ")) + l[1], 15, me ? Ui.ACCENT : Ui.TEXT, false);
                        t.setPadding(0, Ui.dp(a, 3), 0, Ui.dp(a, 3));
                        t.setTextIsSelectable(true);
                        list.addView(t);
                    }
                    Log.unread = 0;
                }
                sv.post(() -> sv.fullScroll(ScrollView.FOCUS_DOWN));
            }
        };
        fill.run();
        Log.onChange = () -> a.runOnUiThread(fill);
        final EditText in = new EditText(a);
        in.setHint(Lang.t("Type a message"));
        in.setHintTextColor(Ui.SUB);
        in.setTextColor(Ui.TEXT);
        in.setSingleLine(true);
        in.setImeOptions(EditorInfo.IME_ACTION_SEND);
        in.setBackground(Ui.rounded(a, Ui.SURFACE2, 12));
        in.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
        in.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(200)});
        LinearLayout row = Ui.horizontal(a);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(in, new LinearLayout.LayoutParams(0, -2, 1f));
        final Runnable send = () -> {
            String s = in.getText().toString().trim();
            if (s.isEmpty()) return;
            in.setText("");
            Log.add(true, s);
            sender.send(s);
        };
        in.setOnEditorActionListener((v, actionId, ev) -> { send.run(); return true; });
        row.addView(Ui.button(a, Lang.t("Send"), Ui.FILLED, v -> send.run()), Ui.wrapMargins(a, 8, 0, 0, 0));
        card.addView(row, Ui.fillMargins(a, 0, 6, 0, 0));
        card.addView(Ui.button(a, Lang.t("Close"), Ui.TEXTONLY, v -> d.dismiss()), Ui.wrapMargins(a, 0, 6, 0, 0));
        d.setOnDismissListener(x -> { Log.onChange = null; Log.unread = 0; current = null; });
        d.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE | WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        d.show();
        in.requestFocus();
    }
}
