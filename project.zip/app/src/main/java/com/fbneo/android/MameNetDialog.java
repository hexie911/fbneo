package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** Local multiplayer for the MAME player: host (player 1) or join (player 2) over Wi-Fi or a hotspot. */
final class MameNetDialog {
    interface Owner {
        MameNet net();
        void setNet(MameNet n);
    }

    private final Activity a;
    private final Owner owner;
    private final String rom, coreTag;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final NetDiscovery disc;
    private Dialog d;
    private LinearLayout card, hostList;
    private TextView status;
    private EditText ip;
    private String screen = "menu";
    private boolean hotspot;

    static void show(Activity a, Owner o, String rom, String coreTag) { new MameNetDialog(a, o, rom, coreTag).open(); }

    private MameNetDialog(Activity a, Owner o, String rom, String coreTag) {
        this.a = a; this.owner = o; this.rom = rom; this.coreTag = coreTag;
        this.disc = new NetDiscovery(a);
    }

    private void open() {
        LinearLayout[] hold = new LinearLayout[1];
        d = Dialogs.base(a, hold);
        card = hold[0];
        MameNet n = owner.net();
        if (n != null && n.active()) screen = "run";
        else if (n != null && !n.state.equals("error") && !n.state.equals("idle")) screen = n.host ? "host" : "join";
        d.setOnDismissListener(x -> { h.removeCallbacksAndMessages(null); disc.stop(); });
        render();
        d.show();
        h.postDelayed(new Runnable() { @Override public void run() { tick(); h.postDelayed(this, 500); } }, 500);
    }

    private TextView note(String t) {
        TextView x = Ui.text(a, t, 13, Ui.SUB, false);
        x.setLineSpacing(0, 1.15f);
        x.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 8));
        return x;
    }

    private View choice(String head, String sub, View.OnClickListener l) {
        LinearLayout r = Ui.row(a, head, sub, l);
        r.setLayoutParams(Ui.fillMargins(a, 0, 4, 0, 4));
        r.setBackground(Ui.ripple(a, Ui.rounded(a, Ui.SURFACE2, 16), 16));
        return r;
    }

    private void render() {
        card.removeAllViews();
        hostList = null; status = null; ip = null;
        card.addView(Ui.text(a, Lang.t("Local multiplayer"), 22, Ui.TEXT, true));
        MameNet n = owner.net();
        if (screen.equals("menu")) {
            if (n != null && n.state.equals("error")) {
                TextView err = Ui.text(a, n.message, 13, Ui.WARN, true);
                err.setPadding(0, Ui.dp(a, 6), 0, 0);
                card.addView(err);
            }
            card.addView(note(Lang.t("Play ") + rom + Lang.t(" with a friend on the same Wi-Fi or hotspot. Both phones need the same ROM and the same core. ")
                    + Lang.t("The host is player 1. The game restarts for both when you connect.")));
            card.addView(choice(Lang.t("Same Wi-Fi network"), Lang.t("Both phones are on the same Wi-Fi"), v -> { hotspot = false; screen = "method"; render(); }));
            card.addView(choice(Lang.t("Hotspot"), Lang.t("One phone shares its hotspot, the other connects to it"), v -> { hotspot = true; screen = "method"; render(); }));
            card.addView(Ui.button(a, Lang.t("Close"), Ui.TEXTONLY, v -> d.dismiss()), Ui.wrapMargins(a, 0, 6, 0, 0));
        } else if (screen.equals("method")) {
            card.addView(note(hotspot ? Lang.t("The phone that shares the hotspot should host. The other phone joins it.") : Lang.t("Either phone can host. The host is player 1.")));
            final int cur = Prefs.sp(a).getInt("mameNetDelay", 0);
            card.addView(choice(Lang.t("Input delay: ") + (cur == 0 ? Lang.t("Auto") : cur + Lang.t(" frames")), Lang.t("Host decides. Lower feels snappier but needs a good connection"),
                    v -> { Prefs.put(a, "mameNetDelay", cur >= 6 ? 0 : cur + 1); render(); }));
            card.addView(choice(Lang.t("Host"), Lang.t("You are player 1. Your friend joins you"), v -> startHost()));
            card.addView(choice(Lang.t("Join"), Lang.t("You are player 2. Join your friend's game"), v -> { screen = "join"; disc.startListening(); render(); }));
            card.addView(Ui.button(a, Lang.t("Back"), Ui.TEXTONLY, v -> { screen = "menu"; render(); }), Ui.wrapMargins(a, 0, 6, 0, 0));
        } else if (screen.equals("host")) {
            if (hotspot) {
                card.addView(note(Lang.t("1. Turn on your phone's hotspot.\n2. Your friend connects their phone to it.\n3. Your friend opens this menu, taps Hotspot, then Join.")));
                card.addView(Ui.button(a, Lang.t("Open hotspot settings"), Ui.TONAL, v -> openSettings(true)), Ui.fillMargins(a, 0, 4, 4, 4));
            } else {
                card.addView(note(Lang.t("Your friend opens this menu on their phone and taps Join. They should see your phone in the list.")));
            }
            StringBuilder sb = new StringBuilder(Lang.t("Your address:"));
            List<String> ips = NetDiscovery.localAddresses();
            if (ips.isEmpty()) sb.append(" none found, connect to Wi-Fi or turn on the hotspot");
            for (String s : ips) sb.append("\n").append(s);
            TextView t = Ui.text(a, sb.toString(), 13, Ui.TEXT, false);
            t.setTextIsSelectable(true);
            card.addView(t);
            status = Ui.text(a, "", 14, Ui.ACCENT, true);
            status.setPadding(0, Ui.dp(a, 8), 0, 0);
            card.addView(status);
            card.addView(Ui.button(a, Lang.t("Cancel"), Ui.TEXTONLY, v -> cancel()), Ui.wrapMargins(a, 0, 8, 0, 0));
        } else if (screen.equals("join")) {
            if (hotspot) {
                card.addView(note(Lang.t("First connect this phone to your friend's hotspot in Wi-Fi settings, then come back here.")));
                card.addView(Ui.button(a, Lang.t("Open Wi-Fi settings"), Ui.TONAL, v -> openSettings(false)), Ui.fillMargins(a, 0, 4, 0, 4));
            }
            card.addView(Ui.text(a, Lang.t("Games found nearby"), 13, Ui.SUB, true), Ui.fillMargins(a, 0, 8, 0, 0));
            hostList = Ui.vertical(a);
            card.addView(hostList);
            card.addView(Ui.text(a, Lang.t("Or type the host's address"), 13, Ui.SUB, true), Ui.fillMargins(a, 0, 10, 0, 0));
            ip = new EditText(a);
            ip.setSingleLine(true);
            ip.setHint(Lang.t("for example 192.168.1.20"));
            ip.setTextColor(Ui.TEXT);
            ip.setHintTextColor(Ui.SUB);
            ip.setInputType(InputType.TYPE_CLASS_PHONE);
            ip.setBackground(Ui.rounded(a, Ui.SURFACE2, 12));
            ip.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
            String gw = NetDiscovery.gateway(a);
            String last = Prefs.sp(a).getString("mameNetIp", "");
            ip.setText(hotspot && gw.length() > 0 ? gw : (last.length() > 0 ? last : gw));
            card.addView(ip, Ui.fillMargins(a, 0, 4, 0, 4));
            LinearLayout bar = Ui.horizontal(a);
            bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            bar.addView(Ui.button(a, Lang.t("Cancel"), Ui.TEXTONLY, v -> cancel()));
            bar.addView(Ui.button(a, Lang.t("Join"), Ui.FILLED, v -> join(ip.getText().toString().trim())), Ui.wrapMargins(a, 8, 0, 0, 0));
            card.addView(bar, Ui.fillMargins(a, 0, 6, 0, 0));
            status = Ui.text(a, "", 14, Ui.ACCENT, true);
            card.addView(status);
        } else {
            card.addView(note(Lang.t("You are player ") + (n != null && n.host ? Lang.t("1 (host)") : "2") + Lang.t(". Input delay ") + (n == null ? 0 : n.delay)
                    + Lang.t(" frames. Quitting the game on one phone ends the session. Save states, reset and pause are off while connected.")));
            status = Ui.text(a, "", 14, Ui.OK, true);
            card.addView(status);
            LinearLayout bar = Ui.horizontal(a);
            bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            bar.addView(Ui.button(a, Lang.t("Close"), Ui.TEXTONLY, v -> d.dismiss()));
            TextView stop = Ui.button(a, Lang.t("Disconnect"), Ui.TONAL, v -> cancel());
            stop.setTextColor(Ui.DANGER);
            bar.addView(stop, Ui.wrapMargins(a, 8, 0, 0, 0));
            card.addView(bar, Ui.fillMargins(a, 0, 8, 0, 0));
        }
    }

    private void openSettings(boolean hotspotPage) {
        android.content.Intent i = new android.content.Intent(hotspotPage ? "android.settings.TETHER_SETTINGS" : android.provider.Settings.ACTION_WIFI_SETTINGS);
        try {
            a.startActivity(i);
        } catch (Exception e) {
            try { a.startActivity(new android.content.Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS)); }
            catch (Exception e2) { Ui.toast(a, Lang.t("Open Settings yourself")); }
        }
    }

    private void startHost() {
        MameNet n = new MameNet(rom, coreTag, Prefs.sp(a).getInt("mameNetDelay", 0));
        owner.setNet(n);
        n.startHost();
        disc.startHosting("mame:" + rom);
        screen = "host";
        render();
    }

    private void join(String addr) {
        if (addr.length() == 0) { Ui.toast(a, Lang.t("Enter the host's address")); return; }
        Prefs.put(a, "mameNetIp", addr);
        MameNet n = new MameNet(rom, coreTag, Prefs.sp(a).getInt("mameNetDelay", 0));
        owner.setNet(n);
        n.startJoin(addr);
    }

    private void cancel() {
        MameNet n = owner.net();
        if (n != null) n.stop();
        owner.setNet(null);
        disc.stop();
        screen = "menu";
        render();
    }

    private void tick() {
        MameNet n = owner.net();
        if (n != null && n.state.equals("error") && !screen.equals("menu")) {
            disc.stop();
            screen = "menu";
            render();
            return;
        }
        if (n != null && n.active() && !screen.equals("run")) { disc.stop(); screen = "run"; render(); return; }
        if (status != null && n != null) status.setText(n.active() ? (n.desync ? Lang.t("Out of sync, restart the game on both") : Lang.t("Connected")) : n.message);
        if (hostList != null) {
            hostList.removeAllViews();
            boolean any = false;
            for (NetDiscovery.Host x : disc.found()) {
                if (!x.game.startsWith("mame:")) continue;
                any = true;
                boolean same = x.game.equals("mame:" + rom);
                hostList.addView(choice(x.ip, same ? Lang.t("Playing ") + rom + Lang.t(". Tap to join") : Lang.t("Plays ") + x.game.substring(5) + Lang.t(", you are on ") + rom,
                        v -> { if (ip != null) ip.setText(x.ip); join(x.ip); }));
            }
            if (!any) hostList.addView(note(Lang.t("Looking... Ask your friend to start hosting.")));
        }
    }
}
