package com.fbneo.android;

import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Turns Android key / motion events into actions using a PadMap. UI thread only. */
final class PadInput {
    interface Sink {
        void onAction(int slot, int action, boolean down);
    }

    static final int[] TRACKED_AXES = {
            MotionEvent.AXIS_X, MotionEvent.AXIS_Y, MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ,
            MotionEvent.AXIS_RX, MotionEvent.AXIS_RY, MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y,
            MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER, MotionEvent.AXIS_BRAKE, MotionEvent.AXIS_GAS,
            MotionEvent.AXIS_THROTTLE, MotionEvent.AXIS_RUDDER
    };

    private static final float THRESHOLD = 0.5f;      // triggers and other single axes

    // Stick feel: a direction turns on above STICK_ON and off below STICK_OFF (so it doesn't flicker).
    // Lower values make the diagonals wider, which is what quarter and half circles need.
    private static float stickOn = 0.38f, stickOff = 0.30f;

    static void configure(android.content.Context c) {
        switch (Prefs.stickFeel(c)) {
            case 0: stickOn = 0.50f; stickOff = 0.45f; break;
            case 2: stickOn = 0.30f; stickOff = 0.22f; break;
            default: stickOn = 0.38f; stickOff = 0.30f; break;
        }
    }

    /** The other axis of the same stick (X/Y, Z/RZ, RX/RY), or -1 for hats and triggers. */
    private static int partner(int axis) {
        switch (axis) {
            case MotionEvent.AXIS_X: return MotionEvent.AXIS_Y;
            case MotionEvent.AXIS_Y: return MotionEvent.AXIS_X;
            case MotionEvent.AXIS_Z: return MotionEvent.AXIS_RZ;
            case MotionEvent.AXIS_RZ: return MotionEvent.AXIS_Z;
            case MotionEvent.AXIS_RX: return MotionEvent.AXIS_RY;
            case MotionEvent.AXIS_RY: return MotionEvent.AXIS_RX;
            default: return -1;
        }
    }
    private static final int PAD_SOURCES = InputDevice.SOURCE_GAMEPAD | InputDevice.SOURCE_JOYSTICK | InputDevice.SOURCE_DPAD;

    private final Sink sink;
    private final PadMap[] maps = new PadMap[2];
    private final Map<Integer, Integer> slotByDevice = new HashMap<>();
    @SuppressWarnings("unchecked")
    private final Set<Integer>[] held = new Set[]{new HashSet<Integer>(), new HashSet<Integer>()};
    private final float[][] axes = new float[2][64];
    private final boolean[][] pushed = new boolean[2][Actions.COUNT];
    private final boolean[][] axisOn = new boolean[2][128];

    PadInput(PadMap map1, PadMap map2, Sink sink) {
        this.maps[0] = map1;
        this.maps[1] = map2;
        this.sink = sink;
    }

    void setMaps(PadMap m1, PadMap m2) {
        maps[0] = m1;
        maps[1] = m2;
        recompute(0);
        recompute(1);
    }

    static boolean ignoredKey(int code) {
        return code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN
                || code == KeyEvent.KEYCODE_VOLUME_MUTE || code == KeyEvent.KEYCODE_POWER
                || code == KeyEvent.KEYCODE_CAMERA || code == KeyEvent.KEYCODE_HOME
                || code == KeyEvent.KEYCODE_APP_SWITCH || code == KeyEvent.KEYCODE_BACK;
    }

    private int slotFor(int deviceId, boolean pad) {
        if (!pad) return 0;
        Integer s = slotByDevice.get(deviceId);
        if (s != null) return s;
        // forget devices that went away so a reconnected pad gets its old slot back
        Set<Integer> used = new HashSet<>();
        for (Map.Entry<Integer, Integer> e : new HashMap<>(slotByDevice).entrySet()) {
            if (InputDevice.getDevice(e.getKey()) == null) slotByDevice.remove(e.getKey());
            else used.add(e.getValue());
        }
        int slot = !used.contains(0) ? 0 : 1;
        slotByDevice.put(deviceId, slot);
        return slot;
    }

    /** @return true when the event was used and must not reach SDL. */
    boolean onKey(KeyEvent e) {
        int code = e.getKeyCode();
        if (ignoredKey(code)) return false;
        boolean pad = (e.getSource() & PAD_SOURCES) != 0 || KeyEvent.isGamepadButton(code);
        if (!pad && !isBound(code)) return false;
        int slot = slotFor(e.getDeviceId(), pad);
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() == 0) held[slot].add(code);
        } else if (e.getAction() == KeyEvent.ACTION_UP) {
            held[slot].remove(code);
        } else {
            return true;
        }
        recompute(slot);
        return true;
    }

    boolean onMotion(MotionEvent e) {
        if ((e.getSource() & InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) return false;
        if (e.getAction() != MotionEvent.ACTION_MOVE) return false;
        int slot = slotFor(e.getDeviceId(), true);
        for (int a : TRACKED_AXES) axes[slot][a] = e.getAxisValue(a);
        recompute(slot);
        return true;
    }

    private boolean isBound(int code) {
        for (int a = 0; a < Actions.COUNT; a++)
            for (PadMap.Binding b : maps[0].get(a))
                if (!b.axis && b.code == code) return true;
        return false;
    }

    private void recompute(int slot) {
        for (int a = 0; a < Actions.COUNT; a++) {
            boolean p = false;
            List<PadMap.Binding> l = maps[slot].get(a);
            for (int i = 0; i < l.size() && !p; i++) {
                PadMap.Binding b = l.get(i);
                if (!b.axis) p = held[slot].contains(b.code);
                else {
                    float v = b.dir > 0 ? axes[slot][b.code] : -axes[slot][b.code];
                    if (partner(b.code) >= 0 && b.code < 64) {
                        int idx = b.code * 2 + (b.dir > 0 ? 1 : 0);
                        p = v >= (axisOn[slot][idx] ? stickOff : stickOn);
                        axisOn[slot][idx] = p;
                    } else {
                        p = v > THRESHOLD;
                    }
                }
            }
            if (p != pushed[slot][a]) {
                pushed[slot][a] = p;
                sink.onAction(slot, a, p);
            }
        }
    }

    void releaseAll() {
        for (int s = 0; s < 2; s++) {
            held[s].clear();
            java.util.Arrays.fill(axes[s], 0f);
            java.util.Arrays.fill(axisOn[s], false);
            recompute(s);
        }
    }
}
