package com.fbneo.android;

import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Turns Android key / motion events into actions using a PadMap. UI thread only. */
final class PadInput {
    interface Sink {
        void onAction(int slot, int action, boolean down);
    }

    static final int[] TRACKED_AXES = {
            MotionEvent.AXIS_X, MotionEvent.AXIS_Y, MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ,
            MotionEvent.AXIS_RX, MotionEvent.AXIS_RY, MotionEvent.AXIS_HAT_X, MotionEvent.AXIS_HAT_Y,
            MotionEvent.AXIS_LTRIGGER, MotionEvent.AXIS_RTRIGGER, MotionEvent.AXIS_BRAKE, MotionEvent.AXIS_GAS,
            MotionEvent.AXIS_THROTTLE, MotionEvent.AXIS_RUDDER
    };

    private static final float THRESHOLD = 0.5f;      // triggers and other single axes

    // Stick feel: a direction turns on above STICK_ON and off below STICK_OFF (so it doesn't flicker).
    // Lower values make the diagonals wider, which is what quarter and half circles need.
    private static float stickOn = 0.38f, stickOff = 0.30f;

    static void configure(android.content.Context c) {
        switch (Prefs.stickFeel(c)) {
            case 0: stickOn = 0.50f; stickOff = 0.42f; break;
            case 2: stickOn = 0.32f; stickOff = 0.24f; break;
            default: stickOn = 0.40f; stickOff = 0.32f; break;
        }
        configureDiag(Prefs.stickFeel(c));
    }

    /** The other axis of the same stick (X/Y, Z/RZ, RX/RY), or -1 for hats and triggers. */
    private static int partner(int axis) {
        switch (axis) {
            case MotionEvent.AXIS_X: return MotionEvent.AXIS_Y;
            case MotionEvent.AXIS_Y: return MotionEvent.AXIS_X;
            case MotionEvent.AXIS_Z: return MotionEvent.AXIS_RZ;
            case MotionEvent.AXIS_RZ: return MotionEvent.AXIS_Z;
            case MotionEvent.AXIS_RX: return MotionEvent.AXIS_RY;
            case MotionEvent.AXIS_RY: return MotionEvent.AXIS_RX;
            default: return -1;
        }
    }
    private static final int PAD_SOURCES = InputDevice.SOURCE_GAMEPAD | InputDevice.SOURCE_JOYSTICK | InputDevice.SOURCE_DPAD;

    private final Sink sink;
    private final PadMap[] maps = new PadMap[2];
    private final Map<Integer, Integer> slotByDevice = new HashMap<>();
    @SuppressWarnings("unchecked")
    private final Set<Integer>[] held = new Set[]{new HashSet<Integer>(), new HashSet<Integer>()};
    private final float[][] axes = new float[2][64];
    private final boolean[][] pushed = new boolean[2][Actions.COUNT];

    PadInput(PadMap map1, PadMap map2, Sink sink) {
        this.maps[0] = map1;
        this.maps[1] = map2;
        this.sink = sink;
    }

    void setMaps(PadMap m1, PadMap m2) {
        maps[0] = m1;
        maps[1] = m2;
        recompute(0);
        recompute(1);
    }

    static boolean ignoredKey(int code) {
        return code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN
                || code == KeyEvent.KEYCODE_VOLUME_MUTE || code == KeyEvent.KEYCODE_POWER
                || code == KeyEvent.KEYCODE_CAMERA || code == KeyEvent.KEYCODE_HOME
                || code == KeyEvent.KEYCODE_APP_SWITCH || code == KeyEvent.KEYCODE_BACK;
    }

    private int slotFor(int deviceId, boolean pad) {
        if (!pad) return 0;
        Integer s = slotByDevice.get(deviceId);
        if (s != null) return s;
        // forget devices that went away so a reconnected pad gets its old slot back
        Set<Integer> used = new HashSet<>();
        for (Map.Entry<Integer, Integer> e : new HashMap<>(slotByDevice).entrySet()) {
            if (InputDevice.getDevice(e.getKey()) == null) slotByDevice.remove(e.getKey());
            else used.add(e.getValue());
        }
        int slot = !used.contains(0) ? 0 : 1;
        slotByDevice.put(deviceId, slot);
        return slot;
    }

    /** @return true when the event was used and must not reach SDL. */
    boolean onKey(KeyEvent e) {
        int code = e.getKeyCode();
        if (ignoredKey(code)) return false;
        boolean pad = (e.getSource() & PAD_SOURCES) != 0 || KeyEvent.isGamepadButton(code);
        if (!pad && !isBound(code)) return false;
        int slot = slotFor(e.getDeviceId(), pad);
        if (e.getAction() == KeyEvent.ACTION_DOWN) {
            if (e.getRepeatCount() == 0) held[slot].add(code);
        } else if (e.getAction() == KeyEvent.ACTION_UP) {
            held[slot].remove(code);
        } else {
            return true;
        }
        recompute(slot);
        return true;
    }

    boolean onMotion(MotionEvent e) {
        if ((e.getSource() & InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK) return false;
        if (e.getAction() != MotionEvent.ACTION_MOVE) return false;
        int slot = slotFor(e.getDeviceId(), true);
        for (int a : TRACKED_AXES) axes[slot][a] = e.getAxisValue(a);
        recompute(slot);
        return true;
    }

    private boolean isBound(int code) {
        for (int a = 0; a < Actions.COUNT; a++)
            for (PadMap.Binding b : maps[0].get(a))
                if (!b.axis && b.code == code) return true;
        for (PadMap.Macro m : maps[0].macros)
            for (PadMap.Binding b : m.binds)
                if (!b.axis && b.code == code) return true;
        return false;
    }

    // Sticks: the two axes of a stick are read together as one direction (angle), not as two separate switches.
    // That keeps straight directions clean, makes diagonals the same on every stick, and means a binding
    // such as "Up = left stick up" can never fire from a sideways push.
    private static final int[][] PAIRS = {
            {MotionEvent.AXIS_X, MotionEvent.AXIS_Y},
            {MotionEvent.AXIS_Z, MotionEvent.AXIS_RZ},
            {MotionEvent.AXIS_RX, MotionEvent.AXIS_RY}};
    private static final int L = 1, R = 2, U = 4, D = 8;
    private final boolean[][] stickActive = new boolean[2][3];
    private final int[][] stickDirs = new int[2][3];

    private static float diagStart = 22.5f;

    static void configureDiag(int feel) {
        diagStart = feel == 0 ? 29f : feel == 2 ? 17f : 22.5f;
    }

    private void updateSticks(int slot) {
        for (int p = 0; p < PAIRS.length; p++) {
            float x = axes[slot][PAIRS[p][0]], y = axes[slot][PAIRS[p][1]];
            float len = (float) Math.hypot(x, y);
            boolean on = len >= (stickActive[slot][p] ? stickOff : stickOn);
            stickActive[slot][p] = on;
            int m = 0;
            if (on) {
                double ang = Math.toDegrees(Math.atan2(-y, x));      // 0 = right, 90 = up
                double ax = Math.abs(ang);
                if (ax < 90 - diagStart) m |= R;
                if (ax > 90 + diagStart) m |= L;
                if (ang > diagStart && ang < 180 - diagStart) m |= U;
                if (ang < -diagStart && ang > -180 + diagStart) m |= D;
            }
            stickDirs[slot][p] = m;
        }
    }

    private static int pairOf(int axis) {
        for (int p = 0; p < PAIRS.length; p++) if (PAIRS[p][0] == axis || PAIRS[p][1] == axis) return p;
        return -1;
    }

    /** D-pad: the same whether the pad sends key presses or a hat axis. */
    private boolean dpad(int slot, int dir) {
        switch (dir) {
            case L: return held[slot].contains(KeyEvent.KEYCODE_DPAD_LEFT) || axes[slot][MotionEvent.AXIS_HAT_X] < -THRESHOLD;
            case R: return held[slot].contains(KeyEvent.KEYCODE_DPAD_RIGHT) || axes[slot][MotionEvent.AXIS_HAT_X] > THRESHOLD;
            case U: return held[slot].contains(KeyEvent.KEYCODE_DPAD_UP) || axes[slot][MotionEvent.AXIS_HAT_Y] < -THRESHOLD;
            default: return held[slot].contains(KeyEvent.KEYCODE_DPAD_DOWN) || axes[slot][MotionEvent.AXIS_HAT_Y] > THRESHOLD;
        }
    }

    private boolean bindingDown(int slot, PadMap.Binding b) {
        if (!b.axis) {
            switch (b.code) {
                case KeyEvent.KEYCODE_DPAD_LEFT: return dpad(slot, L);
                case KeyEvent.KEYCODE_DPAD_RIGHT: return dpad(slot, R);
                case KeyEvent.KEYCODE_DPAD_UP: return dpad(slot, U);
                case KeyEvent.KEYCODE_DPAD_DOWN: return dpad(slot, D);
                default: return held[slot].contains(b.code);
            }
        }
        if (b.code == MotionEvent.AXIS_HAT_X) return dpad(slot, b.dir > 0 ? R : L);
        if (b.code == MotionEvent.AXIS_HAT_Y) return dpad(slot, b.dir > 0 ? D : U);
        int p = pairOf(b.code);
        if (p >= 0) {
            boolean xLike = PAIRS[p][0] == b.code;
            int bit = xLike ? (b.dir > 0 ? R : L) : (b.dir > 0 ? D : U);
            return (stickDirs[slot][p] & bit) != 0;
        }
        float v = b.dir > 0 ? axes[slot][b.code] : -axes[slot][b.code];
        return v > THRESHOLD;
    }

    private void recompute(int slot) {
        updateSticks(slot);
        // macros first: every action a pressed macro contains counts as pressed
        boolean[] viaMacro = new boolean[Actions.COUNT];
        for (PadMap.Macro m : maps[slot].macros) {
            boolean down = false;
            for (int i = 0; i < m.binds.size() && !down; i++) down = bindingDown(slot, m.binds.get(i));
            if (down) for (int act : m.actions) if (act >= 0 && act < Actions.COUNT) viaMacro[act] = true;
        }
        for (int a = 0; a < Actions.COUNT; a++) {
            boolean p = viaMacro[a];
            List<PadMap.Binding> l = maps[slot].get(a);
            for (int i = 0; i < l.size() && !p; i++) p = bindingDown(slot, l.get(i));
            if (p != pushed[slot][a]) {
                pushed[slot][a] = p;
                sink.onAction(slot, a, p);
            }
        }
    }

    void releaseAll() {
        for (int s = 0; s < 2; s++) {
            held[s].clear();
            java.util.Arrays.fill(axes[s], 0f);
            java.util.Arrays.fill(stickActive[s], false);
            recompute(s);
        }
    }
}
