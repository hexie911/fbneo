package com.fbneo.android;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns the emulator log of the last run into a short, human readable list of problems. */
final class LogReport {
    private LogReport() {}

    static final class Result {
        String title = "";
        final List<String> lines = new ArrayList<>();
        boolean any() { return lines.size() > 0; }
    }

    private static final Pattern LUA_ERR = Pattern.compile("Lua thread bombed out: (.*)");
    private static final Pattern MODULE = Pattern.compile("module '([^']+)' not found");
    private static final Pattern ROM_MISSING = Pattern.compile("^\\s*(?:Loading\\s+\\w+\\s+)?\\(?([\\w\\-.]+)\\)?.*\\(not found\\)", Pattern.CASE_INSENSITIVE);
    private static final Pattern BIOS_MISSING = Pattern.compile("BIOS\\s+(\\S+)\\s+\\(not found\\)");

    static Result analyse(String log) {
        Result r = new Result();
        if (log == null || log.length() == 0) return r;
        String[] lines = log.split("\n");
        boolean luaFail = false;
        List<String> missingRoms = new ArrayList<>();
        for (String line : lines) {
            Matcher m = LUA_ERR.matcher(line);
            if (m.find()) {
                luaFail = true;
                String msg = m.group(1);
                Matcher mm = MODULE.matcher(msg);
                if (mm.find()) {
                    r.lines.add(Lang.t("The Lua script needs a file it can't find: ") + mm.group(1).replace('/', '/') + ".lua");
                    r.lines.add(Lang.t("Copy the whole script folder (src, data, images …) and run the .lua from inside it. ")
                            + Lang.t("For 3rd Strike training mode, use \"Download training mode\" in the game's Lua list."));
                } else {
                    r.lines.add(Lang.t("Lua error: ") + msg.trim());
                }
                continue;
            }
            Matcher b = BIOS_MISSING.matcher(line);
            if (b.find()) {
                if (!missingRoms.contains(b.group(1))) missingRoms.add(b.group(1));
                continue;
            }
            if (line.contains("(not found)")) {
                Matcher n = ROM_MISSING.matcher(line);
                String nm = n.find() ? n.group(1) : line.trim();
                if (!missingRoms.contains(nm)) missingRoms.add(nm);
            }
        }
        if (!missingRoms.isEmpty()) {
            StringBuilder sb = new StringBuilder(Lang.t("Missing ROM files: "));
            for (int i = 0; i < missingRoms.size() && i < 6; i++) {
                if (i > 0) sb.append(", ");
                sb.append(missingRoms.get(i));
            }
            r.lines.add(sb.toString());
            r.lines.add(Lang.t("Check that the right ROM set (and its parent / BIOS zip) is in your ROM folder."));
        }
        r.title = luaFail ? Lang.t("Lua script problem") : Lang.t("Game problem");
        return r;
    }
}
