package com.fbneo.android;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Main screen: your game library. Tap a game to pick a Lua script and play. */
public class LauncherActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Lang.wrap(base));
    }

    static final int REQ_SCRIPT = 10, REQ_ROMDIR = 11, REQ_COVER = 12;
    /** Games of the last scan, {rom, title, main}: used by the cover downloader. */
    static volatile List<String[]> coverList = new ArrayList<>();

    static final class Rom {
        String name, title, main, detail = "", year = "", maker = "", initials = "";
        boolean bios, known, neo;
        int c1, c2;
    }

    private final List<Rom> all = new ArrayList<>();
    private final List<Rom> shown = new ArrayList<>();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private BaseAdapter adapter;
    private GridView grid;
    private boolean stripMode;
    private TextView layoutBtn;
    private final int builtTheme = Ui.themeVersion;
    private View searchBar;
    private EditText searchField;
    private EditText search;
    private TextView subtitle;
    private View banner, hero, empty;
    private TextView emptyText;
    private int colW, cols = 2;
    private String lastSignature = "";
    private boolean scanning;
    private long launchedAt;
    private Rom pendingRom;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.migrateLayout(this);
        stripMode = Prefs.sp(this).getBoolean("stripView", false);
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);

        final boolean land = getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels;
        final LinearLayout hdr = Ui.vertical(this);
        root.addView(hdr);
        // header
        LinearLayout top = Ui.horizontal(this);
        top.setPadding(Ui.dp(this, 16), Ui.dp(this, land ? 4 : 12), Ui.dp(this, 10), Ui.dp(this, 2));
        LinearLayout titles = Ui.vertical(this);
        titles.addView(Ui.text(this, "FBNeo", land ? 20 : 24, Ui.TEXT, true));
        subtitle = Ui.text(this, "", 12, Ui.SUB, false);
        subtitle.setSingleLine(true);
        subtitle.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        subtitle.setPadding(0, Ui.dp(this, 1), 0, 0);
        titles.addView(subtitle);
        top.addView(titles, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        View more = Ui.iconButton(this, Icons.MORE, Lang.t("Menu"), v -> openSide());
        ((LinearLayout.LayoutParams) more.getLayoutParams()).leftMargin = Ui.dp(this, 8);
        top.addView(more);
        hdr.addView(top);

        // storage permission banner
        LinearLayout bn = Ui.horizontal(this);
        bn.setBackground(Ui.rounded(this, Ui.WARN_DIM, 16));
        bn.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
        TextView bt = Ui.text(this, Lang.t("Allow \"All files access\" so FBNeo can read your ROMs and Lua scripts."), 13, Ui.TEXT, false);
        bt.setLineSpacing(0, 1.1f);
        bn.addView(bt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bn.addView(Ui.button(this, Lang.t("Allow"), Ui.FILLED, v -> Prefs.requestAccess(this)), Ui.wrapMargins(this, 10, 0, 0, 0));
        banner = bn;
        hdr.addView(bn, Ui.fillMargins(this, 14, 2, 14, 4));

        // search
        LinearLayout sb = Ui.horizontal(this);
        sb.setBackground(Ui.rounded(this, Ui.SURFACE, 20));
        sb.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), 0);
        sb.addView(Ui.icon(this, Icons.SEARCH, Ui.SUB, 20));
        search = new EditText(this);
        searchField = search;
        searchBar = sb;
        sb.setVisibility(View.GONE);
        search.setHint(Lang.t("Search games"));
        search.setHintTextColor(Ui.SUB);
        search.setTextColor(Ui.TEXT);
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setBackground(null);
        search.setPadding(Ui.dp(this, 12), 0, 0, 0);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) {}
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) { applyFilter(); }
            @Override public void afterTextChanged(Editable s) {}
        });
        sb.addView(search, new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f));
        hdr.addView(sb, Ui.fillMargins(this, 14, 2, 14, 4));
        View sbtn = Ui.glyphButton(this, "\uD83D\uDD0D", Lang.t("Search games"), v -> toggleSearch());
        ((LinearLayout.LayoutParams) sbtn.getLayoutParams()).leftMargin = Ui.dp(this, 8);
        top.addView(sbtn, 1);
        layoutBtn = Ui.glyphButton(this, stripMode ? "\u25A6" : "\u2630", Lang.t("Change how games look"), v -> {
            stripMode = !stripMode;
            Prefs.put(this, "stripView", stripMode);
            layoutBtn.setText(stripMode ? "\u25A6" : "\u2630");
            computeColumns();
            grid.setAdapter(adapter);
        });
        ((LinearLayout.LayoutParams) layoutBtn.getLayoutParams()).leftMargin = Ui.dp(this, 8);
        top.addView(layoutBtn, 1);

        // continue card
        hero = buildHeroShell();
        hdr.addView(hero, Ui.fillMargins(this, 14, 2, 14, 4));
        hero.setVisibility(View.GONE);

        // grid + empty state
        FrameLayout body = new FrameLayout(this);
        grid = new GridView(this);
        grid.setSelector(Ui.focusRing(this, 16));
        grid.setFocusable(true);
        grid.setClipToPadding(false);
        grid.setPadding(Ui.dp(this, 12), Ui.dp(this, 4), Ui.dp(this, 12), Ui.dp(this, 24));
        grid.setVerticalSpacing(Ui.dp(this, 12));
        grid.setHorizontalSpacing(Ui.dp(this, 12));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        grid.setVerticalScrollBarEnabled(false);
        adapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public int getViewTypeCount() { return 2; }
            @Override public int getItemViewType(int i) { return stripMode ? 1 : 0; }
            @Override public View getView(int i, View v, ViewGroup p) { return stripMode ? strip(shown.get(i), v) : tile(shown.get(i), v); }
        };
        grid.setAdapter(adapter);
        if (land) grid.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView v, int st) { }
            @Override public void onScroll(AbsListView v, int first, int vis, int total) {
                int want = first >= 1 ? View.GONE : View.VISIBLE;
                if (hdr.getVisibility() != want && !(want == View.VISIBLE && v.getChildCount() > 0 && v.getChildAt(0).getTop() < 0)) hdr.setVisibility(want);
            }
        });
        grid.setOnItemClickListener((parent, view, pos, id) -> showSheet(shown.get(pos)));
        body.addView(grid, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        empty = buildEmpty();
        body.addView(empty, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        empty.setVisibility(View.GONE);
        root.addView(body, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        computeColumns();
        grid.requestFocus();
    }


    private void toggleSearch() {
        boolean show = searchBar.getVisibility() != View.VISIBLE;
        searchBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            searchField.requestFocus();
            android.view.inputmethod.InputMethodManager im = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (im != null) im.showSoftInput(searchField, 0);
        } else {
            searchField.setText("");
            android.view.inputmethod.InputMethodManager im = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (im != null) im.hideSoftInputFromWindow(searchField.getWindowToken(), 0);
            grid.requestFocus();
        }
    }

    @Override public boolean dispatchKeyEvent(android.view.KeyEvent e) {
        android.view.KeyEvent m = Ui.padKey(e);
        if (m != null && !(searchField.hasFocus() && e.getKeyCode() == android.view.KeyEvent.KEYCODE_BUTTON_B && false)) return super.dispatchKeyEvent(m);
        if (e.getAction() == android.view.KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            int k = e.getKeyCode();
            if (k == android.view.KeyEvent.KEYCODE_BUTTON_Y) { toggleSearch(); return true; }
            if (k == android.view.KeyEvent.KEYCODE_BUTTON_START || k == android.view.KeyEvent.KEYCODE_BUTTON_SELECT) { openSide(); return true; }
        }
        return super.dispatchKeyEvent(e);
    }

    private void openSide() {
        SideMenu.show(this, SideMenu.FBNEO,
                new String[]{Lang.t("Controls"), Lang.t("Settings")},
                new Runnable[]{() -> startActivity(new Intent(this, MappingActivity.class)), () -> startActivity(new Intent(this, SettingsActivity.class))},
                subtitle.getText().toString());
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        computeColumns();
        adapter.notifyDataSetChanged();
    }

    private void computeColumns() {
        int widthPx = getResources().getDisplayMetrics().widthPixels;
        boolean ls = widthPx > getResources().getDisplayMetrics().heightPixels;
        cols = stripMode ? (ls ? 2 : 1) : Math.max(2, widthPx / Ui.dp(this, ls ? 112 : 140));
        int pad = Ui.dp(this, 12) * 2;
        int gap = Ui.dp(this, 12) * (cols - 1);
        colW = (widthPx - pad - gap) / cols;
        grid.setNumColumns(cols);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (builtTheme != Ui.themeVersion) { recreate(); return; }
        Prefs.migrateLayout(this);
        banner.setVisibility(Prefs.hasAccess(this) ? View.GONE : View.VISIBLE);
        scan(false);
        if (launchedAt != 0) {
            launchedAt = 0;
            LogReport.Result r = LogReport.analyse(Prefs.logTail(this, 120));
            if (r.any()) {
                final String tail = Prefs.logTail(this, 40);
                Dialogs.message(this, r.title, r.lines, Lang.t("Close"), null, Lang.t("View log"), () -> Dialogs.log(this, tail));
            }
        }
    }

    // ---- views ---------------------------------------------------------------------------

    private LinearLayout buildHeroShell() {
        LinearLayout h = Ui.horizontal(this);
        h.setBackground(Ui.ripple(this, Ui.rounded(this, Ui.ACCENT_DIM, 20), 20));
        h.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        h.setClickable(true);
        Ui.press(h);
        return h;
    }

    private void bindHero(final Rom r) {
        LinearLayout h = (LinearLayout) hero;
        h.removeAllViews();
        TextView cover = coverText(r, 20);
        cover.setBackground(coverBackground(r, 14, true));
        h.addView(cover, new LinearLayout.LayoutParams(Ui.dp(this, 56), Ui.dp(this, 56)));
        LinearLayout col = Ui.vertical(this);
        TextView k = Ui.text(this, Lang.t("CONTINUE"), 10, Ui.ACCENT, true);
        k.setLetterSpacing(0.12f);
        col.addView(k);
        TextView t = Ui.text(this, r.main, 16, Ui.TEXT, true);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setPadding(0, Ui.dp(this, 3), 0, 0);
        col.addView(t);
        String d = r.detail.length() > 0 ? r.detail : r.name;
        TextView s = Ui.text(this, d, 12, Ui.SUB, false);
        s.setSingleLine(true);
        s.setEllipsize(TextUtils.TruncateAt.END);
        s.setPadding(0, Ui.dp(this, 2), 0, 0);
        col.addView(s);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        cp.leftMargin = Ui.dp(this, 14);
        h.addView(col, cp);
        ImageView play = Ui.icon(this, Icons.PLAY, Ui.ON_ACCENT, 20);
        play.setBackground(Ui.rounded(this, Ui.ACCENT, 22));
        int pd = Ui.dp(this, 12);
        play.setPadding(pd, pd, pd, pd);
        play.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        h.addView(play);
        h.setOnClickListener(v -> showSheet(r));
    }

    private View buildEmpty() {
        LinearLayout e = Ui.vertical(this);
        e.setGravity(Gravity.CENTER);
        e.setPadding(Ui.dp(this, 32), 0, Ui.dp(this, 32), Ui.dp(this, 48));
        ImageView ic = Ui.icon(this, Icons.GAMEPAD, Ui.ACCENT, 44);
        ic.setBackground(Ui.rounded(this, Ui.ACCENT_DIM, 44));
        int p = Ui.dp(this, 22);
        ic.setPadding(p, p, p, p);
        ic.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, 88), Ui.dp(this, 88)));
        e.addView(ic);
        TextView t = Ui.text(this, Lang.t("No games yet"), 20, Ui.TEXT, true);
        t.setPadding(0, Ui.dp(this, 20), 0, 0);
        e.addView(t);
        emptyText = Ui.text(this, "", 14, Ui.SUB, false);
        emptyText.setGravity(Gravity.CENTER);
        emptyText.setLineSpacing(0, 1.15f);
        emptyText.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 20));
        e.addView(emptyText);
        e.addView(Ui.button(this, Lang.t("Choose ROM folder"), Ui.FILLED, v -> {
            Intent i = new Intent(this, FileBrowserActivity.class);
            i.putExtra("mode", "folder");
            i.putExtra("start", Prefs.romDir(this));
            i.putExtra("title", Lang.t("ROM folder"));
            startActivityForResult(i, REQ_ROMDIR);
        }));
        return e;
    }

    private static int fnv(String s) {
        int h = 0x811C9DC5;
        for (int i = 0; i < s.length(); i++) { h ^= s.charAt(i); h *= 0x01000193; }
        return h;
    }

    private GradientDrawable coverBackground(Rom r, float radiusDp, boolean allCorners) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{r.c1, r.c2});
        float rad = Ui.dp(this, radiusDp);
        g.setCornerRadii(allCorners ? new float[]{rad, rad, rad, rad, rad, rad, rad, rad}
                : new float[]{rad, rad, rad, rad, 0, 0, 0, 0});
        return g;
    }

    private TextView coverText(Rom r, float sp) {
        TextView t = Ui.text(this, r.initials, sp, 0xE6FFFFFF, true);
        t.setGravity(Gravity.CENTER);
        t.setLetterSpacing(0.04f);
        return t;
    }

    private static final class Strip {
        TextView initials, title, detail, lua;
        ImageView img;
    }

    private View strip(Rom r, View v) {
        Strip t;
        if (v == null) {
            LinearLayout row = Ui.horizontal(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 12), 0);
            row.setBackground(Ui.ripple(this, Ui.rounded(this, Ui.SURFACE, 14), 14));
            t = new Strip();
            t.initials = Ui.text(this, "", 13, 0xE6FFFFFF, true);
            t.initials.setGravity(Gravity.CENTER);
            FrameLayout fl = new FrameLayout(this);
            fl.addView(t.initials, new FrameLayout.LayoutParams(-1, -1));
            t.img = new ImageView(this);
            t.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            fl.addView(t.img, new FrameLayout.LayoutParams(-1, -1));
            fl.setClipToOutline(true);
            fl.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override public void getOutline(View vw, android.graphics.Outline o) { o.setRoundRect(0, 0, vw.getWidth(), vw.getHeight(), Ui.dp(LauncherActivity.this, 12)); }
            });
            row.addView(fl, new LinearLayout.LayoutParams(Ui.dp(this, 42), Ui.dp(this, 42)));
            LinearLayout col = Ui.vertical(this);
            col.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
            t.title = Ui.text(this, "", 14, Ui.TEXT, true);
            t.title.setSingleLine(true);
            t.title.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(t.title);
            t.detail = Ui.text(this, "", 11, Ui.SUB, false);
            t.detail.setSingleLine(true);
            t.detail.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(t.detail);
            row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            t.lua = Ui.chip(this, "LUA", Ui.ON_ACCENT, Ui.ACCENT);
            t.lua.setTextSize(9);
            row.addView(t.lua);
            row.setTag(t);
            row.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 60)));
            v = row;
        } else {
            t = (Strip) v.getTag();
        }
        t.initials.setBackground(coverBackground(r, 12, true));
        t.initials.setText(r.initials);
        android.graphics.Bitmap cb = CoverStore.peek(this, r.name, this::coverLoaded);
        t.img.setImageBitmap(cb);
        t.img.setVisibility(cb != null ? View.VISIBLE : View.GONE);
        t.title.setText(r.main + "  \u00B7  " + r.name);
        String d = r.detail;
        if (r.bios) d = Lang.t("BIOS / system files");
        else if (!r.known) d = Lang.t("Not a known FBNeo set");
        else if (d.length() == 0) d = (r.year + "  " + r.maker).trim();
        t.detail.setText(d);
        String lua = Prefs.romScript(this, r.name);
        t.lua.setVisibility(lua != null && lua.length() > 0 ? View.VISIBLE : View.GONE);
        v.setAlpha(r.bios || !r.known ? 0.55f : 1f);
        return v;
    }

    private static final class Tile {
        FrameLayout cover;
        TextView initials, id, lua, title, detail;
        ImageView img;
    }

    private View tile(Rom r, View v) {
        Tile t;
        if (v == null) {
            LinearLayout card = Ui.vertical(this);
            card.setBackground(Ui.ripple(this, Ui.rounded(this, Ui.SURFACE, 16), 16));
            card.setClickable(false);
            t = new Tile();
            t.cover = new FrameLayout(this);
            t.initials = Ui.text(this, "", 22, 0xE6FFFFFF, true);
            t.initials.setGravity(Gravity.CENTER);
            t.initials.setLetterSpacing(0.04f);
            t.img = new ImageView(this);
            t.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            t.cover.addView(t.img, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            t.cover.setClipToOutline(true);
            final float rad = Ui.dp(this, 16);
            t.cover.setOutlineProvider(new android.view.ViewOutlineProvider() {
                @Override public void getOutline(View vw, android.graphics.Outline o) { o.setRoundRect(0, 0, vw.getWidth(), (int) (vw.getHeight() + rad), rad); }
            });
            t.cover.addView(t.initials, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            t.id = Ui.text(this, "", 10, 0xB3FFFFFF, false);
            t.id.setTypeface(Typeface.MONOSPACE);
            FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.START);
            ip.setMargins(Ui.dp(this, 10), 0, 0, Ui.dp(this, 8));
            t.cover.addView(t.id, ip);
            t.lua = Ui.chip(this, "LUA", Ui.ON_ACCENT, Ui.ACCENT);
            t.lua.setTextSize(9);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.END);
            lp.setMargins(0, Ui.dp(this, 8), Ui.dp(this, 8), 0);
            t.cover.addView(t.lua, lp);
            card.addView(t.cover, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (colW * 0.5f)));

            LinearLayout txt = Ui.vertical(this);
            txt.setPadding(Ui.dp(this, 8), Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 8));
            t.title = Ui.text(this, "", 12, Ui.TEXT, true);
            t.title.setLines(2);
            t.title.setEllipsize(TextUtils.TruncateAt.END);
            t.title.setLineSpacing(0, 1.05f);
            txt.addView(t.title);
            t.detail = Ui.text(this, "", 10.5f, Ui.SUB, false);
            t.detail.setSingleLine(true);
            t.detail.setEllipsize(TextUtils.TruncateAt.END);
            t.detail.setPadding(0, Ui.dp(this, 4), 0, 0);
            txt.addView(t.detail);
            card.addView(txt);
            card.setTag(t);
            card.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            v = card;
        } else {
            t = (Tile) v.getTag();
            ViewGroup.LayoutParams cp = t.cover.getLayoutParams();
            int h = (int) (colW * 0.5f);
            if (cp.height != h) { cp.height = h; t.cover.setLayoutParams(cp); }
        }
        t.cover.setBackground(coverBackground(r, 16, false));
        t.initials.setText(r.initials);
        android.graphics.Bitmap cb = CoverStore.peek(this, r.name, this::coverLoaded);
        t.img.setImageBitmap(cb);
        t.img.setVisibility(cb != null ? View.VISIBLE : View.GONE);
        t.initials.setVisibility(cb != null ? View.GONE : View.VISIBLE);
        t.id.setText(r.name);
        String lua = Prefs.romScript(this, r.name);
        t.lua.setVisibility(lua != null && lua.length() > 0 ? View.VISIBLE : View.GONE);
        t.title.setText(r.main);
        String d = r.detail;
        if (r.bios) d = Lang.t("BIOS / system files");
        else if (!r.known) d = Lang.t("Not a known FBNeo set");
        else if (d.length() == 0) d = (r.year + "  " + r.maker).trim();
        t.detail.setText(d);
        v.setAlpha(r.bios || !r.known ? 0.55f : 1f);
        return v;
    }

    // ---- data ----------------------------------------------------------------------------

    private static final String[] BIOS_SETS = {"neogeo", "pgm", "decocass", "cchip", "ym2608", "isgsm", "nmk004",
            "skns", "hng64", "midssio", "namcoc69", "namcoc70", "namcoc75", "neocdz", "pce", "segacd", "fdsbios", "gba",
            "spectrum", "msx", "coleco", "bubsys", "konamigx", "playch10", "stvbios", "airlbios", "taitofx1"};

    private static String initialsOf(String main) {
        String[] words = main.split("[^A-Za-z0-9]+");
        StringBuilder sb = new StringBuilder();
        int n = 0;
        for (String w : words) {
            if (w.length() == 0) continue;
            String lw = w.toLowerCase(Locale.ROOT);
            if (lw.equals("the") || lw.equals("of") || lw.equals("and") || lw.equals("a") || lw.equals("vs")) continue;
            if (w.matches("[IVX]{1,4}|[0-9]{1,3}")) { sb.append(w); break; }
            sb.append(Character.toUpperCase(w.charAt(0)));
            if (++n >= 3) break;
        }
        return sb.length() == 0 ? "?" : sb.toString();
    }

    private static void decorate(Rom r) {
        String t = r.title;
        int i = t.indexOf(" (");
        if (i > 0) {
            r.main = t.substring(0, i);
            int j = t.lastIndexOf(')');
            r.detail = j > i + 2 ? t.substring(i + 2, j) : "";
        } else {
            r.main = t;
            r.detail = "";
        }
        r.initials = initialsOf(r.main);
        int hue = (fnv(r.main) & 0x7FFFFFFF) % 360;
        r.c1 = Color.HSVToColor(new float[]{hue, 0.50f, 0.58f});
        r.c2 = Color.HSVToColor(new float[]{(hue + 28) % 360, 0.62f, 0.26f});
    }

    private void scan(final boolean force) {
        if (scanning) return;
        final String dir = Prefs.romDir(this);
        File[] probe = new File(dir).listFiles();
        StringBuilder sig = new StringBuilder(dir);
        if (probe != null) {
            for (File f : probe) sig.append('|').append(f.getName()).append(f.length());
        }
        final String signature = sig.toString();
        if (!force && signature.equals(lastSignature) && !all.isEmpty()) {
            refreshHeader(dir);
            return;
        }
        scanning = true;
        subtitle.setText(dir);
        new Thread(() -> {
            final List<Rom> found = new ArrayList<>();
            File[] files = new File(dir).listFiles();
            if (files != null) {
                for (File f : files) {
                    String n = f.getName();
                    String low = n.toLowerCase(Locale.ROOT);
                    if (!f.isFile() || !(low.endsWith(".zip") || low.endsWith(".7z"))) continue;
                    Rom r = new Rom();
                    r.name = n.substring(0, n.lastIndexOf('.'));
                    r.title = r.name;
                    found.add(r);
                }
            }
            if (!found.isEmpty() && Native.loadLibraries()) {
                try {
                    String[] names = new String[found.size()];
                    for (int i = 0; i < names.length; i++) names[i] = found.get(i).name;
                    String[] d = Native.describe(names);
                    for (int i = 0; i < d.length && i < found.size(); i++) {
                        if (d[i] == null || d[i].length() == 0) continue;
                        String[] p = d[i].split("\t", -1);
                        Rom r = found.get(i);
                        r.known = true;
                        if (p.length > 0 && p[0].length() > 0) r.title = p[0];
                        if (p.length > 1) r.year = p[1];
                        if (p.length > 2) r.maker = p[2];
                        if (p.length > 3) { r.bios = p[3].contains("B"); r.neo = p[3].contains("N"); }
                        for (String bn : BIOS_SETS) if (bn.equals(r.name)) r.bios = true;
                    }
                } catch (Throwable t) {
                    // names are optional
                }
            }
            for (Rom r : found) decorate(r);
            Collections.sort(found, (a, b) -> {
                int ra = a.known && !a.bios ? 0 : a.bios ? 1 : 2;
                int rb = b.known && !b.bios ? 0 : b.bios ? 1 : 2;
                if (ra != rb) return ra - rb;
                int c = a.main.compareToIgnoreCase(b.main);
                return c != 0 ? c : a.name.compareToIgnoreCase(b.name);
            });
            ui.post(() -> {
                scanning = false;
                lastSignature = signature;
                all.clear();
                all.addAll(found);
                List<String[]> cl = new ArrayList<>();
                for (Rom r : found) if (r.known && !r.bios) cl.add(new String[]{r.name, r.title, r.main});
                coverList = cl;
                autoCovers();
                applyFilter();
                refreshHeader(dir);
            });
        }).start();
    }

    private final Runnable coverRefresh = () -> adapter.notifyDataSetChanged();

    void refreshList() { coverLoaded(); }

    private void coverLoaded() {
        ui.removeCallbacks(coverRefresh);
        ui.postDelayed(coverRefresh, 120);
    }

    /** Optional: fetch the covers that are missing, in the background. */
    private void autoCovers() {
        if (!Prefs.sp(this).getBoolean("autoCovers", false) || CoverStore.busy()) return;
        final List<String[]> list = coverList;
        final Context app = getApplicationContext();
        new Thread(() -> {
            int n = CoverStore.downloadMissing(app, list, null, null);
            if (n > 0) ui.post(this::coverLoaded);
        }).start();
    }

    private Rom pendingCover;

    void pickCover(Rom rom) {
        pendingCover = rom;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(i, Lang.t("Choose a cover image")), REQ_COVER);
    }

    private void refreshHeader(String dir) {
        int games = 0;
        for (Rom r : all) if (r.known && !r.bios) games++;
        subtitle.setText(all.isEmpty() ? dir : games + Lang.t(" games  ·  ") + dir);
        emptyText.setText(Lang.t("Put your ROM .zip files in\n") + dir + Lang.t("\nor choose another folder."));
        updateHero();
    }

    private void applyFilter() {
        String q = search.getText().toString().trim().toLowerCase(Locale.ROOT);
        shown.clear();
        for (Rom r : all) {
            if (q.length() == 0 || r.title.toLowerCase(Locale.ROOT).contains(q) || r.name.toLowerCase(Locale.ROOT).contains(q)) {
                shown.add(r);
            }
        }
        adapter.notifyDataSetChanged();
        empty.setVisibility(all.isEmpty() && !scanning ? View.VISIBLE : View.GONE);
        updateHero();
    }

    private void updateHero() {
        String last = Prefs.lastRom(this);
        Rom found = null;
        if (last.length() > 0 && search.getText().length() == 0) {
            for (Rom r : all) if (r.name.equals(last)) { found = r; break; }
        }
        if (found == null) {
            hero.setVisibility(View.GONE);
        } else {
            bindHero(found);
            hero.setVisibility(View.VISIBLE);
        }
    }

    // ---- launching -----------------------------------------------------------------------

    private void showSheet(Rom rom) {
        if (!Prefs.hasAccess(this)) {
            Prefs.requestAccess(this);
            return;
        }
        new GameSheet(this, rom).show();
    }

    void browseForScript(Rom rom) {
        pendingRom = rom;
        Intent i = new Intent(this, FileBrowserActivity.class);
        i.putExtra("mode", "file");
        i.putExtra("ext", ".lua");
        i.putExtra("start", Prefs.luaDir(this));
        i.putExtra("title", Lang.t("Choose a Lua script"));
        startActivityForResult(i, REQ_SCRIPT);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_COVER && pendingCover != null) {
            final Rom r = pendingCover;
            pendingCover = null;
            if (res == RESULT_OK && data != null && data.getData() != null) {
                final android.net.Uri u = data.getData();
                final Context app = getApplicationContext();
                new Thread(() -> {
                    boolean ok = false;
                    try (java.io.InputStream in = getContentResolver().openInputStream(u)) {
                        ok = in != null && CoverStore.save(app, r.name, CoverStore.readAll(in, 20 * 1024 * 1024));
                    } catch (Exception e) { ok = false; }
                    final boolean fin = ok;
                    ui.post(() -> {
                        if (!fin) Ui.toast(this, Lang.t("Could not read that image"));
                        coverLoaded();
                        showSheet(r);
                    });
                }).start();
            } else {
                showSheet(r);
            }
            return;
        }
        if (req == REQ_SCRIPT && pendingRom != null) {
            Rom r = pendingRom;
            pendingRom = null;
            if (res == RESULT_OK && data != null && data.getStringExtra("path") != null) {
                Prefs.setRomScript(this, r.name, data.getStringExtra("path"));
                adapter.notifyDataSetChanged();
            }
            showSheet(r);
        } else if (req == REQ_ROMDIR && res == RESULT_OK && data != null && data.getStringExtra("path") != null) {
            Prefs.put(this, "romDir", data.getStringExtra("path"));
            lastSignature = "";
            scan(true);
        }
    }

    void play(Rom rom, String lua, boolean remember) {
        if (lua.length() > 0) {
            File f = new File(lua);
            if (!f.isFile()) {
                Ui.toast(this, Lang.t("Lua script not found: ") + lua);
                return;
            }
            LuaTools.prepareFolders(f);
            LuaTools.Report rep = LuaTools.check(f, rom.name);
            if (!rep.sets.isEmpty() && !rep.sets.contains(rom.name)) {
                askRightGame(rom, lua, remember, rep);
                return;
            }
        }
        start(rom, lua, remember);
    }

    /** The script only works on specific ROM sets (3rd Strike training: sfiii3nr1). */
    private void askRightGame(final Rom rom, final String lua, final boolean remember, LuaTools.Report rep) {
        Rom match = null;
        for (Rom r : all) {
            if (rep.sets.contains(r.name)) { match = r; break; }
        }
        StringBuilder sb = new StringBuilder();
        for (String s : rep.sets) { if (sb.length() > 0) sb.append(", "); sb.append(s); }
        List<String> text = new ArrayList<>();
        text.add(Lang.t("This script is made for the ROM set ") + sb + Lang.t(", not for ") + rom.name
                + Lang.t(". On other sets it can fail to start and leave a black screen."));
        final Rom fixed = match;
        if (fixed != null) {
            Dialogs.message(this, Lang.t("Wrong game version"), text, Lang.t("Play ") + fixed.name, () -> start(fixed, lua, remember),
                    Lang.t("Play anyway"), () -> start(rom, lua, remember));
        } else {
            text.add(Lang.t("There is no ") + sb + Lang.t(".zip in your ROM folder."));
            Dialogs.message(this, Lang.t("Wrong game version"), text, Lang.t("Play anyway"), () -> start(rom, lua, remember),
                    Lang.t("Cancel"), null);
        }
    }

    private void start(Rom rom, String lua, boolean remember) {
        if (remember) Prefs.setRomScript(this, rom.name, lua);
        Prefs.setLastRom(this, rom.name);
        Intent i = new Intent(this, GameActivity.class);
        i.putExtra("args", Prefs.buildArgs(this, rom.name, lua));
        launchedAt = SystemClock.elapsedRealtime();
        startActivity(i);
        adapter.notifyDataSetChanged();
    }
}
