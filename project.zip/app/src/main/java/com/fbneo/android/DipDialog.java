package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** The running game's DIP switches (difficulty, lives, region ...) as a list you can change. */
final class DipDialog {
    private DipDialog() {}

    static void show(final Activity a) {
        final String[] groups;
        try {
            groups = Native.dipList();
        } catch (UnsatisfiedLinkError | RuntimeException e) {
            Ui.toast(a, "DIP switches are not available");
            return;
        }
        if (groups == null || groups.length == 0) {
            Ui.toast(a, "This game has no DIP switches");
            return;
        }
        final LinearLayout[] h = new LinearLayout[1];
        final Dialog d = Dialogs.base(a, h);
        LinearLayout card = h[0];
        card.addView(Ui.text(a, "DIP switches", 20, Ui.TEXT, true));
        TextView hint = Ui.text(a, "Tap a setting to change it. If nothing seems to change, use Reset game from the pause menu.",
                12, Ui.SUB, false);
        hint.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 6));
        card.addView(hint);

        LinearLayout list = Ui.vertical(a);
        for (int g = 0; g < groups.length; g++) {
            final int group = g;
            final String[] f = groups[g].split("\t");
            if (f.length < 3) continue;
            final int selected = parse(f[1]);
            final String[] options = new String[f.length - 2];
            System.arraycopy(f, 2, options, 0, options.length);
            String now = selected >= 0 && selected < options.length ? options[selected] : "";
            list.addView(Ui.row(a, f[0], now, v ->
                    Dialogs.choose(a, f[0], options, selected, w -> {
                        Native.dipSet(group, w);
                        d.dismiss();
                        show(a);
                    })));
        }
        ScrollView sv = new Dialogs.MaxHeightScroll(a, (int) (Dialogs.screenHeight(a) * 0.62f));
        sv.addView(list);
        card.addView(sv);
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.setPadding(0, Ui.dp(a, 10), 0, 0);
        bar.addView(Ui.button(a, "Done", Ui.TEXTONLY, v -> d.dismiss()));
        card.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        d.show();
    }

    private static int parse(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
