package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** Styled dialogs (rounded dark cards) used instead of the stock AlertDialog. */
final class Dialogs {
    private Dialogs() {}

    interface IntCallback { void on(int value); }

    /** ScrollView that never grows taller than a given height. */
    static final class MaxHeightScroll extends ScrollView {
        private final int max;

        MaxHeightScroll(Context c, int maxPx) {
            super(c);
            max = maxPx;
            setOverScrollMode(OVER_SCROLL_NEVER);
        }

        @Override
        protected void onMeasure(int w, int h) {
            super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(max, View.MeasureSpec.AT_MOST));
        }
    }

    static int screenHeight(Context c) {
        return c.getResources().getDisplayMetrics().heightPixels;
    }

    static int screenWidth(Context c) {
        return c.getResources().getDisplayMetrics().widthPixels;
    }

    /** Empty centered dialog card; fill the returned layout, then call show(). */
    static Dialog base(Context c, final LinearLayout[] holder) {
        Dialog d = new Dialog(c);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout card = Ui.vertical(c);
        card.setBackground(Ui.rounded(c, Ui.SURFACE, 24));
        int p = Ui.dp(c, 22);
        card.setPadding(p, p, p, Ui.dp(c, 14));
        // taller than the screen (landscape)? then the whole card scrolls
        ScrollView outer = new MaxHeightScroll(c, (int) (screenHeight(c) * 0.94f));
        outer.addView(card);
        d.setContentView(outer);
        Window w = d.getWindow();
        w.setBackgroundDrawable(new ColorDrawable(0));
        w.setDimAmount(0.6f);
        int width = Math.min(screenWidth(c) - Ui.dp(c, 32), Ui.dp(c, 480));
        w.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT);
        w.setGravity(Gravity.CENTER);
        holder[0] = card;
        return d;
    }

    static Dialog message(Activity a, String title, List<String> paragraphs, String primary, final Runnable onPrimary,
                          String secondary, final Runnable onSecondary) {
        final LinearLayout[] h = new LinearLayout[1];
        final Dialog d = base(a, h);
        LinearLayout card = h[0];
        card.addView(Ui.text(a, title, 20, Ui.TEXT, true));
        LinearLayout body = Ui.vertical(a);
        for (String s : paragraphs) {
            TextView t = Ui.text(a, s, 14, Ui.SUB, false);
            t.setLineSpacing(0, 1.15f);
            t.setPadding(0, Ui.dp(a, 10), 0, 0);
            body.addView(t);
        }
        ScrollView sv = new MaxHeightScroll(a, (int) (screenHeight(a) * 0.55f));
        sv.addView(body);
        card.addView(sv);
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.setPadding(0, Ui.dp(a, 14), 0, 0);
        if (secondary != null) {
            bar.addView(Ui.button(a, secondary, Ui.TEXTONLY, v -> { d.dismiss(); if (onSecondary != null) onSecondary.run(); }));
        }
        bar.addView(Ui.button(a, primary, Ui.TEXTONLY, v -> { d.dismiss(); if (onPrimary != null) onPrimary.run(); }));
        card.addView(bar);
        d.show();
        return d;
    }

    /** Single choice list. */
    static void choose(Activity a, String title, String[] options, int selected, final IntCallback cb) {
        final LinearLayout[] h = new LinearLayout[1];
        final Dialog d = base(a, h);
        LinearLayout card = h[0];
        card.addView(Ui.text(a, title, 20, Ui.TEXT, true));
        LinearLayout list = Ui.vertical(a);
        for (int i = 0; i < options.length; i++) {
            final int idx = i;
            LinearLayout r = Ui.horizontal(a);
            r.setPadding(Ui.dp(a, 4), Ui.dp(a, 14), Ui.dp(a, 4), Ui.dp(a, 14));
            r.setBackground(Ui.ripple(a, Ui.rounded(a, 0, 12), 12));
            TextView t = Ui.text(a, options[i], 16, i == selected ? Ui.ACCENT : Ui.TEXT, i == selected);
            r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (i == selected) r.addView(Ui.icon(a, Icons.CHECK, Ui.ACCENT, 20));
            r.setClickable(true);
            r.setOnClickListener(v -> { d.dismiss(); cb.on(idx); });
            list.addView(r);
        }
        LinearLayout.LayoutParams lp = Ui.fillMargins(a, 0, 8, 0, 0);
        ScrollView sv = new MaxHeightScroll(a, (int) (screenHeight(a) * 0.6f));
        sv.addView(list);
        card.addView(sv, lp);
        d.show();
    }

    static void log(final Activity a, final String text) {
        final LinearLayout[] h = new LinearLayout[1];
        final Dialog d = base(a, h);
        LinearLayout card = h[0];
        card.addView(Ui.text(a, "Last game log", 20, Ui.TEXT, true));
        TextView tv = Ui.text(a, text.length() == 0 ? "No log yet. Start a game first." : text, 11, Ui.TEXT, false);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextIsSelectable(true);
        tv.setPadding(0, Ui.dp(a, 12), 0, 0);
        ScrollView sv = new MaxHeightScroll(a, (int) (screenHeight(a) * 0.6f));
        sv.addView(tv);
        card.addView(sv);
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.setPadding(0, Ui.dp(a, 12), 0, 0);
        bar.addView(Ui.button(a, "Copy", Ui.TEXTONLY, v -> {
            ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("FBNeo log", text));
            Ui.toast(a, "Copied");
        }));
        bar.addView(Ui.button(a, "Close", Ui.TEXTONLY, v -> d.dismiss()));
        card.addView(bar);
        d.show();
    }
}
