package com.fbneo.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Folder / file picker. Extras: mode ("folder" | "file"), start, ext (e.g. ".lua"), title. Result: "path". */
public class FileBrowserActivity extends Activity {
    private boolean folderMode;
    private String ext;
    private File cur;
    private TextView pathView, hint;
    private final List<File> items = new ArrayList<>();
    private BaseAdapter adapter;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        folderMode = !"file".equals(getIntent().getStringExtra("mode"));
        ext = getIntent().getStringExtra("ext");
        String start = getIntent().getStringExtra("start");
        cur = new File(start != null ? start : "/storage/emulated/0");
        while (cur != null && !cur.isDirectory()) cur = cur.getParentFile();
        if (cur == null) cur = new File("/storage/emulated/0");

        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);
        String title = getIntent().getStringExtra("title");
        root.addView(Ui.topBar(this, title != null ? title : (folderMode ? "Choose a folder" : "Choose a file"), this::finish));
        pathView = Ui.text(this, "", 12, Ui.SUB, false);
        pathView.setSingleLine(true);
        pathView.setEllipsize(TextUtils.TruncateAt.START);
        pathView.setBackground(Ui.rounded(this, Ui.SURFACE, 12));
        pathView.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        root.addView(pathView, Ui.fillMargins(this, 16, 0, 16, 6));

        ListView list = new ListView(this);
        list.setDividerHeight(0);
        list.setClipToPadding(false);
        list.setPadding(0, 0, 0, Ui.dp(this, 12));
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        adapter = new BaseAdapter() {
            @Override public int getCount() { return items.size() + 1; }
            @Override public Object getItem(int i) { return null; }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View v, ViewGroup p) {
                LinearLayout r;
                TextView t;
                android.widget.ImageView ic;
                if (v == null) {
                    r = Ui.horizontal(FileBrowserActivity.this);
                    r.setBackground(Ui.ripple(FileBrowserActivity.this, Ui.rounded(FileBrowserActivity.this, Ui.SURFACE, 14), 14));
                    r.setPadding(Ui.dp(FileBrowserActivity.this, 14), Ui.dp(FileBrowserActivity.this, 13), Ui.dp(FileBrowserActivity.this, 14), Ui.dp(FileBrowserActivity.this, 13));
                    ic = Ui.icon(FileBrowserActivity.this, Icons.FOLDER, Ui.ACCENT, 22);
                    LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(Ui.dp(FileBrowserActivity.this, 22), Ui.dp(FileBrowserActivity.this, 22));
                    ip.rightMargin = Ui.dp(FileBrowserActivity.this, 14);
                    ic.setLayoutParams(ip);
                    r.addView(ic);
                    t = Ui.text(FileBrowserActivity.this, "", 15, Ui.TEXT, false);
                    t.setSingleLine(true);
                    t.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                    r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    r.setLayoutParams(new android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                    r.setTag(new Object[]{ic, t});
                    LinearLayout wrap = Ui.vertical(FileBrowserActivity.this);
                    wrap.setPadding(Ui.dp(FileBrowserActivity.this, 16), Ui.dp(FileBrowserActivity.this, 3), Ui.dp(FileBrowserActivity.this, 16), Ui.dp(FileBrowserActivity.this, 3));
                    wrap.addView(r);
                    wrap.setTag(r);
                    v = wrap;
                }
                LinearLayout wrap = (LinearLayout) v;
                r = (LinearLayout) wrap.getTag();
                Object[] views = (Object[]) r.getTag();
                ic = (android.widget.ImageView) views[0];
                t = (TextView) views[1];
                if (i == 0) {
                    ic.setImageDrawable(Icons.get(Icons.BACK, Ui.SUB));
                    t.setText("Up one folder");
                    t.setTextColor(Ui.SUB);
                } else {
                    File f = items.get(i - 1);
                    ic.setImageDrawable(Icons.get(f.isDirectory() ? Icons.FOLDER : Icons.SCRIPT, f.isDirectory() ? Ui.ACCENT : Ui.SUB));
                    t.setText(f.getName());
                    t.setTextColor(Ui.TEXT);
                }
                return v;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, pos, id) -> {
            if (pos == 0) {
                File up = cur.getParentFile();
                if (up != null) { cur = up; refresh(); }
                return;
            }
            File f = items.get(pos - 1);
            if (f.isDirectory()) { cur = f; refresh(); }
            else if (!folderMode) finishWith(f);
        });
        FrameLayoutHolder.add(root, list, this);

        if (folderMode) {
            LinearLayout bar = Ui.horizontal(this);
            bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
            bar.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 14));
            bar.setBackgroundColor(Ui.BG);
            bar.addView(Ui.button(this, "Cancel", Ui.TEXTONLY, v -> finish()));
            bar.addView(Ui.button(this, "Use this folder", Ui.FILLED, v -> finishWith(cur)), Ui.wrapMargins(this, 8, 0, 0, 0));
            root.addView(bar);
        }
        setContentView(root);
        refresh();
    }

    /** Adds the list plus the "nothing here" hint on top of each other. */
    private static final class FrameLayoutHolder {
        static void add(LinearLayout root, ListView list, FileBrowserActivity a) {
            android.widget.FrameLayout f = new android.widget.FrameLayout(a);
            f.addView(list, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            a.hint = Ui.text(a, "", 14, Ui.SUB, false);
            a.hint.setGravity(Gravity.CENTER);
            a.hint.setPadding(Ui.dp(a, 32), 0, Ui.dp(a, 32), Ui.dp(a, 64));
            f.addView(a.hint, new android.widget.FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            root.addView(f, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        }
    }

    private void refresh() {
        pathView.setText(cur.getAbsolutePath());
        items.clear();
        File[] l = cur.listFiles();
        hint.setText("");
        if (l == null) {
            hint.setText("Cannot read this folder.\nCheck that \"All files access\" is allowed.");
        } else {
            List<File> dirs = new ArrayList<>(), files = new ArrayList<>();
            for (File f : l) {
                if (f.getName().startsWith(".")) continue;
                if (f.isDirectory()) dirs.add(f);
                else if (!folderMode && (ext == null || f.getName().toLowerCase().endsWith(ext))) files.add(f);
            }
            Collections.sort(dirs, (a, c) -> a.getName().compareToIgnoreCase(c.getName()));
            Collections.sort(files, (a, c) -> a.getName().compareToIgnoreCase(c.getName()));
            items.addAll(dirs);
            items.addAll(files);
            if (items.isEmpty()) hint.setText(folderMode ? "No subfolders here." : "No " + (ext != null ? ext : "") + " files here.");
        }
        adapter.notifyDataSetChanged();
    }

    private void finishWith(File f) {
        Intent r = new Intent();
        r.putExtra("path", f.getAbsolutePath());
        setResult(RESULT_OK, r);
        finish();
    }

    @Override
    public void onBackPressed() {
        File up = cur.getParentFile();
        // Back goes up one folder first, then leaves
        if (up != null && cur.getAbsolutePath().length() > "/storage/emulated/0".length()) {
            cur = up;
            refresh();
        } else {
            super.onBackPressed();
        }
    }
}
