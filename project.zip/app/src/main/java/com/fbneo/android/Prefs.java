package com.fbneo.android;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import java.io.File;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/** Settings storage, storage permission helpers and the command line given to the emulator. */
final class Prefs {
    private Prefs() {}

    static final String DEFAULT_ROOT = "/storage/emulated/0/Emulators/";
    static final String OLD_DATA = "/storage/emulated/0/fbneo/";
    static final String OLD_MAME = "/storage/emulated/0/Roms/mame/";

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("fbneo", Context.MODE_PRIVATE);
    }

    private static String slash(String p) {
        return p.endsWith("/") ? p : p + "/";
    }

    /** The one main folder that holds fbneo/ and mame/. */
    static String rootDir(Context c) { return slash(sp(c).getString("rootDir", DEFAULT_ROOT)); }
    static String dataDir(Context c) { return slash(sp(c).getString("dataDir", rootDir(c) + "fbneo/")); }
    static String romDir(Context c) { return slash(sp(c).getString("romDir", dataDir(c) + "roms/")); }
    static String luaDir(Context c) { return slash(sp(c).getString("luaDir", dataDir(c) + "lua/")); }
    static String mameDir(Context c) { return slash(sp(c).getString("mameDir", rootDir(c) + "mame/")); }
    /** One time: moves the old fbneo and mame folders into the main folder and creates the three sub folders. */
    static void migrateLayout(Context c) {
        try {
            if (!hasAccess(c)) return;
            SharedPreferences p = sp(c);
            if (!p.getBoolean("layoutV2", false)) {
                File root = new File(rootDir(c));
                root.mkdirs();
                if (!p.contains("dataDir")) {
                    File o = new File(OLD_DATA), n = new File(root, "fbneo");
                    if (o.isDirectory() && !n.exists() && !o.renameTo(n)) p.edit().putString("dataDir", OLD_DATA).apply();
                }
                if (!p.contains("mameDir")) {
                    File o = new File(OLD_MAME), n = new File(root, "mame");
                    if (o.isDirectory() && !n.exists() && !o.renameTo(n)) p.edit().putString("mameDir", OLD_MAME).apply();
                }
                p.edit().putBoolean("layoutV2", true).apply();
            }
            new File(dataDir(c), "roms").mkdirs();
            new File(dataDir(c), "lua").mkdirs();
            new File(mameDir(c)).mkdirs();
        } catch (Throwable ignored) {}
    }

    static String filter(Context c) { return sp(c).getString("filter", "sharp"); }
    static boolean integerScale(Context c) { return sp(c).getBoolean("integer", false); }
    static boolean showFps(Context c) { return sp(c).getBoolean("fps", false); }
    static int sampleRate(Context c) { return sp(c).getInt("rate", 44100); }
    static boolean startSwapped(Context c) { return sp(c).getBoolean("swap", false); }
    static String defaultLua(Context c) { return sp(c).getString("luaDefault", ""); }
    /** Picture output through Vulkan instead of OpenGL ES (off unless chosen in Settings). */
    static boolean vulkan(Context c) { return sp(c).getBoolean("vulkan", false); }
    static boolean vsync(Context c) { return sp(c).getBoolean("vsync", false); }
    /** 0 = low lag (3 frames of audio), 1 = balanced (4), 2 = safe (6, the default: smoothest). */
    static int latency(Context c) { return sp(c).getInt("latency", 2); }
    /** Keep the emulation thread on the phone's fastest CPU cores. */
    static boolean fastCores(Context c) { return sp(c).getBoolean("fastCores", true); }
    /** Sleep between frames: cooler and gentler on the battery, but heavy games can get slower. */
    static boolean batterySaver(Context c) { return sp(c).getBoolean("batterySaver", false); }
    static boolean autoRotate(Context c) { return sp(c).getBoolean("autoRotate", false); }
    /** Draw one frame in (n+1): 0 = off. Helps weak phones, mostly with CPS3. */
    static int frameskip(Context c) { return sp(c).getInt("frameskip", 0); }
    /** Cheaper sound mixing (less accurate ADPCM). */
    static boolean fastAudio(Context c) { return sp(c).getBoolean("fastAudio", false); }
    /** Neo Geo: start as the home console (AES) with its options menu. Per game. */
    static boolean aes(Context c, String rom) { return sp(c).getBoolean("aes." + rom, false); }
    static void setAes(Context c, String rom, boolean on) { put(c, "aes." + rom, on); }
    static boolean touchOn(Context c) { return sp(c).getBoolean("touchOn", false); }
    static int touchAlpha(Context c) { return sp(c).getInt("touchAlpha", 55); }
    /** On-screen counters: bit 0 FPS, bit 1 speed, bit 2 screen refresh. */
    static int counters(Context c) { return sp(c).getInt("counters", sp(c).getBoolean("fps", false) ? 1 : 0); }
    /** Frames paced by a steady clock instead of the audio device's chunks (smoother). */
    static boolean smoothPacing(Context c) { return sp(c).getBoolean("smoothPacing", true); }
    /** Run the game at the screen's refresh rate when they are close (59.6 fps game on a 60 Hz screen). */
    static boolean matchRefresh(Context c) { return sp(c).getBoolean("matchRefresh", true); }
    /** Stop drawing frames while the phone is behind, to keep full game speed. */
    static boolean autoSkip(Context c) { return sp(c).getBoolean("autoSkip", true); }
    static boolean softRender(Context c) { return sp(c).getBoolean("softRender", false); }
    static boolean videoThread(Context c) { return sp(c).getBoolean("videoThread", false); }
    static boolean highPrio(Context c) { return sp(c).getBoolean("highPrio", true); }
    static boolean sustained(Context c) { return sp(c).getBoolean("sustained", false); }
    /** Touching the gap between buttons presses both: 0 = off, 60, 80 or 100 (how far it reaches). */
    static int touchBlend(Context c) { return sp(c).getInt("touchBlend", 0); }
    /** On-screen stick moves freely (true) or jumps between 8 directions (false). */
    static boolean smoothStick(Context c) { return sp(c).getBoolean("smoothStick", true); }
    static boolean match60(Context c) { return sp(c).getBoolean("match60", false); }

    /** Screen shapes offered in the app: {label, native argument}. Index 0 = the game's own shape. */
    static final String[][] ASPECTS = {
            {"Original (the game's own shape)", "original"},
            {"4:3  (classic arcade monitor)", "4:3"},
            {"3:2", "3:2"},
            {"16:10", "16:10"},
            {"16:9  (widescreen)", "16:9"},
            {"21:9  (ultrawide)", "21:9"},
            {"Stretch to the whole screen", "stretch"},
    };
    static int aspect(Context c) { return Math.max(0, Math.min(ASPECTS.length - 1, sp(c).getInt("aspect", 0))); }
    static String aspectArg(int index) { return ASPECTS[Math.max(0, Math.min(ASPECTS.length - 1, index))][1]; }
    /** Width and height for Native.setAspect(). */
    static int[] aspectValues(int index) {
        String a = aspectArg(index);
        if ("stretch".equals(a)) return new int[]{-1, -1};
        if ("original".equals(a)) return new int[]{0, 0};
        String[] p = a.split(":");
        return new int[]{Integer.parseInt(p[0]), Integer.parseInt(p[1])};
    }

    /** Remember quick stick / D-pad changes so none is lost between two frames (arcade feel). */
    static boolean smoothInput(Context c) { return sp(c).getBoolean("smoothInput", true); }
    /** 0 = precise, 1 = arcade (default), 2 = forgiving. */
    static int stickFeel(Context c) { return sp(c).getInt("stickFeel", 1); }

    static String lastRom(Context c) { return sp(c).getString("lastRom", ""); }
    static void setLastRom(Context c, String rom) { put(c, "lastRom", rom); }

    static void put(Context c, String k, String v) { sp(c).edit().putString(k, v).commit(); }
    static void put(Context c, String k, boolean v) { sp(c).edit().putBoolean(k, v).commit(); }
    static void put(Context c, String k, int v) { sp(c).edit().putInt(k, v).commit(); }

    /** Script remembered for a game: null = never chosen, "" = chosen "no script". */
    static String romScript(Context c, String rom) { return sp(c).getString("lua." + rom, null); }
    static void setRomScript(Context c, String rom, String path) { put(c, "lua." + rom, path == null ? "" : path); }

    /** "Jump to character select with free play" checkbox, per game. */
    static boolean quickStart(Context c, String rom) { return sp(c).getBoolean("quick." + rom, false); }
    static void setQuickStart(Context c, String rom, boolean on) { put(c, "quick." + rom, on); }

    static String logFile(Context c) { return dataDir(c) + "last_run.log"; }

    static String[] buildArgs(Context c, String rom, String lua) {
        return buildArgs(c, rom, lua, false, "");
    }

    static String[] buildArgs(Context c, String rom, String lua, boolean quick, String quickState) {
        List<String> a = new ArrayList<>();
        a.add("-datadir"); a.add(dataDir(c));
        a.add("-romdir"); a.add(romDir(c));
        a.add("-logfile"); a.add(logFile(c));
        a.add("-fullscreen");
        String f = filter(c);
        a.add("smooth".equals(f) ? "-linear" : "best".equals(f) ? "-best" : "-nearest");
        if (integerScale(c)) a.add("-integerscale");
        if (counters(c) != 0) { a.add("-counters"); a.add(String.valueOf(counters(c))); }
        if (!smoothPacing(c)) a.add("-classicpacing");
        if (!autoSkip(c)) a.add("-noautoskip");
        if (softRender(c)) a.add("-softrender");
        if (videoThread(c)) a.add("-vthread");
        if (highPrio(c)) a.add("-highprio");
        if (!vsync(c)) a.add("-novsync");
        int lat = latency(c);
        a.add("-audiosegs"); a.add(String.valueOf(lat == 0 ? 3 : lat == 1 ? 4 : 6));
        a.add("-orient"); a.add(autoRotate(c) ? "auto" : "land");
        a.add("-aspect"); a.add(aspectArg(aspect(c)));
        if (frameskip(c) > 0) { a.add("-frameskip"); a.add(String.valueOf(frameskip(c))); }
        if (fastAudio(c)) a.add("-fastaudio");
        if (aes(c, rom)) a.add("-aes");
        if (!smoothInput(c)) a.add("-noinputqueue");
        if (fastCores(c)) a.add("-bigcores");
        if (batterySaver(c)) a.add("-idlesleep");
        if (startSwapped(c)) a.add("-swap");
        a.add("-samplerate"); a.add(String.valueOf(sampleRate(c)));
        if (lua != null && lua.length() > 0) { a.add("-lua"); a.add(lua); }
        if (quick) {
            a.add("-quickstart");
            if (quickState != null && quickState.length() > 0) { a.add("-quickstate"); a.add(quickState); }
        }
        a.add(rom);
        return a.toArray(new String[0]);
    }

    /** Last few lines of the emulator log (empty string if there is none). */
    static String logTail(Context c, int maxLines) {
        File f = new File(logFile(c));
        if (!f.isFile()) return "";
        try (RandomAccessFile r = new RandomAccessFile(f, "r")) {
            long len = r.length();
            int n = (int) Math.min(len, 6000);
            byte[] b = new byte[n];
            r.seek(len - n);
            r.readFully(b);
            String[] lines = new String(b, "UTF-8").split("\n");
            StringBuilder sb = new StringBuilder();
            int start = Math.max(0, lines.length - maxLines);
            for (int i = start; i < lines.length; i++) {
                if (lines[i].trim().length() > 0) sb.append(lines[i]).append('\n');
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    // ---- storage permission ------------------------------------------------------------

    static boolean hasAccess(Context c) {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    static void requestAccess(Activity a) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + a.getPackageName())));
            } catch (Exception e) {
                a.startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else {
            a.requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }
}
