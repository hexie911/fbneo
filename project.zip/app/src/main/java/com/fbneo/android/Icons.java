package com.fbneo.android;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/** Small vector icons drawn with Canvas (no resource files, no support library). */
final class Icons {
    private Icons() {}

    static final int GAMEPAD = 0, GEAR = 1, PLAY = 2, FOLDER = 3, SEARCH = 4, BACK = 5, CLOSE = 6, CHECK = 7,
            DOWNLOAD = 8, WARN = 9, CHEVRON = 10, SCRIPT = 11, LIST = 12, INFO = 13;

    static Drawable get(int kind, int color) {
        return new Icon(kind, color);
    }

    private static final class Icon extends Drawable {
        private final int kind;
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private int alpha = 255;

        Icon(int kind, int color) {
            this.kind = kind;
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(color);
            line.setStyle(Paint.Style.STROKE);
            line.setColor(color);
            line.setStrokeCap(Paint.Cap.ROUND);
            line.setStrokeJoin(Paint.Join.ROUND);
        }

        @Override
        public void draw(Canvas c) {
            float w = getBounds().width(), h = getBounds().height();
            float s = Math.min(w, h);
            c.save();
            c.translate(getBounds().left + (w - s) / 2f, getBounds().top + (h - s) / 2f);
            c.scale(s / 24f, s / 24f);
            line.setStrokeWidth(2f);
            fill.setAlpha(alpha);
            line.setAlpha(alpha);
            Path p = new Path();
            switch (kind) {
                case GAMEPAD: {
                    RectF body = new RectF(2.5f, 7f, 21.5f, 18f);
                    c.drawRoundRect(body, 5.5f, 5.5f, line);
                    c.drawLine(7.5f, 10.5f, 7.5f, 14.5f, line);
                    c.drawLine(5.5f, 12.5f, 9.5f, 12.5f, line);
                    c.drawCircle(15.5f, 11.2f, 1.1f, fill);
                    c.drawCircle(18f, 13.8f, 1.1f, fill);
                    break;
                }
                case GEAR: {
                    for (int i = 0; i < 8; i++) {
                        c.save();
                        c.rotate(i * 45f, 12f, 12f);
                        c.drawLine(12f, 2.6f, 12f, 5.2f, line);
                        c.restore();
                    }
                    c.drawCircle(12f, 12f, 6.3f, line);
                    c.drawCircle(12f, 12f, 2.4f, line);
                    break;
                }
                case PLAY: {
                    p.moveTo(7f, 4.5f);
                    p.lineTo(19.5f, 12f);
                    p.lineTo(7f, 19.5f);
                    p.close();
                    c.drawPath(p, fill);
                    break;
                }
                case FOLDER: {
                    p.moveTo(3f, 6.5f);
                    p.lineTo(9f, 6.5f);
                    p.lineTo(11f, 8.5f);
                    p.lineTo(21f, 8.5f);
                    p.lineTo(21f, 18.5f);
                    p.lineTo(3f, 18.5f);
                    p.close();
                    c.drawPath(p, line);
                    break;
                }
                case SEARCH: {
                    c.drawCircle(10.5f, 10.5f, 6f, line);
                    c.drawLine(15f, 15f, 20.5f, 20.5f, line);
                    break;
                }
                case BACK: {
                    c.drawLine(19.5f, 12f, 5f, 12f, line);
                    p.moveTo(11f, 5.5f);
                    p.lineTo(4.5f, 12f);
                    p.lineTo(11f, 18.5f);
                    c.drawPath(p, line);
                    break;
                }
                case CLOSE: {
                    c.drawLine(6f, 6f, 18f, 18f, line);
                    c.drawLine(18f, 6f, 6f, 18f, line);
                    break;
                }
                case CHECK: {
                    p.moveTo(5f, 12.5f);
                    p.lineTo(10f, 17.5f);
                    p.lineTo(19.5f, 7f);
                    c.drawPath(p, line);
                    break;
                }
                case DOWNLOAD: {
                    c.drawLine(12f, 4f, 12f, 15f, line);
                    p.moveTo(7f, 10.5f);
                    p.lineTo(12f, 15.5f);
                    p.lineTo(17f, 10.5f);
                    c.drawPath(p, line);
                    c.drawLine(5f, 19.5f, 19f, 19.5f, line);
                    break;
                }
                case WARN: {
                    p.moveTo(12f, 3.5f);
                    p.lineTo(22f, 20.5f);
                    p.lineTo(2f, 20.5f);
                    p.close();
                    c.drawPath(p, line);
                    c.drawLine(12f, 9.5f, 12f, 14.5f, line);
                    c.drawCircle(12f, 17.4f, 1f, fill);
                    break;
                }
                case CHEVRON: {
                    p.moveTo(9f, 5.5f);
                    p.lineTo(15.5f, 12f);
                    p.lineTo(9f, 18.5f);
                    c.drawPath(p, line);
                    break;
                }
                case SCRIPT: {
                    c.drawRoundRect(new RectF(5f, 3.5f, 19f, 20.5f), 2.5f, 2.5f, line);
                    c.drawLine(8.5f, 9f, 15.5f, 9f, line);
                    c.drawLine(8.5f, 12.5f, 15.5f, 12.5f, line);
                    c.drawLine(8.5f, 16f, 12.5f, 16f, line);
                    break;
                }
                case LIST: {
                    for (int i = 0; i < 3; i++) {
                        float y = 7f + i * 5f;
                        c.drawCircle(5.5f, y, 1f, fill);
                        c.drawLine(9f, y, 20f, y, line);
                    }
                    break;
                }
                case INFO: {
                    c.drawCircle(12f, 12f, 9f, line);
                    c.drawLine(12f, 11f, 12f, 16.5f, line);
                    c.drawCircle(12f, 7.8f, 1f, fill);
                    break;
                }
                default:
                    break;
            }
            c.restore();
        }

        @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }
        @Override public void setColorFilter(ColorFilter f) { fill.setColorFilter(f); line.setColorFilter(f); }
        @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
        @Override public int getIntrinsicWidth() { return -1; }
        @Override public int getIntrinsicHeight() { return -1; }
    }
}
