package com.fbneo.android;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Game covers: stored as covers/<rom name>.jpg inside the FBNeo data folder, fetched from the libretro thumbnail
 * server (FBNeo - Arcade Games) or picked from the phone.
 */
final class CoverStore {
    private CoverStore() {}

    private static final String BASE = "https://thumbnails.libretro.com/FBNeo%20-%20Arcade%20Games/";
    private static final String[] KINDS = {"Named_Boxarts", "Named_Titles", "Named_Snaps"};
    private static final int MAX_SIDE = 800;

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final ExecutorService POOL = Executors.newSingleThreadExecutor();
    private static final Set<String> loading = new HashSet<>();
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    static File dir(Context c) {
        File d = new File(Prefs.dataDir(c), "covers");
        d.mkdirs();
        return d;
    }

    static File file(Context c, String rom) {
        return new File(dir(c), rom + ".jpg");
    }

    static boolean has(Context c, String rom) {
        return file(c, rom).isFile();
    }

    static void remove(Context c, String rom) {
        file(c, rom).delete();
    }

    /** Cached picture, or null (and a background load that calls onLoaded when it is ready). */
    static Bitmap peek(Context c, String rom, final Runnable onLoaded) {
        final File f = file(c, rom);
        if (!f.isFile()) return null;
        final String key = rom + "|" + f.lastModified();
        Bitmap b = CACHE.get(key);
        if (b != null) return b;
        synchronized (loading) {
            if (!loading.add(key)) return null;
        }
        POOL.execute(() -> {
            Bitmap bm = decode(f, 360);
            synchronized (loading) { loading.remove(key); }
            if (bm != null) {
                CACHE.put(key, bm);
                if (onLoaded != null) MAIN.post(onLoaded);
            }
        });
        return null;
    }

    private static Bitmap decode(File f, int maxSide) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= maxSide) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        } catch (RuntimeException | OutOfMemoryError e) {
            return null;
        }
    }

    /** Decodes any image (PNG, JPEG, WebP), shrinks it and stores it as the game's cover. */
    static boolean save(Context c, String rom, byte[] data) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return false;
            int s = 1;
            while (Math.max(o.outWidth, o.outHeight) / (s * 2) >= MAX_SIDE) s *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = s;
            Bitmap src = BitmapFactory.decodeByteArray(data, 0, data.length, o);
            if (src == null) return false;
            Bitmap flat = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas cv = new Canvas(flat);
            cv.drawColor(0xFF000000);
            cv.drawBitmap(src, 0, 0, null);
            File out = file(c, rom);
            File tmp = new File(out.getPath() + ".tmp");
            try (FileOutputStream fo = new FileOutputStream(tmp)) {
                flat.compress(Bitmap.CompressFormat.JPEG, 88, fo);
            }
            if (!tmp.renameTo(out)) { out.delete(); if (!tmp.renameTo(out)) return false; }
            return true;
        } catch (Exception | OutOfMemoryError e) {
            return false;
        }
    }

    static byte[] readAll(InputStream in, int cap) throws java.io.IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) {
            bo.write(buf, 0, n);
            if (bo.size() > cap) throw new java.io.IOException("too big");
        }
        return bo.toByteArray();
    }

    private static String clean(String s) {
        // libretro thumbnail file names replace these characters with an underscore
        return s.replaceAll("[&*/:`<>?\\\\|\"]", "_");
    }

    private static byte[] get(String url) {
        HttpURLConnection h = null;
        try {
            h = (HttpURLConnection) new URL(url).openConnection();
            h.setConnectTimeout(8000);
            h.setReadTimeout(15000);
            h.setRequestProperty("User-Agent", "FBNeo-Android");
            if (h.getResponseCode() != 200) return null;
            try (InputStream in = h.getInputStream()) {
                return readAll(in, 6 * 1024 * 1024);
            }
        } catch (Exception e) {
            return null;
        } finally {
            if (h != null) h.disconnect();
        }
    }

    /** Tries the box art, then the title screen, then a snapshot. True when a cover was stored. */
    static boolean download(Context c, String rom, String title, String main) {
        String[] names = title.equals(main) || main.length() == 0 ? new String[]{title} : new String[]{title, main};
        for (String kind : KINDS) {
            for (String n : names) {
                try {
                    String u = BASE + kind + "/" + URLEncoder.encode(clean(n), "UTF-8").replace("+", "%20") + ".png";
                    byte[] d = get(u);
                    if (d != null && save(c, rom, d)) return true;
                } catch (java.io.UnsupportedEncodingException e) { /* never */ }
            }
        }
        return false;
    }

    interface Progress { void on(int done, int total, int found, String current); }

    private static final AtomicBoolean running = new AtomicBoolean();

    static boolean busy() { return running.get(); }

    /** Fetches every cover that is still missing. games = {rom, title, main}. Returns how many were found. */
    static int downloadMissing(Context c, List<String[]> games, Progress p, AtomicBoolean cancel) {
        if (!running.compareAndSet(false, true)) return 0;
        int found = 0, done = 0;
        try {
            int total = games.size();
            for (String[] g : games) {
                if (cancel != null && cancel.get()) break;
                if (!has(c, g[0])) {
                    if (p != null) p.on(done, total, found, g[2]);
                    if (download(c, g[0], g[1], g[2])) found++;
                }
                done++;
            }
            if (p != null) p.on(done, total, found, "");
        } finally {
            running.set(false);
        }
        return found;
    }
}
