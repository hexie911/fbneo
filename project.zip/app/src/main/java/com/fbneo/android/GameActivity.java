package com.fbneo.android;

import android.app.Dialog;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.libsdl.app.SDLActivity;

/** Runs FBNeo (libmain.so) through SDL and feeds it the controller with the user's mapping. */
public class GameActivity extends SDLActivity {
    private PadInput pad;
    private Dialog menu;
    private TouchPadView touch;
    private LinearLayout editBar;
    private android.widget.SeekBar sizeBar, alphaBar;
    private boolean syncing;

    private interface SliderCb { void on(int value, boolean fromUser); }

    private android.widget.SeekBar slider(final int min, final int max, int start, final SliderCb cb) {
        android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(start - min);
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s, int p, boolean user) {
                if (!syncing) cb.on(p + min, user);
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar s) { if (touch != null) touch.save(); }
        });
        return sb;
    }

    private void syncSliders(TouchPadView.El sel) {
        if (sizeBar == null || alphaBar == null) return;
        syncing = true;
        sizeBar.setEnabled(sel != null);
        alphaBar.setEnabled(sel != null);
        if (sel != null) {
            sizeBar.setProgress(Math.round(sel.size) - 40);
            float a = sel.alpha > 0 ? sel.alpha : (touch != null ? touch.globalAlpha() : 0.55f);
            alphaBar.setProgress(Math.round(a * 100) - 10);
        }
        syncing = false;
    }
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected String[] getLibraries() {
        return new String[]{"SDL2", "main"};
    }

    @Override
    protected String[] getArguments() {
        String[] a = getIntent().getStringArrayExtra("args");
        if (a == null) return new String[0];
        if (!Prefs.matchRefresh(this) || a.length == 0) return a;
        // aim the game at the screen's refresh rate (the last argument is the game name)
        float hz = lockedHz;
        try {
            if (hz <= 0) hz = getWindowManager().getDefaultDisplay().getRefreshRate();
        } catch (RuntimeException e) {
            hz = 0;
        }
        if (hz < 20 || hz > 250) return a;
        String[] b = new String[a.length + 2];
        System.arraycopy(a, 0, b, 0, a.length - 1);
        b[a.length - 1] = "-matchhz";
        b[a.length] = String.valueOf(Math.round(hz * 100));
        b[a.length + 1] = a[a.length - 1];
        return b;
    }

    private volatile float lockedHz = 0;
    private boolean hzLoop;
    private long hzStart;
    private int hzCount;

    /** Measures how often the screen really refreshes and tells the emulator (for the "Screen" counter). */
    private void startHzMeter() {
        if ((Prefs.counters(this) & 4) == 0 || hzLoop) return;
        hzLoop = true;
        hzStart = 0;
        hzCount = 0;
        try {
            final android.view.Choreographer ch = android.view.Choreographer.getInstance();
            ch.postFrameCallback(new android.view.Choreographer.FrameCallback() {
                @Override public void doFrame(long nanos) {
                    if (!hzLoop) return;
                    if (hzStart == 0) hzStart = nanos;
                    hzCount++;
                    long dt = nanos - hzStart;
                    if (dt >= 1_000_000_000L) {
                        try { Native.setDisplayHz(hzCount * 1e9f / dt); } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
                        hzStart = nanos;
                        hzCount = 0;
                    }
                    ch.postFrameCallback(this);
                }
            });
        } catch (RuntimeException e) {
            hzLoop = false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        PadInput.configure(this);
        pad = new PadInput(PadMap.load(this, 0), PadMap.load(this, 1), new PadInput.Sink() {
            @Override
            public void onAction(int slot, int action, boolean down) {
                if (action == Actions.MENU) {
                    if (down) showMenu();
                    return;
                }
                send(slot, action, down);
            }
        });
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        tunePerformance();
        if (Prefs.sustained(this) && Build.VERSION.SDK_INT >= 24) {
            try { getWindow().setSustainedPerformanceMode(true); } catch (RuntimeException e) { /* not supported */ }
        }
        setupTouch();
    }

    // ---- on-screen controls ------------------------------------------------------------

    private void setupTouch() {
        touch = new TouchPadView(this, new TouchPadView.Host() {
            @Override public void openMenu() { handler.post(new Runnable() { @Override public void run() { showMenu(); } }); }
            @Override public void editChanged(TouchPadView.El sel) { syncSliders(sel); }
        });
        addContentView(touch, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        editBar = Ui.vertical(this);
        editBar.setBackground(Ui.rounded(this, 0xE6171A21, 16));
        editBar.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 6));
        LinearLayout row1 = Ui.horizontal(this);
        row1.setGravity(Gravity.CENTER);
        row1.addView(Ui.button(this, "+ Button", Ui.TEXTONLY, v -> TouchEditor.addButton(this, touch)));
        row1.addView(Ui.button(this, "+ Macro", Ui.TEXTONLY, v -> TouchEditor.addMacro(this, touch)));
        TextView del = Ui.button(this, "Delete", Ui.TEXTONLY, v -> touch.deleteSelected());
        del.setTextColor(Ui.DANGER);
        row1.addView(del);
        row1.addView(Ui.button(this, "Reset", Ui.TEXTONLY, v -> touch.resetLayout()));
        row1.addView(Ui.button(this, "Done", Ui.FILLED, v -> endEdit()));
        editBar.addView(row1);
        LinearLayout row2 = Ui.horizontal(this);
        row2.setGravity(Gravity.CENTER_VERTICAL);
        sizeBar = slider(40, 260, 80, (val, user) -> { if (user) touch.setSelectedSize(val); });
        alphaBar = slider(10, 100, 55, (val, user) -> { if (user) touch.setSelectedAlpha(val / 100f); });
        row2.addView(Ui.text(this, "Size", 13, Ui.SUB, false));
        row2.addView(sizeBar, new LinearLayout.LayoutParams(Ui.dp(this, 170), ViewGroup.LayoutParams.WRAP_CONTENT));
        row2.addView(Ui.text(this, "Opacity", 13, Ui.SUB, false));
        row2.addView(alphaBar, new LinearLayout.LayoutParams(Ui.dp(this, 170), ViewGroup.LayoutParams.WRAP_CONTENT));
        editBar.addView(row2);
        LinearLayout row3 = Ui.horizontal(this);
        row3.setGravity(Gravity.CENTER);
        final int[] blends = {0, 60, 80, 100};
        final TextView blendBtn = Ui.button(this, "", Ui.TONAL, null);
        blendBtn.setText(blendText());
        blendBtn.setOnClickListener(v -> {
            int cur = Prefs.touchBlend(this), n = 0;
            for (int i = 0; i < blends.length; i++) if (blends[i] == cur) n = (i + 1) % blends.length;
            Prefs.put(this, "touchBlend", blends[n]);
            touch.setBlend(blends[n]);
            blendBtn.setText(blendText());
        });
        row3.addView(blendBtn);
        final TextView stickBtn = Ui.button(this, "", Ui.TONAL, null);
        stickBtn.setText(stickText());
        stickBtn.setOnClickListener(v -> {
            boolean on = !Prefs.smoothStick(this);
            Prefs.put(this, "smoothStick", on);
            touch.setSmoothStick(on);
            stickBtn.setText(stickText());
        });
        row3.addView(stickBtn, Ui.wrapMargins(this, 0, 6, 0, 0));
        editBar.addView(row3);
        syncSliders(null);
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = Ui.dp(this, 6);
        addContentView(editBar, lp);
        editBar.setVisibility(View.GONE);
        applyTouchVisibility();
    }

    private String blendText() {
        int b = Prefs.touchBlend(this);
        return "Multi-touch between buttons: " + (b == 0 ? "Off" : b + "%");
    }

    private String stickText() {
        return "Smooth stick: " + (Prefs.smoothStick(this) ? "On" : "Off (8 directions)");
    }

    private void applyTouchVisibility() {
        if (touch == null) return;
        boolean on = Prefs.touchOn(this);
        touch.setVisibility(on ? View.VISIBLE : View.GONE);
        touch.setAlphaLevel(Prefs.touchAlpha(this));
        if (!on) touch.releaseAllTouch();
    }

    private void startEdit() {
        Prefs.put(this, "touchOn", true);
        applyTouchVisibility();
        touch.setEdit(true);
        try { Native.setPaused(true); } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
        editBar.setVisibility(View.VISIBLE);
    }

    private void endEdit() {
        touch.setEdit(false);
        try { Native.setPaused(false); } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
        touch.save();
        editBar.setVisibility(View.GONE);
    }

    private static void send(int slot, int action, boolean down) {
        try {
            Native.setAction(slot, action, down);
        } catch (UnsatisfiedLinkError | RuntimeException e) {
            // native library not ready yet
        }
    }

    /** Run an emulator action once. Goes through a command queue so it is never missed while the game is paused. */
    private void pulse(final int action) {
        try {
            Native.command(action);
        } catch (UnsatisfiedLinkError | RuntimeException e) {
            // native library not ready yet
        }
    }

    // ---- performance -------------------------------------------------------------------

    private void tunePerformance() {
        if (Prefs.match60(this)) {
            try {
                Display d = getWindowManager().getDefaultDisplay();
                Display.Mode cur = d.getMode();
                Display.Mode best = null;
                for (Display.Mode m : d.getSupportedModes()) {
                    if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight()
                            && Math.abs(m.getRefreshRate() - 60f) < 1.5f) {
                        best = m;
                    }
                }
                if (best != null) lockedHz = best.getRefreshRate();
                if (best != null && best.getModeId() != cur.getModeId()) {
                    WindowManager.LayoutParams lp = getWindow().getAttributes();
                    lp.preferredDisplayModeId = best.getModeId();
                    getWindow().setAttributes(lp);
                }
            } catch (RuntimeException e) {
                // optional
            }
        }
    }

    /** Tell the system compositor this surface is a fixed 60 fps source (Android 11+). */
    private void hintFrameRate() {
        if (Build.VERSION.SDK_INT < 30 || mSurface == null) return;
        try {
            Surface s = mSurface.getHolder().getSurface();
            if (s != null && s.isValid()) {
                s.setFrameRate(60f, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE);
            }
        } catch (RuntimeException e) {
            // optional
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        try { Native.videoThreadHold(false); } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
        startHzMeter();
        handler.postDelayed(new Runnable() {
            @Override public void run() { hintFrameRate(); }
        }, 800);
    }

    // ---- pause menu --------------------------------------------------------------------

    private View menuButton(String label, int style, final Runnable action) {
        TextView b = Ui.button(this, label, style, v -> {
            if (menu != null) menu.dismiss();
            if (action != null) action.run();
        });
        b.setLayoutParams(Ui.fillMargins(this, 0, 5, 0, 5));
        return b;
    }

    private void chooseShape() {
        String[] names = new String[Prefs.ASPECTS.length];
        for (int i = 0; i < names.length; i++) names[i] = Prefs.ASPECTS[i][0];
        Dialogs.choose(this, "Screen shape", names, Prefs.aspect(this), w -> {
            Prefs.put(this, "aspect", w);
            int[] v = Prefs.aspectValues(w);
            try {
                Native.setAspect(v[0], v[1]);
            } catch (UnsatisfiedLinkError | RuntimeException e) {
                // native library not ready
            }
        });
    }

    private View pairRow(View left, View right) {
        LinearLayout row = Ui.horizontal(this);
        row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = Ui.dp(this, 10);
        row.addView(right, lp);
        row.setLayoutParams(Ui.fillMargins(this, 0, 5, 0, 5));
        return row;
    }

    private String romName() {
        String[] a = getIntent().getStringArrayExtra("args");
        return a != null && a.length > 0 ? a[a.length - 1] : "game";
    }

    private void showMenu() {
        if (menu != null && menu.isShowing()) return;
        if (pad != null) pad.releaseAll();
        if (touch != null) touch.releaseAllTouch();
        final LinearLayout[] h = new LinearLayout[1];
        menu = Dialogs.base(this, h);
        LinearLayout card = h[0];
        TextView t = Ui.text(this, "Paused", 22, Ui.TEXT, true);
        t.setPadding(0, 0, 0, Ui.dp(this, 12));
        card.addView(t);
        card.addView(menuButton("Resume", Ui.FILLED, null));
        card.addView(Ui.switchRow(this, "On-screen controls", "Stick, buttons and macros on the screen", Prefs.touchOn(this), (v, on) -> {
            Prefs.put(this, "touchOn", on);
            applyTouchVisibility();
        }), Ui.fillMargins(this, 0, 5, 0, 5));
        ((LinearLayout.LayoutParams) card.getChildAt(card.getChildCount() - 1).getLayoutParams()).setMargins(0, Ui.dp(this, 5), 0, Ui.dp(this, 5));
        card.addView(menuButton("Edit on-screen controls", Ui.TONAL, this::startEdit));
        LinearLayout two = Ui.horizontal(this);
        TextView save = Ui.button(this, "Save state", Ui.TONAL, v -> { menu.dismiss(); pulse(Actions.SAVE); });
        TextView load = Ui.button(this, "Load state", Ui.TONAL, v -> { menu.dismiss(); pulse(Actions.LOAD); });
        two.addView(save, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = Ui.dp(this, 10);
        two.addView(load, lp);
        card.addView(two, Ui.fillMargins(this, 0, 5, 0, 5));
        card.addView(pairRow(
                Ui.button(this, "DIP switches", Ui.TONAL, v -> { menu.dismiss(); DipDialog.show(GameActivity.this); }),
                Ui.button(this, "Screen shape", Ui.TONAL, v -> { menu.dismiss(); chooseShape(); })));
        boolean svc = false;
        try { svc = Native.serviceOn(); } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
        card.addView(pairRow(
                Ui.button(this, svc ? "Service: ON" : "Service (test menu)", Ui.TONAL, v -> {
                    menu.dismiss();
                    try { Native.toggleService(); } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
                }),
                Ui.button(this, "Cheats", Ui.TONAL, v -> { menu.dismiss(); CheatDialog.show(GameActivity.this, romName()); })));
        String netState = "idle";
        try { netState = Native.netStatus().split("\\|", 2)[0]; } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
        card.addView(menuButton(netState.equals("run") ? "Local multiplayer (connected)" : "Local multiplayer", Ui.TONAL,
                () -> NetDialog.show(GameActivity.this, romName())));
        card.addView(pairRow(
                Ui.button(this, "Swap P1 / P2", Ui.TONAL, v -> { menu.dismiss(); pulse(Actions.SWAP); }),
                Ui.button(this, "Reset game", Ui.TONAL, v -> { menu.dismiss(); pulse(Actions.RESET); })));
        TextView quit = Ui.button(this, "Quit game", Ui.TEXTONLY, v -> {
            menu.dismiss();
            pulse(Actions.QUIT);
        });
        quit.setTextColor(Ui.DANGER);
        quit.setLayoutParams(Ui.fillMargins(this, 0, 5, 0, 0));
        card.addView(quit);
        menu.show();
    }

    // ---- input -------------------------------------------------------------------------

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (menu != null && menu.isShowing()) return super.dispatchKeyEvent(event);
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (event.getAction() == KeyEvent.ACTION_UP) showMenu();
            return true;
        }
        if (pad != null && pad.onKey(event)) return true;
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        if (menu != null && menu.isShowing()) return super.dispatchGenericMotionEvent(ev);
        if (pad != null && pad.onMotion(ev)) return true;
        return super.dispatchGenericMotionEvent(ev);
    }

    @Override
    public void onBackPressed() {
        showMenu();
    }

    @Override
    protected void onPause() {
        hzLoop = false;
        if (pad != null) pad.releaseAll();
        try { Native.videoThreadHold(true); } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // The emulator keeps global state: always start the next game in a fresh process.
        Process.killProcess(Process.myPid());
    }
}
