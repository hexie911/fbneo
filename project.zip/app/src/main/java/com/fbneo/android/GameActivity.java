package com.fbneo.android;

import android.app.Dialog;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.libsdl.app.SDLActivity;

/** Runs FBNeo (libmain.so) through SDL and feeds it the controller with the user's mapping. */
public class GameActivity extends SDLActivity {
    private PadInput pad;
    private Dialog menu;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected String[] getLibraries() {
        return new String[]{"SDL2", "main"};
    }

    @Override
    protected String[] getArguments() {
        String[] a = getIntent().getStringArrayExtra("args");
        return a != null ? a : new String[0];
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        PadInput.configure(this);
        pad = new PadInput(PadMap.load(this), new PadInput.Sink() {
            @Override
            public void onAction(int slot, int action, boolean down) {
                if (action == Actions.MENU) {
                    if (down) showMenu();
                    return;
                }
                send(slot, action, down);
            }
        });
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        tunePerformance();
    }

    private static void send(int slot, int action, boolean down) {
        try {
            Native.setAction(slot, action, down);
        } catch (UnsatisfiedLinkError | RuntimeException e) {
            // native library not ready yet
        }
    }

    /** Press and release an emulator action once (the emulator looks for the rising edge). */
    private void pulse(final int action) {
        handler.postDelayed(new Runnable() {
            @Override public void run() {
                send(0, action, true);
                handler.postDelayed(new Runnable() {
                    @Override public void run() { send(0, action, false); }
                }, 120);
            }
        }, 250);
    }

    // ---- performance -------------------------------------------------------------------

    private void tunePerformance() {
        if (Prefs.match60(this)) {
            try {
                Display d = getWindowManager().getDefaultDisplay();
                Display.Mode cur = d.getMode();
                Display.Mode best = null;
                for (Display.Mode m : d.getSupportedModes()) {
                    if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight()
                            && Math.abs(m.getRefreshRate() - 60f) < 1.5f) {
                        best = m;
                    }
                }
                if (best != null && best.getModeId() != cur.getModeId()) {
                    WindowManager.LayoutParams lp = getWindow().getAttributes();
                    lp.preferredDisplayModeId = best.getModeId();
                    getWindow().setAttributes(lp);
                }
            } catch (RuntimeException e) {
                // optional
            }
        }
    }

    /** Tell the system compositor this surface is a fixed 60 fps source (Android 11+). */
    private void hintFrameRate() {
        if (Build.VERSION.SDK_INT < 30 || mSurface == null) return;
        try {
            Surface s = mSurface.getHolder().getSurface();
            if (s != null && s.isValid()) {
                s.setFrameRate(60f, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE);
            }
        } catch (RuntimeException e) {
            // optional
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.postDelayed(new Runnable() {
            @Override public void run() { hintFrameRate(); }
        }, 800);
    }

    // ---- pause menu --------------------------------------------------------------------

    private View menuButton(String label, int style, final Runnable action) {
        TextView b = Ui.button(this, label, style, v -> {
            if (menu != null) menu.dismiss();
            if (action != null) action.run();
        });
        b.setLayoutParams(Ui.fillMargins(this, 0, 5, 0, 5));
        return b;
    }

    private void chooseShape() {
        String[] names = new String[Prefs.ASPECTS.length];
        for (int i = 0; i < names.length; i++) names[i] = Prefs.ASPECTS[i][0];
        Dialogs.choose(this, "Screen shape", names, Prefs.aspect(this), w -> {
            Prefs.put(this, "aspect", w);
            int[] v = Prefs.aspectValues(w);
            try {
                Native.setAspect(v[0], v[1]);
            } catch (UnsatisfiedLinkError | RuntimeException e) {
                // native library not ready
            }
        });
    }

    private View pairRow(View left, View right) {
        LinearLayout row = Ui.horizontal(this);
        row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = Ui.dp(this, 10);
        row.addView(right, lp);
        row.setLayoutParams(Ui.fillMargins(this, 0, 5, 0, 5));
        return row;
    }

    private String romName() {
        String[] a = getIntent().getStringArrayExtra("args");
        return a != null && a.length > 0 ? a[a.length - 1] : "game";
    }

    private void showMenu() {
        if (menu != null && menu.isShowing()) return;
        if (pad != null) pad.releaseAll();
        final LinearLayout[] h = new LinearLayout[1];
        menu = Dialogs.base(this, h);
        LinearLayout card = h[0];
        TextView t = Ui.text(this, "Paused", 22, Ui.TEXT, true);
        t.setPadding(0, 0, 0, Ui.dp(this, 12));
        card.addView(t);
        card.addView(menuButton("Resume", Ui.FILLED, null));
        LinearLayout two = Ui.horizontal(this);
        TextView save = Ui.button(this, "Save state", Ui.TONAL, v -> { menu.dismiss(); pulse(Actions.SAVE); });
        TextView load = Ui.button(this, "Load state", Ui.TONAL, v -> { menu.dismiss(); pulse(Actions.LOAD); });
        two.addView(save, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = Ui.dp(this, 10);
        two.addView(load, lp);
        card.addView(two, Ui.fillMargins(this, 0, 5, 0, 5));
        card.addView(pairRow(
                Ui.button(this, "DIP switches", Ui.TONAL, v -> { menu.dismiss(); DipDialog.show(GameActivity.this); }),
                Ui.button(this, "Screen shape", Ui.TONAL, v -> { menu.dismiss(); chooseShape(); })));
        boolean svc = false;
        try { svc = Native.serviceOn(); } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
        card.addView(pairRow(
                Ui.button(this, svc ? "Service: ON" : "Service (test menu)", Ui.TONAL, v -> {
                    menu.dismiss();
                    try { Native.toggleService(); } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
                }),
                Ui.button(this, "Cheats", Ui.TONAL, v -> { menu.dismiss(); CheatDialog.show(GameActivity.this, romName()); })));
        card.addView(pairRow(
                Ui.button(this, "Swap P1 / P2", Ui.TONAL, v -> { menu.dismiss(); pulse(Actions.SWAP); }),
                Ui.button(this, "Reset game", Ui.TONAL, v -> { menu.dismiss(); pulse(Actions.RESET); })));
        TextView quit = Ui.button(this, "Quit game", Ui.TEXTONLY, v -> {
            menu.dismiss();
            pulse(Actions.QUIT);
        });
        quit.setTextColor(Ui.DANGER);
        quit.setLayoutParams(Ui.fillMargins(this, 0, 5, 0, 0));
        card.addView(quit);
        menu.show();
    }

    // ---- input -------------------------------------------------------------------------

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (menu != null && menu.isShowing()) return super.dispatchKeyEvent(event);
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (event.getAction() == KeyEvent.ACTION_UP) showMenu();
            return true;
        }
        if (pad != null && pad.onKey(event)) return true;
        return super.dispatchKeyEvent(event);
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        if (menu != null && menu.isShowing()) return super.dispatchGenericMotionEvent(ev);
        if (pad != null && pad.onMotion(ev)) return true;
        return super.dispatchGenericMotionEvent(ev);
    }

    @Override
    public void onBackPressed() {
        showMenu();
    }

    @Override
    protected void onPause() {
        if (pad != null) pad.releaseAll();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // The emulator keeps global state: always start the next game in a fresh process.
        Process.killProcess(Process.myPid());
    }
}
