package com.fbneo.android;

import android.content.Context;
import android.view.KeyEvent;
import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.List;

/** Which controller buttons / axes trigger which action. Stored as one text line in the settings. */
final class PadMap {
    static final class Binding {
        final boolean axis;
        final int code;   // key code or axis number
        final int dir;    // axis only: +1 / -1

        Binding(boolean axis, int code, int dir) {
            this.axis = axis;
            this.code = code;
            this.dir = dir;
        }

        static Binding key(int code) { return new Binding(false, code, 0); }
        static Binding axis(int axis, int dir) { return new Binding(true, axis, dir); }

        String serialize() { return axis ? "a" + code + (dir > 0 ? "+" : "-") : "k" + code; }

        static Binding parse(String s) {
            try {
                if (s.startsWith("k")) return key(Integer.parseInt(s.substring(1)));
                if (s.startsWith("a")) {
                    char d = s.charAt(s.length() - 1);
                    return axis(Integer.parseInt(s.substring(1, s.length() - 1)), d == '+' ? 1 : -1);
                }
            } catch (RuntimeException e) { /* fall through */ }
            return null;
        }

        String describe() {
            if (!axis) return keyName(code);
            return axisName(code) + (dir > 0 ? " +" : " −");
        }
    }

    /** One controller button that presses several game actions at once (for example LP + LK). */
    static final class Macro {
        String name = "Macro";
        int[] actions = new int[0];
        final List<Binding> binds = new ArrayList<>();

        String actionsText() {
            StringBuilder sb = new StringBuilder();
            for (int a : actions) {
                if (sb.length() > 0) sb.append(" + ");
                sb.append(TouchEditor.shortName(a));
            }
            return sb.toString();
        }
    }

    final List<Macro> macros = new ArrayList<>();

    private final List<List<Binding>> map = new ArrayList<>();

    PadMap() {
        for (int i = 0; i < Actions.COUNT; i++) map.add(new ArrayList<Binding>());
    }

    List<Binding> get(int action) { return map.get(action); }

    void set(int action, List<Binding> b) {
        map.set(action, new ArrayList<>(b));
    }

    private void dropKey(int action, int keyCode) {
        List<Binding> l = map.get(action);
        for (int i = l.size() - 1; i >= 0; i--) {
            if (!l.get(i).axis && l.get(i).code == keyCode) l.remove(i);
        }
    }

    private void add(int action, Binding... b) {
        for (Binding x : b) map.get(action).add(x);
    }

    /** Defaults for a DualShock 4 / Xbox style pad as Android reports it, using the layout asked for. */
    static PadMap defaults() {
        PadMap m = new PadMap();
        m.add(Actions.UP, Binding.key(KeyEvent.KEYCODE_DPAD_UP), Binding.axis(MotionEvent.AXIS_HAT_Y, -1), Binding.axis(MotionEvent.AXIS_Y, -1));
        m.add(Actions.DOWN, Binding.key(KeyEvent.KEYCODE_DPAD_DOWN), Binding.axis(MotionEvent.AXIS_HAT_Y, 1), Binding.axis(MotionEvent.AXIS_Y, 1));
        m.add(Actions.LEFT, Binding.key(KeyEvent.KEYCODE_DPAD_LEFT), Binding.axis(MotionEvent.AXIS_HAT_X, -1), Binding.axis(MotionEvent.AXIS_X, -1));
        m.add(Actions.RIGHT, Binding.key(KeyEvent.KEYCODE_DPAD_RIGHT), Binding.axis(MotionEvent.AXIS_HAT_X, 1), Binding.axis(MotionEvent.AXIS_X, 1));
        m.add(Actions.FIRE1, Binding.key(KeyEvent.KEYCODE_BUTTON_X));   // Square   = LP
        m.add(Actions.FIRE2, Binding.key(KeyEvent.KEYCODE_BUTTON_Y));   // Triangle = MP
        m.add(Actions.FIRE3, Binding.key(KeyEvent.KEYCODE_BUTTON_R1));  // R1       = HP
        m.add(Actions.FIRE4, Binding.key(KeyEvent.KEYCODE_BUTTON_A));   // Cross    = LK
        m.add(Actions.FIRE5, Binding.key(KeyEvent.KEYCODE_BUTTON_B));   // Circle   = MK
        m.add(Actions.FIRE6, Binding.key(KeyEvent.KEYCODE_BUTTON_R2), Binding.axis(MotionEvent.AXIS_RTRIGGER, 1), Binding.axis(MotionEvent.AXIS_GAS, 1)); // R2 = HK
        m.add(Actions.COIN, Binding.key(KeyEvent.KEYCODE_BUTTON_SELECT)); // Share
        m.add(Actions.START, Binding.key(KeyEvent.KEYCODE_BUTTON_START)); // Options
        m.add(Actions.MENU, Binding.key(KeyEvent.KEYCODE_BUTTON_MODE));   // PS button = pause menu
        m.add(Actions.HK1, Binding.key(KeyEvent.KEYCODE_BUTTON_L1));
        m.add(Actions.HK1 + 1, Binding.key(KeyEvent.KEYCODE_BUTTON_L2), Binding.axis(MotionEvent.AXIS_LTRIGGER, 1), Binding.axis(MotionEvent.AXIS_BRAKE, 1));
        // L3 and R3 are left empty
        return m;
    }

    String serialize() {
        StringBuilder sb = new StringBuilder();
        for (int a = 0; a < Actions.COUNT; a++) {
            List<Binding> l = map.get(a);
            if (l.isEmpty()) continue;
            sb.append(Actions.key(a)).append('=');
            for (int i = 0; i < l.size(); i++) {
                if (i > 0) sb.append(',');
                sb.append(l.get(i).serialize());
            }
            sb.append(';');
        }
        return sb.toString();
    }

    static PadMap parse(String s) {
        PadMap m = new PadMap();
        for (String part : s.split(";")) {
            int eq = part.indexOf('=');
            if (eq < 0) continue;
            int a = Actions.fromKey(part.substring(0, eq));
            if (a < 0) continue;
            for (String b : part.substring(eq + 1).split(",")) {
                Binding x = Binding.parse(b.trim());
                if (x != null) m.map.get(a).add(x);
            }
        }
        return m;
    }

    /** Player 2's default: the same layout, but only the player controls (no emulator shortcuts twice). */
    static PadMap defaults2() {
        PadMap d = defaults();
        PadMap m = new PadMap();
        for (int a : Actions.PLAYER) m.map.set(a, new ArrayList<>(d.map.get(a)));
        return m;
    }

    static PadMap load(Context c) { return load(c, 0); }

    private static void loadMacros(Context c, int player, PadMap m) {
        try {
            String s = Prefs.sp(c).getString("macros" + player, "");
            if (s.length() == 0) return;
            org.json.JSONArray arr = new org.json.JSONArray(s);
            for (int i = 0; i < arr.length(); i++) {
                org.json.JSONObject o = arr.getJSONObject(i);
                Macro mc = new Macro();
                mc.name = o.optString("n", "Macro");
                org.json.JSONArray a = o.getJSONArray("a");
                mc.actions = new int[a.length()];
                for (int k = 0; k < mc.actions.length; k++) mc.actions[k] = a.getInt(k);
                org.json.JSONArray bs = o.optJSONArray("b");
                if (bs != null) for (int k = 0; k < bs.length(); k++) {
                    Binding bd = Binding.parse(bs.getString(k));
                    if (bd != null) mc.binds.add(bd);
                }
                m.macros.add(mc);
            }
        } catch (Exception e) {
            m.macros.clear();
        }
    }

    private void saveMacros(Context c, int player) {
        try {
            org.json.JSONArray arr = new org.json.JSONArray();
            for (Macro mc : macros) {
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("n", mc.name);
                org.json.JSONArray a = new org.json.JSONArray();
                for (int v : mc.actions) a.put(v);
                o.put("a", a);
                org.json.JSONArray bs = new org.json.JSONArray();
                for (Binding bd : mc.binds) bs.put(bd.serialize());
                o.put("b", bs);
                arr.put(o);
            }
            Prefs.put(c, "macros" + player, arr.toString());
        } catch (Exception e) {
            // keep the old ones
        }
    }

    /** player 0 = the first controller (also keyboard), 1 = the second controller. */
    static PadMap load(Context c, int player) {
        String s = Prefs.sp(c).getString(player == 0 ? "padmap" : "padmap2", null);
        PadMap m = s == null ? (player == 0 ? defaults() : defaults2()) : parse(s);
        if (s != null && Prefs.sp(c).getInt("padmapVer" + player, 1) < 2) {
            // old defaults: PS button swapped players, L3 paused and R3 fast-forwarded. Only those untouched
            // defaults are changed; anything the player mapped by hand stays.
            m.dropKey(Actions.SWAP, KeyEvent.KEYCODE_BUTTON_MODE);
            m.dropKey(Actions.PAUSE, KeyEvent.KEYCODE_BUTTON_THUMBL);
            m.dropKey(Actions.FFWD, KeyEvent.KEYCODE_BUTTON_THUMBR);
            if (player == 0 && m.get(Actions.MENU).isEmpty()) m.add(Actions.MENU, Binding.key(KeyEvent.KEYCODE_BUTTON_MODE));
            Prefs.put(c, player == 0 ? "padmap" : "padmap2", m.serialize());
            Prefs.put(c, "padmapVer" + player, 2);
        }
        loadMacros(c, player, m);
        return m;
    }

    void save(Context c) { save(c, 0); }

    void save(Context c, int player) {
        Prefs.put(c, player == 0 ? "padmap" : "padmap2", serialize());
        saveMacros(c, player);
    }

    String describe(int action) {
        List<Binding> l = map.get(action);
        if (l.isEmpty()) return "not set";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append("  ·  ");
            sb.append(l.get(i).describe());
        }
        return sb.toString();
    }

    static String keyName(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_BUTTON_A: return "Cross (A)";
            case KeyEvent.KEYCODE_BUTTON_B: return "Circle (B)";
            case KeyEvent.KEYCODE_BUTTON_X: return "Square (X)";
            case KeyEvent.KEYCODE_BUTTON_Y: return "Triangle (Y)";
            case KeyEvent.KEYCODE_BUTTON_L1: return "L1";
            case KeyEvent.KEYCODE_BUTTON_R1: return "R1";
            case KeyEvent.KEYCODE_BUTTON_L2: return "L2";
            case KeyEvent.KEYCODE_BUTTON_R2: return "R2";
            case KeyEvent.KEYCODE_BUTTON_THUMBL: return "L3";
            case KeyEvent.KEYCODE_BUTTON_THUMBR: return "R3";
            case KeyEvent.KEYCODE_BUTTON_START: return "Options (Start)";
            case KeyEvent.KEYCODE_BUTTON_SELECT: return "Share (Select)";
            case KeyEvent.KEYCODE_BUTTON_MODE: return "PS button (Mode)";
            case KeyEvent.KEYCODE_DPAD_UP: return "D-pad up";
            case KeyEvent.KEYCODE_DPAD_DOWN: return "D-pad down";
            case KeyEvent.KEYCODE_DPAD_LEFT: return "D-pad left";
            case KeyEvent.KEYCODE_DPAD_RIGHT: return "D-pad right";
            default:
                String s = KeyEvent.keyCodeToString(k);
                return s.startsWith("KEYCODE_") ? s.substring(8) : s;
        }
    }

    static String axisName(int a) {
        switch (a) {
            case MotionEvent.AXIS_X: return "Left stick X";
            case MotionEvent.AXIS_Y: return "Left stick Y";
            case MotionEvent.AXIS_Z: return "Right stick X";
            case MotionEvent.AXIS_RZ: return "Right stick Y";
            case MotionEvent.AXIS_HAT_X: return "D-pad X";
            case MotionEvent.AXIS_HAT_Y: return "D-pad Y";
            case MotionEvent.AXIS_LTRIGGER: return "L2 trigger";
            case MotionEvent.AXIS_RTRIGGER: return "R2 trigger";
            case MotionEvent.AXIS_BRAKE: return "L2 (brake)";
            case MotionEvent.AXIS_GAS: return "R2 (gas)";
            default: return MotionEvent.axisToString(a);
        }
    }
}
