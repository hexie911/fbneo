package com.fbneo.android;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** The MAME section: its own ROM folder and list, core download, and a way to start a game. */
public class MameLauncherActivity extends Activity {
    private static final int REQ_DIR = 1, REQ_CORE = 2;

    static final class Item { String name, title, sub; }

    private final List<Item> all = new ArrayList<>(), shown = new ArrayList<>();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout coreRow, dirRow;
    private TextView empty;
    private BaseAdapter adapter;
    private String query = "";
    private volatile boolean busy;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);
        root.addView(Ui.topBar(this, "MAME", this::finish));

        coreRow = Ui.row(this, "", null, v -> coreMenu());
        root.addView(coreRow);
        dirRow = Ui.row(this, Icons.FOLDER, "ROM folder", Prefs.mameDir(this), v -> {
            Intent i = new Intent(this, FileBrowserActivity.class);
            i.putExtra("mode", "folder");
            i.putExtra("start", Prefs.mameDir(this));
            i.putExtra("title", "MAME ROM folder");
            startActivityForResult(i, REQ_DIR);
        });
        root.addView(dirRow);
        root.addView(Ui.row(this, "Last game log", "Show what the core said during the last run", v -> {
            String t = "";
            try {
                File f = MameActivity.logFile(this);
                if (f.isFile()) t = new String(java.nio.file.Files.readAllBytes(f.toPath()), "UTF-8");
            } catch (Exception e) { t = String.valueOf(e); }
            if (t.length() > 20000) t = t.substring(t.length() - 20000);
            Dialogs.log(this, t);
        }));

        EditText search = new EditText(this);
        search.setHint("Search");
        search.setHintTextColor(Ui.SUB);
        search.setTextColor(Ui.TEXT);
        search.setSingleLine(true);
        search.setBackground(Ui.rounded(this, Ui.SURFACE, 16));
        search.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void afterTextChanged(Editable e) { query = e.toString().trim().toLowerCase(Locale.ROOT); filter(); }
        });
        root.addView(search, Ui.fillMargins(this, 16, 8, 16, 8));

        empty = Ui.text(this, "", 14, Ui.SUB, false);
        empty.setGravity(android.view.Gravity.CENTER);
        empty.setPadding(Ui.dp(this, 24), Ui.dp(this, 24), Ui.dp(this, 24), 0);
        root.addView(empty);

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setSelector(android.R.color.transparent);
        adapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View v, ViewGroup p) {
                Item it = shown.get(i);
                LinearLayout r = Ui.row(MameLauncherActivity.this, it.title, it.sub, x -> play(it));
                return r;
            }
        };
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        refreshCore();
        scan();
    }

    private void refreshCore() {
        String id = MameCore.current(this);
        File f = MameCore.file(this, id);
        String name = "custom".equals(id) ? "Custom core file" : id;
        for (int i = 0; i < MameCore.IDS.length; i++) if (MameCore.IDS[i].equals(id)) name = MameCore.NAMES[i];
        ((TextView) coreRow.findViewWithTag("title")).setText(f != null ? "Core: installed" : "Core: not installed");
        Ui.setSub(coreRow, name + (f == null ? "\nTap to download" : "\nTap to change or update"));
    }

    private void coreMenu() {
        if (busy) return;
        String[] o = new String[MameCore.NAMES.length + 1];
        System.arraycopy(MameCore.NAMES, 0, o, 0, MameCore.NAMES.length);
        o[o.length - 1] = "Use a core file from this device...";
        Dialogs.choose(this, "MAME core", o, -1, i -> {
            if (i == o.length - 1) {
                Intent it = new Intent(this, FileBrowserActivity.class);
                it.putExtra("mode", "file");
                it.putExtra("ext", ".so");
                it.putExtra("start", Prefs.mameDir(this));
                it.putExtra("title", "Choose a libretro core (.so)");
                startActivityForResult(it, REQ_CORE);
                return;
            }
            final String id = MameCore.IDS[i];
            MameCore.setCurrent(this, id);
            busy = true;
            Ui.setSub(coreRow, "Starting download...");
            new Thread(() -> {
                String err = null;
                try {
                    MameCore.download(this, id, t -> ui.post(() -> Ui.setSub(coreRow, t)));
                } catch (Exception e) {
                    err = String.valueOf(e.getMessage());
                }
                final String er = err;
                ui.post(() -> {
                    busy = false;
                    refreshCore();
                    if (er != null) {
                        Dialogs.message(this, "Download failed", Collections.singletonList(er
                                + "\n\nYou can also download the core on another device (libretro buildbot, Android arm64-v8a) "
                                + "and pick the .so file with \"Use a core file from this device\"."), "OK", null, null, null);
                    }
                });
            }).start();
        });
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        if (res != RESULT_OK || d == null || d.getStringExtra("path") == null) return;
        if (req == REQ_DIR) {
            Prefs.put(this, "mameDir", d.getStringExtra("path"));
            Ui.setSub(dirRow, Prefs.mameDir(this));
            scan();
        } else if (req == REQ_CORE) {
            try {
                MameCore.useFile(this, new File(d.getStringExtra("path")));
                refreshCore();
            } catch (Exception e) {
                Ui.toast(this, "Could not use that file: " + e.getMessage());
            }
        }
    }

    private void scan() {
        final String dir = Prefs.mameDir(this);
        new Thread(() -> {
            List<Item> out = new ArrayList<>();
            Map<String, MameGames.Info> known = MameGames.get(this);
            File[] fs = new File(dir).listFiles();
            if (fs != null) {
                for (File f : fs) {
                    String n = f.getName();
                    if (!f.isFile() || !n.toLowerCase(Locale.ROOT).endsWith(".zip")) continue;
                    String base = n.substring(0, n.length() - 4);
                    Item it = new Item();
                    it.name = base;
                    MameGames.Info k = known.get(base.toLowerCase(Locale.ROOT));
                    if (k != null) {
                        it.title = k.title;
                        it.sub = base + "  " + k.year + "  " + k.maker;
                    } else {
                        it.title = base;
                        it.sub = "Not in the 2003-Plus list - the current MAME core may still know it";
                    }
                    // device and BIOS archives are not games; keep them out when we know about them
                    if (k != null && !k.runnable) continue;
                    out.add(it);
                }
            }
            Collections.sort(out, (a, b) -> a.title.compareToIgnoreCase(b.title));
            ui.post(() -> {
                all.clear();
                all.addAll(out);
                filter();
            });
        }).start();
    }

    private void filter() {
        shown.clear();
        for (Item i : all) if (query.isEmpty() || i.title.toLowerCase(Locale.ROOT).contains(query) || i.name.contains(query)) shown.add(i);
        adapter.notifyDataSetChanged();
        if (all.isEmpty()) {
            empty.setText("No ROM zips found in\n" + Prefs.mameDir(this)
                    + "\n\nPut MAME ROM zips there (for example tekken3.zip, with its BIOS) or choose another folder.");
            empty.setVisibility(View.VISIBLE);
        } else {
            empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
            if (shown.isEmpty()) empty.setText("Nothing matches your search.");
        }
    }

    private void play(Item it) {
        if (!MameCore.installed(this)) {
            Ui.toast(this, "Download a MAME core first");
            coreMenu();
            return;
        }
        if (!Prefs.hasAccess(this)) { Prefs.requestAccess(this); return; }
        Intent i = new Intent(this, MameActivity.class);
        i.putExtra("rom", it.name);
        i.putExtra("path", Prefs.mameDir(this) + it.name + ".zip");
        startActivity(i);
    }
}
