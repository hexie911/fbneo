package com.fbneo.android;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** The MAME section: its own ROM folder and list, core download, and a way to start a game. */
public class MameLauncherActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Lang.wrap(base));
    }

    private static final int REQ_DIR = 1, REQ_CORE = 2;

    static final class Item { String name, title, sub; }

    private final List<Item> all = new ArrayList<>(), shown = new ArrayList<>();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView empty;
    private BaseAdapter adapter;
    private String query = "";
    private volatile boolean busy;

    private LinearLayout chipHolder;
    private TextView coreTitle, coreSub;
    private android.widget.GridView grid;
    private final int builtTheme = Ui.themeVersion;
    private View searchBar, coreBtn, romBtn, ctlBtn, logBtn;
    private EditText searchField;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.migrateLayout(this);
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);

        final boolean land = getResources().getDisplayMetrics().widthPixels > getResources().getDisplayMetrics().heightPixels;
        final LinearLayout hdr = Ui.vertical(this);
        root.addView(hdr);
        LinearLayout top = Ui.horizontal(this);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this, 8), Ui.dp(this, land ? 2 : 8), Ui.dp(this, 10), Ui.dp(this, 2));
        top.addView(Ui.iconButton(this, Icons.BACK, Lang.t("Back"), v -> finish()));
        LinearLayout titles = Ui.vertical(this);
        titles.setPadding(Ui.dp(this, 14), 0, 0, 0);
        titles.addView(Ui.text(this, "MAME", land ? 20 : 24, Ui.TEXT, true));
        TextView sub = Ui.text(this, Lang.t("Arcade games through a libretro core"), 12, Ui.SUB, false);
        sub.setPadding(0, Ui.dp(this, 2), 0, 0);
        titles.addView(sub);
        top.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(Ui.iconButton(this, Icons.MORE, Lang.t("Menu"), v -> openSide()));
        hdr.addView(top);

        // core card
        LinearLayout cc = Ui.card(this, Ui.SURFACE, 22);
        cc.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
        LinearLayout head = Ui.horizontal(this);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout col = Ui.vertical(this);
        chipHolder = Ui.horizontal(this);
        col.addView(chipHolder);
        coreTitle = Ui.text(this, "", 16, Ui.TEXT, true);
        coreTitle.setPadding(0, Ui.dp(this, 6), 0, 0);
        col.addView(coreTitle);
        coreSub = Ui.text(this, "", 12, Ui.SUB, false);
        coreSub.setPadding(0, Ui.dp(this, 2), 0, 0);
        coreSub.setSingleLine(true);
        coreSub.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        col.addView(coreSub);
        head.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        coreBtn = Ui.button(this, Lang.t("Core"), Ui.FILLED, v -> coreMenu());
        head.addView(coreBtn);
        cc.addView(head);
        LinearLayout acts = Ui.horizontal(this);
        acts.setPadding(0, Ui.dp(this, 6), 0, 0);
        acts.addView(romBtn = Ui.button(this, Lang.t("ROM folder"), Ui.TONAL, v -> {
            Intent i = new Intent(this, FileBrowserActivity.class);
            i.putExtra("mode", "folder");
            i.putExtra("start", Prefs.mameDir(this));
            i.putExtra("title", Lang.t("MAME ROM folder"));
            startActivityForResult(i, REQ_DIR);
        }));
        acts.addView(ctlBtn = Ui.button(this, Lang.t("Controller"), Ui.TONAL, v -> startActivity(new Intent(this, MappingActivity.class))), Ui.wrapMargins(this, 0, 0, 8, 0));
        acts.addView(logBtn = Ui.button(this, Lang.t("Game log"), Ui.TONAL, v -> {
            String t = "";
            try {
                File f = MameActivity.logFile(this);
                if (f.isFile()) t = new String(java.nio.file.Files.readAllBytes(f.toPath()), "UTF-8");
            } catch (Exception e) { t = String.valueOf(e); }
            if (t.length() > 20000) t = t.substring(t.length() - 20000);
            Dialogs.log(this, t);
        }), Ui.wrapMargins(this, 8, 0, 0, 0));
        cc.addView(acts);

        // search pill
        LinearLayout sb = Ui.horizontal(this);
        sb.setBackground(Ui.rounded(this, Ui.SURFACE, 20));
        sb.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), 0);
        sb.setGravity(android.view.Gravity.CENTER_VERTICAL);
        sb.addView(Ui.icon(this, Icons.SEARCH, Ui.SUB, 20));
        EditText search = new EditText(this);
        searchField = search;
        searchBar = sb;
        sb.setVisibility(View.GONE);
        search.setHint(Lang.t("Search games"));
        search.setHintTextColor(Ui.SUB);
        search.setTextColor(Ui.TEXT);
        search.setTextSize(15);
        search.setSingleLine(true);
        search.setBackground(null);
        search.setPadding(Ui.dp(this, 12), 0, 0, 0);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void afterTextChanged(Editable e) { query = e.toString().trim().toLowerCase(Locale.ROOT); filter(); }
        });
        sb.addView(search, new LinearLayout.LayoutParams(0, Ui.dp(this, 40), 1f));
        hdr.addView(sb, Ui.fillMargins(this, 14, 2, 14, 4));
        View sbtn = Ui.glyphButton(this, "\uD83D\uDD0D", Lang.t("Search games"), v -> toggleSearch());
        ((LinearLayout.LayoutParams) sbtn.getLayoutParams()).rightMargin = Ui.dp(this, 8);
        top.addView(sbtn, top.getChildCount() - 1);

        FrameLayout body = new FrameLayout(this);
        grid = new android.widget.GridView(this);
        grid.setSelector(Ui.focusRing(this, 18));
        grid.setFocusable(true);
        grid.setClipToPadding(false);
        grid.setPadding(Ui.dp(this, 12), Ui.dp(this, 2), Ui.dp(this, 12), Ui.dp(this, 24));
        grid.setVerticalSpacing(Ui.dp(this, 10));
        grid.setHorizontalSpacing(Ui.dp(this, 10));
        int wdp = (int) (getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().density);
        grid.setNumColumns(Math.max(1, Math.min(3, wdp / 320)));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View v, ViewGroup p) { return tile(shown.get(i)); }
        };
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((pa, vw, pos, id) -> play(shown.get(pos)));
        if (land) grid.setOnScrollListener(new android.widget.AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(android.widget.AbsListView v, int st) { }
            @Override public void onScroll(android.widget.AbsListView v, int first, int vis, int total) {
                int want = first >= 1 ? View.GONE : View.VISIBLE;
                if (hdr.getVisibility() != want && !(want == View.VISIBLE && v.getChildCount() > 0 && v.getChildAt(0).getTop() < 0)) hdr.setVisibility(want);
            }
        });
        body.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        empty = Ui.text(this, "", 14, Ui.SUB, false);
        empty.setGravity(android.view.Gravity.CENTER);
        empty.setLineSpacing(0, 1.15f);
        empty.setPadding(Ui.dp(this, 32), Ui.dp(this, 20), Ui.dp(this, 32), Ui.dp(this, 20));
        body.addView(empty, new FrameLayout.LayoutParams(-1, -2, android.view.Gravity.CENTER));
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
        grid.requestFocus();
    }


    private void toggleSearch() {
        boolean show = searchBar.getVisibility() != View.VISIBLE;
        searchBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            searchField.requestFocus();
            android.view.inputmethod.InputMethodManager im = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (im != null) im.showSoftInput(searchField, 0);
        } else {
            searchField.setText("");
            android.view.inputmethod.InputMethodManager im = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (im != null) im.hideSoftInputFromWindow(searchField.getWindowToken(), 0);
            grid.requestFocus();
        }
    }

    @Override public boolean dispatchKeyEvent(android.view.KeyEvent e) {
        android.view.KeyEvent m = Ui.padKey(e);
        if (m != null && !(searchField.hasFocus() && e.getKeyCode() == android.view.KeyEvent.KEYCODE_BUTTON_B && false)) return super.dispatchKeyEvent(m);
        if (e.getAction() == android.view.KeyEvent.ACTION_DOWN && e.getRepeatCount() == 0) {
            int k = e.getKeyCode();
            if (k == android.view.KeyEvent.KEYCODE_BUTTON_Y) { toggleSearch(); return true; }
            if (k == android.view.KeyEvent.KEYCODE_BUTTON_START || k == android.view.KeyEvent.KEYCODE_BUTTON_SELECT) { openSide(); return true; }
        }
        return super.dispatchKeyEvent(e);
    }

    private void openSide() {
        SideMenu.show(this, SideMenu.MAME,
                new String[]{Lang.t("Core"), Lang.t("ROM folder"), Lang.t("Controller"), Lang.t("Game log")},
                new Runnable[]{() -> coreBtn.performClick(), () -> romBtn.performClick(), () -> ctlBtn.performClick(), () -> logBtn.performClick()},
                coreTitle.getText() + "\n" + coreSub.getText());
    }

    private View tile(final Item it) {
        LinearLayout r = Ui.horizontal(this);
        r.setGravity(android.view.Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(this, 8), Ui.dp(this, 6), Ui.dp(this, 10), Ui.dp(this, 6));
        r.setBackground(Ui.ripple(this, Ui.rounded(this, Ui.SURFACE, 18), 18));
        int hue = (it.name.hashCode() & 0x7FFFFFFF) % 360;
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                new int[]{Color.HSVToColor(new float[]{hue, 0.50f, 0.58f}), Color.HSVToColor(new float[]{(hue + 28) % 360, 0.62f, 0.26f})});
        g.setCornerRadius(Ui.dp(this, 14));
        TextView cover = Ui.text(this, initials(it.title), 14, 0xE6FFFFFF, true);
        cover.setGravity(android.view.Gravity.CENTER);
        cover.setBackground(g);
        r.addView(cover, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        LinearLayout col = Ui.vertical(this);
        col.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        TextView t = Ui.text(this, it.title, 13, Ui.TEXT, true);
        t.setMaxLines(2);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(t);
        TextView s = Ui.text(this, it.sub, 10.5f, Ui.SUB, false);
        s.setSingleLine(true);
        s.setEllipsize(android.text.TextUtils.TruncateAt.END);
        s.setPadding(0, Ui.dp(this, 3), 0, 0);
        col.addView(s);
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        FrameLayout pb = new FrameLayout(this);
        pb.setBackground(Ui.rounded(this, Ui.ACCENT_DIM, 20));
        ImageView ic = Ui.icon(this, Icons.PLAY, Ui.ACCENT, 20);
        pb.addView(ic, new FrameLayout.LayoutParams(Ui.dp(this, 20), Ui.dp(this, 20), android.view.Gravity.CENTER));
        r.addView(pb, new LinearLayout.LayoutParams(Ui.dp(this, 32), Ui.dp(this, 32)));
        r.setClickable(true);
        r.setOnClickListener(v -> play(it));
        Ui.press(r);
        return r;
    }

    private static String initials(String title) {
        StringBuilder sb = new StringBuilder();
        for (String w : title.split("[^A-Za-z0-9]+")) {
            if (w.isEmpty()) continue;
            if (w.matches("[0-9]{1,3}|[IVX]{1,4}")) { sb.append(w); break; }
            sb.append(Character.toUpperCase(w.charAt(0)));
            if (sb.length() >= 3) break;
        }
        return sb.length() == 0 ? "?" : sb.toString();
    }

    @Override protected void onResume() {
        super.onResume();
        if (builtTheme != Ui.themeVersion) { recreate(); return; }
        refreshCore();
        scan();
    }

    private void refreshCore() {
        String id = MameCore.current(this);
        File f = MameCore.file(this, id);
        String name = "custom".equals(id) ? Lang.t("Custom core file") : id;
        for (int i = 0; i < MameCore.IDS.length; i++) if (MameCore.IDS[i].equals(id)) name = MameCore.NAMES[i];
        chipHolder.removeAllViews();
        chipHolder.addView(f != null ? Ui.chip(this, Lang.t("READY"), Ui.OK, 0xFF16301F) : Ui.chip(this, Lang.t("NO CORE"), Ui.WARN, Ui.WARN_DIM));
        coreTitle.setText(name.contains(" - ") ? name.substring(0, name.indexOf(" - ")) : name);
        coreSub.setText(f != null ? Lang.t("ROMs: ") + Prefs.mameDir(this) : Lang.t("Tap Core to download one"));
    }

    private void setStatus(String t) { coreSub.setText(t); }

    private void coreMenu() {
        if (busy) return;
        String[] o = new String[MameCore.NAMES.length + 1];
        System.arraycopy(MameCore.NAMES, 0, o, 0, MameCore.NAMES.length);
        o[o.length - 1] = Lang.t("Use a core file from this device...");
        Dialogs.choose(this, Lang.t("MAME core"), o, -1, i -> {
            if (i == o.length - 1) {
                Intent it = new Intent(this, FileBrowserActivity.class);
                it.putExtra("mode", "file");
                it.putExtra("ext", ".so");
                it.putExtra("start", Prefs.mameDir(this));
                it.putExtra("title", Lang.t("Choose a libretro core (.so)"));
                startActivityForResult(it, REQ_CORE);
                return;
            }
            final String id = MameCore.IDS[i];
            MameCore.setCurrent(this, id);
            busy = true;
            setStatus(Lang.t("Starting download..."));
            new Thread(() -> {
                String err = null;
                try {
                    MameCore.download(this, id, t -> ui.post(() -> setStatus(t)));
                } catch (Exception e) {
                    err = String.valueOf(e.getMessage());
                }
                final String er = err;
                ui.post(() -> {
                    busy = false;
                    refreshCore();
                    if (er != null) {
                        Dialogs.message(this, Lang.t("Download failed"), Collections.singletonList(er
                                + Lang.t("\n\nYou can also download the core on another device (libretro buildbot, Android arm64-v8a) ")
                                + Lang.t("and pick the .so file with \"Use a core file from this device\".")), Lang.t("OK"), null, null, null);
                    }
                });
            }).start();
        });
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        if (res != RESULT_OK || d == null || d.getStringExtra("path") == null) return;
        if (req == REQ_DIR) {
            Prefs.put(this, "mameDir", d.getStringExtra("path"));
            refreshCore();
            scan();
        } else if (req == REQ_CORE) {
            try {
                MameCore.useFile(this, new File(d.getStringExtra("path")));
                refreshCore();
            } catch (Exception e) {
                Ui.toast(this, Lang.t("Could not use that file: ") + e.getMessage());
            }
        }
    }

    private void scan() {
        final String dir = Prefs.mameDir(this);
        new Thread(() -> {
            List<Item> out = new ArrayList<>();
            Map<String, MameGames.Info> known = MameGames.get(this);
            File[] fs = new File(dir).listFiles();
            if (fs != null) {
                for (File f : fs) {
                    String n = f.getName();
                    if (!f.isFile() || !n.toLowerCase(Locale.ROOT).endsWith(".zip")) continue;
                    String base = n.substring(0, n.length() - 4);
                    Item it = new Item();
                    it.name = base;
                    MameGames.Info k = known.get(base.toLowerCase(Locale.ROOT));
                    if (k != null) {
                        it.title = k.title;
                        it.sub = base + "  " + k.year + "  " + k.maker;
                    } else {
                        it.title = base;
                        it.sub = Lang.t("Not in the 2003-Plus list - the current MAME core may still know it");
                    }
                    // device and BIOS archives are not games; keep them out when we know about them
                    if (k != null && !k.runnable) continue;
                    out.add(it);
                }
            }
            Collections.sort(out, (a, b) -> a.title.compareToIgnoreCase(b.title));
            ui.post(() -> {
                all.clear();
                all.addAll(out);
                filter();
            });
        }).start();
    }

    private void filter() {
        shown.clear();
        for (Item i : all) if (query.isEmpty() || i.title.toLowerCase(Locale.ROOT).contains(query) || i.name.contains(query)) shown.add(i);
        adapter.notifyDataSetChanged();
        if (all.isEmpty()) {
            empty.setText(Lang.t("No ROM zips found in\n") + Prefs.mameDir(this)
                    + Lang.t("\n\nPut MAME ROM zips there (for example tekken3.zip, with its BIOS) or choose another folder."));
            empty.setVisibility(View.VISIBLE);
        } else {
            empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
            if (shown.isEmpty()) empty.setText(Lang.t("Nothing matches your search."));
        }
    }

    private void play(Item it) {
        if (!MameCore.installed(this)) {
            Ui.toast(this, Lang.t("Download a MAME core first"));
            coreMenu();
            return;
        }
        if (!Prefs.hasAccess(this)) { Prefs.requestAccess(this); return; }
        Intent i = new Intent(this, MameActivity.class);
        i.putExtra("rom", it.name);
        i.putExtra("path", Prefs.mameDir(this) + it.name + ".zip");
        startActivity(i);
    }
}
