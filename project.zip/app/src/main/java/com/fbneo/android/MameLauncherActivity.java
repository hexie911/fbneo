package com.fbneo.android;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** The MAME section: its own ROM folder and list, core download, and a way to start a game. */
public class MameLauncherActivity extends Activity {
    private static final int REQ_DIR = 1, REQ_CORE = 2;

    static final class Item { String name, title, sub; }

    private final List<Item> all = new ArrayList<>(), shown = new ArrayList<>();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private TextView empty;
    private BaseAdapter adapter;
    private String query = "";
    private volatile boolean busy;

    private LinearLayout chipHolder;
    private TextView coreTitle, coreSub;
    private android.widget.GridView grid;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.migrateLayout(this);
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);

        LinearLayout top = Ui.horizontal(this);
        top.setGravity(android.view.Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 6));
        top.addView(Ui.iconButton(this, Icons.BACK, "Back", v -> finish()));
        LinearLayout titles = Ui.vertical(this);
        titles.setPadding(Ui.dp(this, 14), 0, 0, 0);
        titles.addView(Ui.text(this, "MAME", 28, Ui.TEXT, true));
        TextView sub = Ui.text(this, "Arcade games through a libretro core", 12, Ui.SUB, false);
        sub.setPadding(0, Ui.dp(this, 2), 0, 0);
        titles.addView(sub);
        top.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(Ui.iconButton(this, Icons.MORE, "Menu", v -> SideMenu.show(this, SideMenu.MAME)));
        root.addView(top);

        // core card
        LinearLayout cc = Ui.card(this, Ui.SURFACE, 22);
        cc.setPadding(Ui.dp(this, 18), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 12));
        LinearLayout head = Ui.horizontal(this);
        head.setGravity(android.view.Gravity.CENTER_VERTICAL);
        LinearLayout col = Ui.vertical(this);
        chipHolder = Ui.horizontal(this);
        col.addView(chipHolder);
        coreTitle = Ui.text(this, "", 16, Ui.TEXT, true);
        coreTitle.setPadding(0, Ui.dp(this, 6), 0, 0);
        col.addView(coreTitle);
        coreSub = Ui.text(this, "", 12, Ui.SUB, false);
        coreSub.setPadding(0, Ui.dp(this, 2), 0, 0);
        coreSub.setSingleLine(true);
        coreSub.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        col.addView(coreSub);
        head.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        head.addView(Ui.button(this, "Core", Ui.FILLED, v -> coreMenu()));
        cc.addView(head);
        LinearLayout acts = Ui.horizontal(this);
        acts.setPadding(0, Ui.dp(this, 10), 0, 0);
        acts.addView(Ui.button(this, "ROM folder", Ui.TONAL, v -> {
            Intent i = new Intent(this, FileBrowserActivity.class);
            i.putExtra("mode", "folder");
            i.putExtra("start", Prefs.mameDir(this));
            i.putExtra("title", "MAME ROM folder");
            startActivityForResult(i, REQ_DIR);
        }));
        acts.addView(Ui.button(this, "Controller", Ui.TONAL, v -> startActivity(new Intent(this, MappingActivity.class))), Ui.wrapMargins(this, 0, 0, 8, 0));
        acts.addView(Ui.button(this, "Game log", Ui.TONAL, v -> {
            String t = "";
            try {
                File f = MameActivity.logFile(this);
                if (f.isFile()) t = new String(java.nio.file.Files.readAllBytes(f.toPath()), "UTF-8");
            } catch (Exception e) { t = String.valueOf(e); }
            if (t.length() > 20000) t = t.substring(t.length() - 20000);
            Dialogs.log(this, t);
        }), Ui.wrapMargins(this, 8, 0, 0, 0));
        cc.addView(acts);
        root.addView(cc, Ui.fillMargins(this, 16, 6, 16, 8));

        // search pill
        LinearLayout sb = Ui.horizontal(this);
        sb.setBackground(Ui.rounded(this, Ui.SURFACE, 26));
        sb.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), 0);
        sb.setGravity(android.view.Gravity.CENTER_VERTICAL);
        sb.addView(Ui.icon(this, Icons.SEARCH, Ui.SUB, 20));
        EditText search = new EditText(this);
        search.setHint("Search games");
        search.setHintTextColor(Ui.SUB);
        search.setTextColor(Ui.TEXT);
        search.setTextSize(15);
        search.setSingleLine(true);
        search.setBackground(null);
        search.setPadding(Ui.dp(this, 12), 0, 0, 0);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void onTextChanged(CharSequence s, int a, int c, int d) { }
            @Override public void afterTextChanged(Editable e) { query = e.toString().trim().toLowerCase(Locale.ROOT); filter(); }
        });
        sb.addView(search, new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f));
        root.addView(sb, Ui.fillMargins(this, 16, 2, 16, 8));

        FrameLayout body = new FrameLayout(this);
        grid = new android.widget.GridView(this);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        grid.setClipToPadding(false);
        grid.setPadding(Ui.dp(this, 12), Ui.dp(this, 2), Ui.dp(this, 12), Ui.dp(this, 24));
        grid.setVerticalSpacing(Ui.dp(this, 10));
        grid.setHorizontalSpacing(Ui.dp(this, 10));
        int wdp = (int) (getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().density);
        grid.setNumColumns(Math.max(1, Math.min(3, wdp / 320)));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View v, ViewGroup p) { return tile(shown.get(i)); }
        };
        grid.setAdapter(adapter);
        body.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        empty = Ui.text(this, "", 14, Ui.SUB, false);
        empty.setGravity(android.view.Gravity.CENTER);
        empty.setLineSpacing(0, 1.15f);
        empty.setPadding(Ui.dp(this, 32), Ui.dp(this, 20), Ui.dp(this, 32), Ui.dp(this, 20));
        body.addView(empty, new FrameLayout.LayoutParams(-1, -2, android.view.Gravity.CENTER));
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    private View tile(final Item it) {
        LinearLayout r = Ui.horizontal(this);
        r.setGravity(android.view.Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(this, 10), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        r.setBackground(Ui.ripple(this, Ui.rounded(this, Ui.SURFACE, 18), 18));
        int hue = (it.name.hashCode() & 0x7FFFFFFF) % 360;
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                new int[]{Color.HSVToColor(new float[]{hue, 0.50f, 0.58f}), Color.HSVToColor(new float[]{(hue + 28) % 360, 0.62f, 0.26f})});
        g.setCornerRadius(Ui.dp(this, 14));
        TextView cover = Ui.text(this, initials(it.title), 17, 0xE6FFFFFF, true);
        cover.setGravity(android.view.Gravity.CENTER);
        cover.setBackground(g);
        r.addView(cover, new LinearLayout.LayoutParams(Ui.dp(this, 54), Ui.dp(this, 54)));
        LinearLayout col = Ui.vertical(this);
        col.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        TextView t = Ui.text(this, it.title, 15, Ui.TEXT, true);
        t.setMaxLines(2);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        col.addView(t);
        TextView s = Ui.text(this, it.sub, 12, Ui.SUB, false);
        s.setSingleLine(true);
        s.setEllipsize(android.text.TextUtils.TruncateAt.END);
        s.setPadding(0, Ui.dp(this, 3), 0, 0);
        col.addView(s);
        r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        FrameLayout pb = new FrameLayout(this);
        pb.setBackground(Ui.rounded(this, Ui.ACCENT_DIM, 20));
        ImageView ic = Ui.icon(this, Icons.PLAY, Ui.ACCENT, 20);
        pb.addView(ic, new FrameLayout.LayoutParams(Ui.dp(this, 20), Ui.dp(this, 20), android.view.Gravity.CENTER));
        r.addView(pb, new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40)));
        r.setClickable(true);
        r.setOnClickListener(v -> play(it));
        Ui.press(r);
        return r;
    }

    private static String initials(String title) {
        StringBuilder sb = new StringBuilder();
        for (String w : title.split("[^A-Za-z0-9]+")) {
            if (w.isEmpty()) continue;
            if (w.matches("[0-9]{1,3}|[IVX]{1,4}")) { sb.append(w); break; }
            sb.append(Character.toUpperCase(w.charAt(0)));
            if (sb.length() >= 3) break;
        }
        return sb.length() == 0 ? "?" : sb.toString();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshCore();
        scan();
    }

    private void refreshCore() {
        String id = MameCore.current(this);
        File f = MameCore.file(this, id);
        String name = "custom".equals(id) ? "Custom core file" : id;
        for (int i = 0; i < MameCore.IDS.length; i++) if (MameCore.IDS[i].equals(id)) name = MameCore.NAMES[i];
        chipHolder.removeAllViews();
        chipHolder.addView(f != null ? Ui.chip(this, "READY", Ui.OK, 0xFF16301F) : Ui.chip(this, "NO CORE", Ui.WARN, Ui.WARN_DIM));
        coreTitle.setText(name.contains(" - ") ? name.substring(0, name.indexOf(" - ")) : name);
        coreSub.setText(f != null ? "ROMs: " + Prefs.mameDir(this) : "Tap Core to download one");
    }

    private void setStatus(String t) { coreSub.setText(t); }

    private void coreMenu() {
        if (busy) return;
        String[] o = new String[MameCore.NAMES.length + 1];
        System.arraycopy(MameCore.NAMES, 0, o, 0, MameCore.NAMES.length);
        o[o.length - 1] = "Use a core file from this device...";
        Dialogs.choose(this, "MAME core", o, -1, i -> {
            if (i == o.length - 1) {
                Intent it = new Intent(this, FileBrowserActivity.class);
                it.putExtra("mode", "file");
                it.putExtra("ext", ".so");
                it.putExtra("start", Prefs.mameDir(this));
                it.putExtra("title", "Choose a libretro core (.so)");
                startActivityForResult(it, REQ_CORE);
                return;
            }
            final String id = MameCore.IDS[i];
            MameCore.setCurrent(this, id);
            busy = true;
            setStatus("Starting download...");
            new Thread(() -> {
                String err = null;
                try {
                    MameCore.download(this, id, t -> ui.post(() -> setStatus(t)));
                } catch (Exception e) {
                    err = String.valueOf(e.getMessage());
                }
                final String er = err;
                ui.post(() -> {
                    busy = false;
                    refreshCore();
                    if (er != null) {
                        Dialogs.message(this, "Download failed", Collections.singletonList(er
                                + "\n\nYou can also download the core on another device (libretro buildbot, Android arm64-v8a) "
                                + "and pick the .so file with \"Use a core file from this device\"."), "OK", null, null, null);
                    }
                });
            }).start();
        });
    }

    @Override protected void onActivityResult(int req, int res, Intent d) {
        if (res != RESULT_OK || d == null || d.getStringExtra("path") == null) return;
        if (req == REQ_DIR) {
            Prefs.put(this, "mameDir", d.getStringExtra("path"));
            refreshCore();
            scan();
        } else if (req == REQ_CORE) {
            try {
                MameCore.useFile(this, new File(d.getStringExtra("path")));
                refreshCore();
            } catch (Exception e) {
                Ui.toast(this, "Could not use that file: " + e.getMessage());
            }
        }
    }

    private void scan() {
        final String dir = Prefs.mameDir(this);
        new Thread(() -> {
            List<Item> out = new ArrayList<>();
            Map<String, MameGames.Info> known = MameGames.get(this);
            File[] fs = new File(dir).listFiles();
            if (fs != null) {
                for (File f : fs) {
                    String n = f.getName();
                    if (!f.isFile() || !n.toLowerCase(Locale.ROOT).endsWith(".zip")) continue;
                    String base = n.substring(0, n.length() - 4);
                    Item it = new Item();
                    it.name = base;
                    MameGames.Info k = known.get(base.toLowerCase(Locale.ROOT));
                    if (k != null) {
                        it.title = k.title;
                        it.sub = base + "  " + k.year + "  " + k.maker;
                    } else {
                        it.title = base;
                        it.sub = "Not in the 2003-Plus list - the current MAME core may still know it";
                    }
                    // device and BIOS archives are not games; keep them out when we know about them
                    if (k != null && !k.runnable) continue;
                    out.add(it);
                }
            }
            Collections.sort(out, (a, b) -> a.title.compareToIgnoreCase(b.title));
            ui.post(() -> {
                all.clear();
                all.addAll(out);
                filter();
            });
        }).start();
    }

    private void filter() {
        shown.clear();
        for (Item i : all) if (query.isEmpty() || i.title.toLowerCase(Locale.ROOT).contains(query) || i.name.contains(query)) shown.add(i);
        adapter.notifyDataSetChanged();
        if (all.isEmpty()) {
            empty.setText("No ROM zips found in\n" + Prefs.mameDir(this)
                    + "\n\nPut MAME ROM zips there (for example tekken3.zip, with its BIOS) or choose another folder.");
            empty.setVisibility(View.VISIBLE);
        } else {
            empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
            if (shown.isEmpty()) empty.setText("Nothing matches your search.");
        }
    }

    private void play(Item it) {
        if (!MameCore.installed(this)) {
            Ui.toast(this, "Download a MAME core first");
            coreMenu();
            return;
        }
        if (!Prefs.hasAccess(this)) { Prefs.requestAccess(this); return; }
        Intent i = new Intent(this, MameActivity.class);
        i.putExtra("rom", it.name);
        i.putExtra("path", Prefs.mameDir(this) + it.name + ".zip");
        startActivity(i);
    }
}
