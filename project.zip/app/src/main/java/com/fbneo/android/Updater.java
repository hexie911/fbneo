package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Updates the app from the project's GitHub "latest" release, without leaving the emulator. */
final class Updater {
    private static final String API = "https://api.github.com/repos/hexie911/fbneo/releases/tags/latest";
    private static final String ACTION = "com.fbneo.android.UPDATE_RESULT";
    private static volatile boolean busy;

    private Updater() {}

    /** Result of looking at the release. */
    private static final class Info {
        boolean newer;
        String versionName = "";
        String url = "";
        long size;
        String notes = "";
    }

    static long installedCode(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception e) { return 0; }
    }

    static String installedName(Context c) {
        try { return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName; }
        catch (Exception e) { return "?"; }
    }

    /** Checks for an update. silent: automatic check, speaks up only when there is one. */
    static void check(final Activity a, final boolean silent) {
        if (busy) return;
        busy = true;
        if (!silent) Ui.toast(a, Lang.t("Checking for updates..."));
        new Thread(() -> {
            Info info = null;
            String err = null;
            try { info = fetch(a); } catch (Exception e) { err = String.valueOf(e.getMessage()); }
            final Info fi = info;
            final String fe = err;
            Prefs.put(a, "updCheckedAt", (int) (System.currentTimeMillis() / 60000L));
            a.runOnUiThread(() -> {
                busy = false;
                if (a.isFinishing()) return;
                if (fi == null) {
                    if (!silent) Ui.toast(a, Lang.t("Could not check for updates. Check your internet connection."));
                } else if (!fi.newer) {
                    if (!silent) Ui.toast(a, Lang.t("You have the latest version") + " (" + installedName(a) + ")");
                } else if (!silent || !fi.versionName.equals(Prefs.sp(a).getString("updDismissed", ""))) {
                    offer(a, fi);
                }
            });
        }, "update-check").start();
    }

    /** At most every 6 hours, when the user has automatic checks on. */
    static void autoCheck(Activity a) {
        if (!Prefs.sp(a).getBoolean("autoUpdate", true)) return;
        int now = (int) (System.currentTimeMillis() / 60000L);
        if (now - Prefs.sp(a).getInt("updCheckedAt", 0) < 360) return;
        check(a, true);
    }

    private static Info fetch(Context c) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(API).openConnection();
        h.setConnectTimeout(10000);
        h.setReadTimeout(15000);
        h.setRequestProperty("Accept", "application/vnd.github+json");
        h.setRequestProperty("User-Agent", "fbn4droid");
        if (h.getResponseCode() != 200) throw new Exception("HTTP " + h.getResponseCode());
        StringBuilder sb = new StringBuilder();
        try (InputStream in = h.getInputStream()) {
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) sb.append(new String(b, 0, n, "UTF-8"));
        }
        org.json.JSONObject o = new org.json.JSONObject(sb.toString());
        Info i = new Info();
        org.json.JSONArray as = o.optJSONArray("assets");
        if (as == null) throw new Exception("no assets");
        for (int k = 0; k < as.length(); k++) {
            org.json.JSONObject x = as.getJSONObject(k);
            if (x.optString("name").toLowerCase().endsWith(".apk")) {
                i.url = x.getString("browser_download_url");
                i.size = x.optLong("size");
                break;
            }
        }
        if (i.url.length() == 0) throw new Exception("no apk");
        String body = o.optString("body", "");
        Matcher mc = Pattern.compile("versionCode:\\s*(\\d+)").matcher(body);
        Matcher mn = Pattern.compile("versionName:\\s*([\\w.\\-]+)").matcher(body);
        if (mn.find()) i.versionName = mn.group(1);
        Matcher mnotes = Pattern.compile("(?s)notes:\\s*(.*)$").matcher(body);
        if (mnotes.find()) i.notes = mnotes.group(1).trim();
        if (mc.find()) {
            i.newer = Long.parseLong(mc.group(1)) > installedCode(c);
        } else {
            // older release without a version tag: compare publish time with our install time
            long pub = parseTime(o.optString("published_at", ""));
            long inst = c.getPackageManager().getPackageInfo(c.getPackageName(), 0).lastUpdateTime;
            i.newer = pub > 0 && pub > inst + 10 * 60 * 1000L;
            if (i.versionName.length() == 0) i.versionName = o.optString("published_at", "").replace("T", " ").replace("Z", "");
        }
        return i;
    }

    private static long parseTime(String s) {
        try {
            java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US);
            f.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
            return f.parse(s).getTime();
        } catch (Exception e) { return 0; }
    }

    private static void offer(final Activity a, final Info i) {
        java.util.List<String> p = new java.util.ArrayList<>();
        p.add(Lang.t("A new version is available") + ": " + i.versionName + "  (" + Lang.t("installed") + ": " + installedName(a) + ")");
        if (i.size > 0) p.add(Lang.t("Download size") + ": " + String.format(java.util.Locale.US, "%.1f MB", i.size / 1048576.0));
        if (i.notes.length() > 0) p.add(i.notes);
        p.add(Lang.t("Your games, saves and settings are kept."));
        Dialogs.message(a, Lang.t("Update available"), p, Lang.t("Update now"), () -> download(a, i),
                Lang.t("Later"), () -> Prefs.put(a, "updDismissed", i.versionName));
    }

    private static void download(final Activity a, final Info i) {
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            Dialogs.message(a, Lang.t("Allow installing updates"), Arrays.asList(
                    Lang.t("Android needs your permission before fbn4droid can install updates. Turn on \"Allow from this source\", then come back and tap Update again.")),
                    Lang.t("Open settings"), () -> {
                        try {
                            a.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + a.getPackageName())));
                        } catch (Exception e) { Ui.toast(a, Lang.t("Could not open settings")); }
                    }, Lang.t("Cancel"), null);
            return;
        }
        final LinearLayout[] h = new LinearLayout[1];
        final Dialog d = Dialogs.base(a, h);
        d.setCancelable(false);
        final TextView msg = Ui.text(a, Lang.t("Downloading update..."), 15, Ui.TEXT, false);
        final ProgressBar pb = new ProgressBar(a, null, android.R.attr.progressBarStyleHorizontal);
        pb.setMax(1000);
        h[0].addView(Ui.text(a, Lang.t("Update"), 20, Ui.TEXT, true));
        h[0].addView(msg, Ui.fillMargins(a, 0, 10, 0, 0));
        h[0].addView(pb, Ui.fillMargins(a, 0, 10, 0, 0));
        d.show();
        busy = true;
        new Thread(() -> {
            String err = null;
            File apk = new File(a.getCacheDir(), "update.apk");
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(i.url).openConnection();
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setInstanceFollowRedirects(true);
                c.setRequestProperty("User-Agent", "fbn4droid");
                if (c.getResponseCode() != 200) throw new Exception("HTTP " + c.getResponseCode());
                long total = c.getContentLengthLong() > 0 ? c.getContentLengthLong() : i.size;
                long got = 0;
                try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(apk)) {
                    byte[] b = new byte[65536];
                    int n;
                    long last = 0;
                    while ((n = in.read(b)) > 0) {
                        out.write(b, 0, n);
                        got += n;
                        long now = System.currentTimeMillis();
                        if (now - last > 150 && total > 0) {
                            last = now;
                            final int pr = (int) (got * 1000 / total);
                            final long g = got, t = total;
                            a.runOnUiThread(() -> {
                                pb.setProgress(pr);
                                msg.setText(Lang.t("Downloading update...") + "  " + (g >> 20) + " / " + (t >> 20) + " MB");
                            });
                        }
                    }
                }
                if (total > 0 && got < total) throw new Exception("incomplete download");
            } catch (Exception e) { err = String.valueOf(e.getMessage()); }
            final String fe = err;
            a.runOnUiThread(() -> {
                busy = false;
                d.dismiss();
                if (fe != null) {
                    Ui.toast(a, Lang.t("Download failed") + ": " + fe);
                } else {
                    install(a, apk);
                }
            });
        }, "update-download").start();
    }

    private static void install(final Activity a, File apk) {
        try {
            final Context app = a.getApplicationContext();
            PackageInstaller pi = app.getPackageManager().getPackageInstaller();
            PackageInstaller.SessionParams sp = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
            int id = pi.createSession(sp);
            try (PackageInstaller.Session s = pi.openSession(id);
                 InputStream in = new FileInputStream(apk);
                 OutputStream out = s.openWrite("fbn4droid.apk", 0, apk.length())) {
                byte[] b = new byte[65536];
                int n;
                while ((n = in.read(b)) > 0) out.write(b, 0, n);
                s.fsync(out);
                BroadcastReceiver r = new BroadcastReceiver() {
                    @Override public void onReceive(Context ctx, Intent it) {
                        int st = it.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
                        if (st == PackageInstaller.STATUS_PENDING_USER_ACTION) {
                            Intent confirm = it.getParcelableExtra(Intent.EXTRA_INTENT);
                            if (confirm != null) {
                                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                ctx.startActivity(confirm);
                            }
                            return;
                        }
                        try { app.unregisterReceiver(this); } catch (Exception e) { }
                        if (st != PackageInstaller.STATUS_SUCCESS) {
                            final String m = it.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE);
                            a.runOnUiThread(() -> { if (!a.isFinishing()) Ui.toast(a, Lang.t("Update failed") + ": " + m); });
                        }
                    }
                };
                IntentFilter f = new IntentFilter(ACTION);
                if (Build.VERSION.SDK_INT >= 33) app.registerReceiver(r, f, Context.RECEIVER_NOT_EXPORTED);
                else app.registerReceiver(r, f);
                Intent cb = new Intent(ACTION).setPackage(app.getPackageName());
                int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
                s.commit(PendingIntent.getBroadcast(app, id, cb, flags).getIntentSender());
            }
        } catch (Exception e) {
            Ui.toast(a, Lang.t("Update failed") + ": " + e.getMessage());
        }
    }
}
