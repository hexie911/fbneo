package com.fbneo.android;

import android.content.Context;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

/** The games the MAME core knows (assets/mame_games.tsv: name, title, year, maker, parent, runnable). */
final class MameGames {
    private MameGames() {}

    static final class Info {
        String name, title, year, maker, parent;
        boolean runnable;
    }

    private static Map<String, Info> sMap;

    static synchronized Map<String, Info> get(Context c) {
        if (sMap != null) return sMap;
        Map<String, Info> m = new HashMap<>();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getAssets().open("mame_games.tsv"), "UTF-8"))) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\t", -1);
                if (p.length < 6) continue;
                Info i = new Info();
                i.name = p[0]; i.title = p[1]; i.year = p[2]; i.maker = p[3]; i.parent = p[4];
                i.runnable = "1".equals(p[5]);
                m.put(i.name, i);
            }
        } catch (Exception e) {
            // empty list: the section just shows nothing
        }
        sMap = m;
        return m;
    }
}
