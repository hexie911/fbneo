package com.fbneo.android;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Controller mapping: tap an action then press the button, or run the guided setup. Also shows a live test line. */
public class MappingActivity extends Activity {
    private PadMap map;
    private PadInput pad;
    private TextView live;
    private View liveDot;
    private final boolean[] down = new boolean[Actions.COUNT];
    private final TextView[] chips = new TextView[Actions.COUNT];

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        map = PadMap.load(this);
        PadInput.configure(this);
        pad = new PadInput(map, (slot, action, d) -> {
            down[action] = d;
            updateLive();
        });

        LinearLayout page = Ui.vertical(this);
        page.setBackgroundColor(Ui.BG);
        page.addView(Ui.topBar(this, "Controller", this::finish));

        ScrollView sv = new ScrollView(this);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        LinearLayout root = Ui.vertical(this);
        root.setPadding(0, 0, 0, Ui.dp(this, 32));
        sv.addView(root);
        page.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView h = Ui.text(this, "Pair your controller in Android's Bluetooth settings first. Tap an action, then press the "
                + "button (or move the stick or trigger) you want for it. A second controller plays as player 2.", 13, Ui.SUB, false);
        h.setLineSpacing(0, 1.15f);
        h.setPadding(Ui.dp(this, 24), Ui.dp(this, 4), Ui.dp(this, 24), Ui.dp(this, 8));
        root.addView(h);

        LinearLayout liveCard = Ui.horizontal(this);
        liveCard.setBackground(Ui.rounded(this, Ui.SURFACE, 16));
        liveCard.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));
        liveDot = new View(this);
        liveDot.setBackground(Ui.rounded(this, Ui.OUTLINE, 6));
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Ui.dp(this, 12), Ui.dp(this, 12));
        dp.rightMargin = Ui.dp(this, 12);
        liveCard.addView(liveDot, dp);
        live = Ui.text(this, "", 14, Ui.SUB, false);
        liveCard.addView(live, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(liveCard, Ui.fillMargins(this, 16, 4, 16, 8));
        updateLive();

        LinearLayout bar = Ui.horizontal(this);
        bar.setPadding(Ui.dp(this, 16), Ui.dp(this, 4), Ui.dp(this, 16), Ui.dp(this, 4));
        bar.addView(Ui.button(this, "Guided setup", Ui.FILLED, v -> guided(0)));
        bar.addView(Ui.button(this, "Reset to defaults", Ui.TONAL, v -> {
            map = PadMap.defaults();
            map.save(this);
            pad.setMap(map);
            refreshRows();
        }), Ui.wrapMargins(this, 10, 0, 0, 0));
        root.addView(bar);

        root.addView(Ui.section(this, "Player controls"));
        for (int a : Actions.PLAYER) addRow(root, a);
        root.addView(Ui.section(this, "Emulator controls"));
        for (int a : Actions.EMULATOR) addRow(root, a);
        setContentView(page);
    }

    private void addRow(LinearLayout root, final int a) {
        LinearLayout r = Ui.horizontal(this);
        r.setBackground(Ui.ripple(this, Ui.rounded(this, Ui.SURFACE, 16), 16));
        r.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 12), Ui.dp(this, 12));
        TextView t = Ui.text(this, Actions.name(a), 15, Ui.TEXT, false);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView chip = Ui.text(this, "", 12, Ui.ACCENT, true);
        chip.setGravity(Gravity.CENTER);
        chip.setBackground(Ui.rounded(this, Ui.ACCENT_DIM, 12));
        chip.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
        chips[a] = chip;
        r.addView(chip);
        r.setClickable(true);
        r.setFocusable(true);
        r.setOnClickListener(v -> capture(a, false, null));
        Ui.press(r);
        r.setLayoutParams(Ui.fillMargins(this, 16, 3, 16, 3));
        root.addView(r);
        setChip(a);
    }

    private void setChip(int a) {
        if (chips[a] == null) return;
        String d = map.describe(a);
        boolean none = d == null || d.length() == 0 || d.toLowerCase().contains("not set") || d.toLowerCase().contains("unassigned");
        chips[a].setText(d == null || d.length() == 0 ? "Not set" : d);
        chips[a].setTextColor(none ? Ui.SUB : Ui.ACCENT);
        chips[a].setBackground(Ui.rounded(this, none ? Ui.SURFACE2 : Ui.ACCENT_DIM, 12));
    }

    private void refreshRows() {
        for (int a = 0; a < Actions.COUNT; a++) setChip(a);
    }

    private void capture(final int action, boolean guided, final Runnable next) {
        String hint = "Press the controller button (or move the stick / trigger) for this action.";
        new CaptureDialog(this, Actions.name(action), hint, guided, new CaptureDialog.Callback() {
            @Override public void onCaptured(PadMap.Binding b) {
                List<PadMap.Binding> l = new ArrayList<>();
                l.add(b);
                map.set(action, l);
                saved();
                if (next != null) next.run();
            }
            @Override public void onClear() {
                map.set(action, new ArrayList<PadMap.Binding>());
                saved();
                if (next != null) next.run();
            }
            @Override public void onSkip() { if (next != null) next.run(); }
        }).show();
    }

    private void saved() {
        map.save(this);
        pad.setMap(map);
        refreshRows();
    }

    private void guided(final int i) {
        if (i >= Actions.GUIDED.length) return;
        capture(Actions.GUIDED[i], true, () -> guided(i + 1));
    }

    private void updateLive() {
        StringBuilder sb = new StringBuilder();
        for (int a = 0; a < Actions.COUNT; a++) {
            if (down[a]) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(Actions.name(a).replaceAll("\\s+", " "));
            }
        }
        boolean any = sb.length() > 0;
        live.setText(any ? sb.toString() : "Live test: press buttons on your controller");
        live.setTextColor(any ? Ui.TEXT : Ui.SUB);
        liveDot.setBackground(Ui.rounded(this, any ? Ui.OK : Ui.OUTLINE, 6));
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        if (pad != null && pad.onKey(e)) return true;
        return super.dispatchKeyEvent(e);
    }

    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        if (pad != null && pad.onMotion(ev)) return true;
        return super.dispatchGenericMotionEvent(ev);
    }
}
