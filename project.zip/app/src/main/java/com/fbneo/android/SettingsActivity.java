package com.fbneo.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.view.ViewGroup;
import android.view.Gravity;
import android.widget.ScrollView;

public class SettingsActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Lang.wrap(base));
    }

    private static final int REQ_DATA = 1, REQ_ROMS = 2, REQ_LUADIR = 3, REQ_LUADEF = 4, REQ_ROOT = 5;

    private LinearLayout root;           // holds the page being shown
    private LinearLayout pg;             // page being filled while building
    private final LinearLayout[] pages = new LinearLayout[6];
    private int open = -1;               // -1 = the section list
    private LinearLayout bar;
    private View themeRow, bgRow, accentRow;
    private static final String[] SECTION_TITLES = {"Games and files", "Controls", "Video and audio", "Performance", "Appearance and language", "Help and about"};
    private static final String[] SECTION_SUBS = {
            "Folders, ROMs, Lua scripts, storage access",
            "Controller buttons, stick feel, on-screen controls",
            "Scaling, screen shape, renderer, counters, sound",
            "Frame skip, CPU cores, timing, weak phone preset",
            "Theme colors, background, accent, language",
            "Last game log, credits"};
    private static final int[] SECTION_ICONS = {Icons.FOLDER, Icons.GAMEPAD, Icons.PLAY, Icons.GEAR, Icons.SCRIPT, Icons.INFO};
    private static final int[] COUNTER_MASKS = {0, 1, 3, 7, 6};
    private View countersRow, rendererRow;
    private View langRow, mainRow, aspectRow, stickRow, accessRow, dataRow, romRow, luaRow, luaDefRow, filterRow, rateRow, latencyRow;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = Ui.vertical(this);
        page.setBackgroundColor(Ui.BG);
        bar = Ui.topBar(this, Lang.t("Settings"), this::goBack);
        page.addView(bar);
        ScrollView sv = new ScrollView(this);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root = Ui.vertical(this);
        root.setPadding(0, 0, 0, Ui.dp(this, 32));
        sv.addView(root, new android.widget.FrameLayout.LayoutParams(Math.min(Dialogs.screenWidth(this), Ui.dp(this, 640)), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL));
        page.addView(sv, new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(page);
        build();
        showSection(getIntent().getIntExtra("section", -1));
    }

    private void goBack() {
        if (open >= 0) showSection(-1); else finish();
    }

    @Override public void onBackPressed() { goBack(); }

    @Override public boolean dispatchKeyEvent(android.view.KeyEvent e) {
        android.view.KeyEvent m = Ui.padKey(e);
        return super.dispatchKeyEvent(m != null ? m : e);
    }

    private void showSection(int i) {
        open = i;
        root.removeAllViews();
        ((android.widget.TextView) bar.getChildAt(1)).setText(i < 0 ? Lang.t("Settings") : Lang.t(SECTION_TITLES[i]));
        if (i < 0) {
            for (int k = 0; k < SECTION_TITLES.length; k++) {
                final int which = k;
                root.addView(Ui.row(this, SECTION_ICONS[k], Lang.t(SECTION_TITLES[k]), Lang.t(SECTION_SUBS[k]), v -> showSection(which)));
            }
        } else {
            root.addView(pages[i]);
        }
        refresh();
    }

    private void chooseTheme() {
        String[] names = new String[Ui.THEME_NAMES.length + 1];
        int cur = names.length - 1;
        for (int i = 0; i < Ui.THEME_NAMES.length; i++) {
            names[i] = Lang.t(Ui.THEME_NAMES[i]);
            if (Ui.THEMES[i][0] == Ui.BG && Ui.THEMES[i][1] == Ui.ACCENT) cur = i;
        }
        names[names.length - 1] = Lang.t("Custom (pick the colors below)");
        Dialogs.choose(this, Lang.t("Theme"), names, cur, w -> {
            if (w < Ui.THEMES.length) Ui.setTheme(this, Ui.THEMES[w][0], Ui.THEMES[w][1]);
            else { pickColor(Lang.t("Background color"), Ui.BG_SWATCHES, Ui.BG, c -> Ui.setTheme(this, c, Ui.ACCENT)); return; }
            reopen();
        });
    }

    /** The colours are baked into the views, so the page is rebuilt; the section stays open. */
    private void reopen() {
        Intent it = new Intent(this, SettingsActivity.class);
        it.putExtra("section", open);
        it.addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION);
        finish();
        overridePendingTransition(0, 0);
        startActivity(it);
        overridePendingTransition(0, 0);
    }

    private void pickColor(String title, int[] swatches, int current, Dialogs.IntCallback cb) {
        final LinearLayout[] h = new LinearLayout[1];
        final android.app.Dialog d = Dialogs.base(this, h);
        LinearLayout card = h[0];
        card.addView(Ui.text(this, title, 18, Ui.TEXT, true));
        LinearLayout grid = Ui.vertical(this);
        final int perRow = 7;
        LinearLayout row = null;
        for (int i = 0; i < swatches.length; i++) {
            if (i % perRow == 0) { row = Ui.horizontal(this); grid.addView(row, Ui.fillMargins(this, 0, 4, 0, 4)); }
            final int c = swatches[i];
            View sw = new View(this);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(c);
            g.setStroke(Ui.dp(this, c == current ? 3 : 1), c == current ? Ui.TEXT : Ui.OUTLINE);
            sw.setBackground(g);
            sw.setFocusable(true);
            sw.setOnClickListener(v -> { d.dismiss(); cb.on(c); reopen(); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36));
            lp.rightMargin = Ui.dp(this, 10);
            row.addView(sw, lp);
        }
        card.addView(grid, Ui.fillMargins(this, 0, 10, 0, 6));
        final android.widget.EditText hex = new android.widget.EditText(this);
        hex.setHint("RRGGBB");
        hex.setHintTextColor(Ui.SUB);
        hex.setTextColor(Ui.TEXT);
        hex.setTextSize(14);
        hex.setSingleLine(true);
        hex.setText(String.format("%06X", current & 0xFFFFFF));
        LinearLayout hr = Ui.horizontal(this);
        hr.setGravity(Gravity.CENTER_VERTICAL);
        hr.addView(Ui.text(this, "#", 15, Ui.SUB, true));
        hr.addView(hex, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        hr.addView(Ui.button(this, Lang.t("Apply"), Ui.FILLED, v -> {
            try {
                int c = android.graphics.Color.parseColor("#" + hex.getText().toString().trim());
                d.dismiss();
                cb.on(c | 0xFF000000);
                reopen();
            } catch (IllegalArgumentException e) { Ui.toast(this, Lang.t("Not a valid color")); }
        }));
        card.addView(hr, Ui.fillMargins(this, 0, 6, 0, 0));
        card.addView(Ui.button(this, Lang.t("Cancel"), Ui.TEXTONLY, v -> d.dismiss()), Ui.fillMargins(this, 0, 6, 0, 0));
        d.show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void build() {
        for (int i = 0; i < pages.length; i++) pages[i] = Ui.vertical(this);
        pg = pages[0];
        pg = pages[0];
        pg.addView(Ui.section(this, Lang.t("Games and files")));
        mainRow = Ui.row(this, Icons.FOLDER, Lang.t("Main folder (fbneo, mame)"), "", v -> pick(REQ_ROOT, Prefs.rootDir(this), Lang.t("Main folder")));
        pg.addView(mainRow);
        accessRow = Ui.row(this, Icons.FOLDER, Lang.t("All files access"), "", v -> Prefs.requestAccess(this));
        pg.addView(accessRow);
        romRow = Ui.row(this, Icons.LIST, Lang.t("ROM folder"), "", v -> pick(REQ_ROMS, Prefs.romDir(this), Lang.t("ROM folder")));
        pg.addView(romRow);
        luaRow = Ui.row(this, Icons.SCRIPT, Lang.t("Lua scripts folder"), "", v -> pick(REQ_LUADIR, Prefs.luaDir(this), Lang.t("Lua scripts folder")));
        pg.addView(luaRow);
        luaDefRow = Ui.row(this, Icons.SCRIPT, Lang.t("Default Lua script"), "", v -> {
            if (Prefs.defaultLua(this).length() > 0) {
                Dialogs.choose(this, Lang.t("Default Lua script"), new String[]{Lang.t("Choose another script"), Lang.t("Clear (no default)")}, -1, w -> {
                    if (w == 0) pickFile();
                    else { Prefs.put(this, "luaDefault", ""); refresh(); }
                });
            } else pickFile();
        });
        pg.addView(luaDefRow);
        dataRow = Ui.row(this, Icons.FOLDER, Lang.t("FBNeo data folder"), "", v -> pick(REQ_DATA, Prefs.dataDir(this), Lang.t("Data folder (config, saves, logs)")));
        pg.addView(dataRow);
        pg.addView(Ui.section(this, Lang.t("Game covers")));
        pg.addView(Ui.row(this, Icons.DOWNLOAD, Lang.t("Download all game covers"),
                Lang.t("Fetches the cover of every game in your list that does not have one yet. Needs internet"), v -> downloadAllCovers()));
        pg.addView(Ui.switchRow(this, Lang.t("Download missing covers automatically"),
                Lang.t("Whenever the game list loads, in the background"), Prefs.sp(this).getBoolean("autoCovers", false),
                (v, on) -> Prefs.put(this, "autoCovers", on)));

        pg = pages[1];
        pg.addView(Ui.section(this, Lang.t("Controller")));
        pg.addView(Ui.row(this, Icons.GAMEPAD, Lang.t("Map controller buttons"),
                Lang.t("Buttons, swap player, Lua hotkeys, save states"),
                v -> startActivity(new Intent(this, MappingActivity.class))));
        pg.addView(Ui.switchRow(this, Lang.t("Arcade input smoothing"), Lang.t("Never loses a quick stick sweep, so half circles and fireballs come out reliably"),
                Prefs.smoothInput(this), (v, on) -> Prefs.put(this, "smoothInput", on)));
        stickRow = Ui.row(this, Lang.t("Stick and D-pad feel"), "", v -> Dialogs.choose(this, Lang.t("Stick and D-pad feel"),
                new String[]{Lang.t("Precise  (stick must be pushed far)"), Lang.t("Arcade  (recommended)"), Lang.t("Forgiving  (wide diagonals)")},
                Prefs.stickFeel(this), w -> {
                    Prefs.put(this, "stickFeel", w);
                    refresh();
                }));
        pg.addView(stickRow);
        pg.addView(Ui.switchRow(this, Lang.t("Start with the pad on player 2"), Lang.t("You can also swap while playing"), Prefs.startSwapped(this),
                (v, on) -> Prefs.put(this, "swap", on)));

        pg = pages[2];
        pg.addView(Ui.section(this, Lang.t("Video")));
        filterRow = Ui.row(this, Lang.t("Scaling"), "", v -> Dialogs.choose(this, Lang.t("Scaling"),
                new String[]{Lang.t("Sharp pixels"), Lang.t("Smooth"), Lang.t("Best (smooth, high quality)")}, filterIndex(), w -> {
                    Prefs.put(this, "filter", w == 0 ? "sharp" : w == 1 ? "smooth" : "best");
                    refresh();
                }));
        pg.addView(filterRow);
        aspectRow = Ui.row(this, Lang.t("Screen shape"), "", v -> {
            String[] names = new String[Prefs.ASPECTS.length];
            for (int i = 0; i < names.length; i++) names[i] = Lang.t(Prefs.ASPECTS[i][0]);
            Dialogs.choose(this, Lang.t("Screen shape"), names, Prefs.aspect(this), w -> {
                Prefs.put(this, "aspect", w);
                refresh();
            });
        });
        pg.addView(aspectRow);
        pg.addView(Ui.switchRow(this, Lang.t("Integer scaling"), Lang.t("Crisp pixels, may leave black borders"), Prefs.integerScale(this),
                (v, on) -> Prefs.put(this, "integer", on)));
        countersRow = Ui.row(this, Lang.t("On-screen counters"), "", v -> Dialogs.choose(this, Lang.t("On-screen counters"),
                new String[]{Lang.t("Off"), Lang.t("FPS"), Lang.t("FPS and speed"), Lang.t("FPS, speed and screen refresh"), Lang.t("Speed and screen refresh")},
                countersIndex(), w -> {
                    Prefs.put(this, "counters", COUNTER_MASKS[w]);
                    refresh();
                }));
        pg.addView(countersRow);
        rendererRow = Ui.row(this, Lang.t("Renderer"), "", v -> Dialogs.choose(this, Lang.t("Renderer"),
                new String[]{Lang.t("GPU  (OpenGL ES, recommended)"), Lang.t("Software  (compatibility, slower)"), Lang.t("GPU  (Vulkan, beta)")},
                Prefs.vulkan(this) ? 2 : Prefs.softRender(this) ? 1 : 0, w -> {
                    Prefs.put(this, "softRender", w == 1);
                    Prefs.put(this, "vulkan", w == 2);
                    refresh();
                }));
        pg.addView(rendererRow);
        pg.addView(Ui.switchRow(this, Lang.t("Multi-threaded video (experimental)"), Lang.t("Draws and shows the picture on a second thread so the game itself runs faster. Falls back by itself if the phone does not support it"),
                Prefs.videoThread(this), (v, on) -> Prefs.put(this, "videoThread", on)));
        pg.addView(Ui.switchRow(this, Lang.t("VSync"), Lang.t("Smooth picture. Turn off if the game feels choppy or slow"), Prefs.vsync(this),
                (v, on) -> Prefs.put(this, "vsync", on)));
        pg.addView(Ui.switchRow(this, Lang.t("Prefer a 60 Hz screen mode"), Lang.t("Avoids uneven frames on 90/120 Hz phones"), Prefs.match60(this),
                (v, on) -> Prefs.put(this, "match60", on)));
        pg.addView(Ui.switchRow(this, Lang.t("Rotate with the phone"), Lang.t("Off = always landscape"), Prefs.autoRotate(this),
                (v, on) -> Prefs.put(this, "autoRotate", on)));

        pg = pages[1];
        pg.addView(Ui.section(this, Lang.t("On-screen controls")));
        pg.addView(Ui.switchRow(this, Lang.t("On-screen controls in every game"), Lang.t("Turn on to start every game with the touch controls. Off = physical controller or keyboard only. Can also be switched in the pause menu; edit the layout from there too"),
                Prefs.touchOn(this), (v, on) -> Prefs.put(this, "touchOn", on)));
        pg.addView(Ui.row(this, Lang.t("Opacity"), Prefs.touchAlpha(this) + "%", v -> Dialogs.choose(this, Lang.t("Opacity of on-screen controls"),
                new String[]{"25%", "40%", "55%", "70%", "90%"}, alphaIndex(), w -> {
                    Prefs.put(this, "touchAlpha", new int[]{25, 40, 55, 70, 90}[w]);
                    refresh();
                })));
        pg = pages[3];
        pg.addView(Ui.section(this, Lang.t("Performance")));
        pg.addView(Ui.switchRow(this, Lang.t("Use the fastest CPU cores"), Lang.t("Keeps the game off the slow cores. Recommended"), Prefs.fastCores(this),
                (v, on) -> Prefs.put(this, "fastCores", on)));
        pg.addView(Ui.switchRow(this, Lang.t("Battery saver"), Lang.t("Sleeps between frames. Cooler, but heavy games like 3rd Strike can get slower"), Prefs.batterySaver(this),
                (v, on) -> Prefs.put(this, "batterySaver", on)));

        pg.addView(Ui.switchRow(this, Lang.t("Smooth frame timing"), Lang.t("Frames come at an even pace instead of in the audio device's bursts. Turn off only if something looks wrong"),
                Prefs.smoothPacing(this), (v, on) -> Prefs.put(this, "smoothPacing", on)));
        pg.addView(Ui.switchRow(this, Lang.t("Match the screen's refresh rate"), Lang.t("Arcade games run at 59.6 fps but screens at 60 Hz. This runs the game at the screen's rate (up to 1% faster) so no frame is ever shown twice"),
                Prefs.matchRefresh(this), (v, on) -> Prefs.put(this, "matchRefresh", on)));
        pg.addView(Ui.switchRow(this, Lang.t("Auto frame skip"), Lang.t("When the phone falls behind, skip drawing a few frames to keep the game at full speed"),
                Prefs.autoSkip(this), (v, on) -> Prefs.put(this, "autoSkip", on)));
        pg.addView(Ui.switchRow(this, Lang.t("High priority"), Lang.t("Asks Android to give the game thread more CPU time"),
                Prefs.highPrio(this), (v, on) -> Prefs.put(this, "highPrio", on)));
        pg.addView(Ui.switchRow(this, Lang.t("Sustained performance"), Lang.t("Keeps the speed steady when the phone gets hot (may lower the peak speed)"),
                Prefs.sustained(this), (v, on) -> Prefs.put(this, "sustained", on)));
        pg.addView(Ui.row(this, Lang.t("Frame skip"), frameskipText(), v -> Dialogs.choose(this, Lang.t("Frame skip"),
                new String[]{Lang.t("Off  (every frame drawn)"), Lang.t("Draw every 2nd frame"), Lang.t("Draw every 3rd frame"), Lang.t("Draw every 4th frame")},
                Prefs.frameskip(this), w -> {
                    Prefs.put(this, "frameskip", w);
                    Ui.toast(this, Lang.t("Applies the next time a game starts"));
                    recreate();
                })));
        pg.addView(Ui.switchRow(this, Lang.t("Faster sound mixing"), Lang.t("Cheaper sound for weak phones. Some voices may sound a little rougher"),
                Prefs.fastAudio(this), (v, on) -> Prefs.put(this, "fastAudio", on)));
        pg.addView(Ui.row(this, Lang.t("Weak phone preset"), Lang.t("One tap: frame skip, faster sound, 22 kHz audio, safe audio buffer, no VSync"), v ->
                Dialogs.message(this, Lang.t("Weak phone preset"), java.util.Arrays.asList(
                        Lang.t("Turns on frame skip (every 2nd frame), automatic frame skip, faster sound mixing, 22 kHz audio, high priority, multi-threaded video and the fastest CPU cores, and turns VSync off."),
                        Lang.t("CPS3 games such as 3rd Strike benefit most. You can change each of these again here.")),
                        Lang.t("Apply"), () -> {
                            Prefs.put(this, "frameskip", 1);
                            Prefs.put(this, "fastAudio", true);
                            Prefs.put(this, "rate", 22050);
                            Prefs.put(this, "fastCores", true);
                            Prefs.put(this, "vsync", false);
                            Prefs.put(this, "latency", 2);
                            Prefs.put(this, "autoSkip", true);
                            Prefs.put(this, "smoothPacing", true);
                            Prefs.put(this, "highPrio", true);
                            Prefs.put(this, "videoThread", true);
                            recreate();
                        }, Lang.t("Cancel"), null)));

        pg = pages[2];
        pg.addView(Ui.section(this, Lang.t("Audio")));
        rateRow = Ui.row(this, Lang.t("Sample rate"), "", v -> Dialogs.choose(this, Lang.t("Audio sample rate"),
                new String[]{Lang.t("44100 Hz"), Lang.t("48000 Hz"), Lang.t("32000 Hz  (lighter)"), Lang.t("22050 Hz  (lightest)")}, rateIndex(), w -> {
                    Prefs.put(this, "rate", w == 0 ? 44100 : w == 1 ? 48000 : w == 2 ? 32000 : 22050);
                    refresh();
                }));
        pg.addView(rateRow);
        latencyRow = Ui.row(this, Lang.t("Audio buffer"), "", v -> Dialogs.choose(this, Lang.t("Audio buffer"),
                new String[]{Lang.t("Low lag  (may crackle)"), Lang.t("Balanced"), Lang.t("Smooth  (recommended)")}, Prefs.latency(this), w -> {
                    Prefs.put(this, "latency", w);
                    refresh();
                }));
        pg.addView(latencyRow);

        pg = pages[4];
        pg.addView(Ui.section(this, Lang.t("Colors")));
        themeRow = Ui.row(this, Lang.t("Theme"), "", v -> chooseTheme());
        pg.addView(themeRow);
        bgRow = Ui.row(this, Lang.t("Background color"), "", v -> pickColor(Lang.t("Background color"), Ui.BG_SWATCHES, Ui.BG, c -> Ui.setTheme(this, c, Ui.ACCENT)));
        pg.addView(bgRow);
        accentRow = Ui.row(this, Lang.t("Accent color"), "", v -> pickColor(Lang.t("Accent color"), Ui.ACCENT_SWATCHES, Ui.ACCENT, c -> Ui.setTheme(this, Ui.BG, c)));
        pg.addView(accentRow);
        pg = pages[4];
        pg.addView(Ui.section(this, Lang.t("Language")));
        langRow = Ui.row(this, Lang.t("Language"), "", v -> Dialogs.choose(this, Lang.t("Language"),
                new String[]{Lang.t("Auto") + " (" + (Lang.isArabic() ? "العربية / English" : "English / العربية") + ")", "English", "العربية"},
                langIndex(), w -> {
                    String nv = w == 1 ? "en" : w == 2 ? "ar" : "auto";
                    if (nv.equals(Lang.pref(this))) return;
                    Lang.setPref(this, nv);
                    Intent it = new Intent(this, LauncherActivity.class);
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(it);
                    finish();
                }));
        pg.addView(langRow);

        pg = pages[5];
        pg.addView(Ui.section(this, Lang.t("Help")));
        pg.addView(Ui.row(this, Icons.LIST, Lang.t("Last game log"), Lang.t("Shows errors and speed measurements (perf lines)"),
                v -> Dialogs.log(this, Prefs.logTail(this, 80))));
        pg.addView(Ui.row(this, Icons.LIST, Lang.t("Online connection log"), Lang.t("How the last online game connected (direct or relay), from the start of the session"),
                v -> {
                    String t = Prefs.logNet(this, 80);
                    Dialogs.log(this, t.length() > 0 ? t : Lang.t("No online connection lines in the last log."));
                }));
        pg.addView(Ui.row(this, Icons.INFO, Lang.t("Credits"), Lang.t("Made by Hexie"), v ->
                Dialogs.message(this, Lang.t("Credits"), java.util.Arrays.asList(
                        Lang.t("Made by Hexie"),
                        Lang.t("FBNeo for Android") + ", v" + appVersion(),
                        Lang.t("Based on FinalBurn Neo, released under its non-commercial licence.")),
                        Lang.t("OK"), null, null, null)));
    }

    private void downloadAllCovers() {
        final java.util.List<String[]> games = LauncherActivity.coverList;
        if (games == null || games.isEmpty()) { Ui.toast(this, Lang.t("Open the game list first so FBNeo knows your games")); return; }
        if (CoverStore.busy()) { Ui.toast(this, Lang.t("A cover download is already running")); return; }
        final LinearLayout[] h = new LinearLayout[1];
        final android.app.Dialog d = Dialogs.base(this, h);
        d.setCancelable(false);
        LinearLayout card = h[0];
        card.addView(Ui.text(this, Lang.t("Download all game covers"), 18, Ui.TEXT, true));
        final android.widget.TextView status = Ui.text(this, Lang.t("Starting…"), 13, Ui.SUB, false);
        card.addView(status, Ui.fillMargins(this, 0, 10, 0, 6));
        final android.widget.ProgressBar bar2 = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar2.setMax(games.size());
        card.addView(bar2, Ui.fillMargins(this, 0, 4, 0, 8));
        final java.util.concurrent.atomic.AtomicBoolean cancel = new java.util.concurrent.atomic.AtomicBoolean();
        final android.widget.TextView btn = Ui.button(this, Lang.t("Cancel"), Ui.TONAL, v -> {
            if (cancel.get() || !CoverStore.busy()) d.dismiss(); else { cancel.set(true); }
        });
        card.addView(btn, Ui.fillMargins(this, 0, 4, 0, 0));
        d.show();
        final android.content.Context app = getApplicationContext();
        new Thread(() -> {
            final int found = CoverStore.downloadMissing(app, games, (done, total, ok, cur) -> runOnUiThread(() -> {
                bar2.setProgress(done);
                status.setText(done + " / " + total + "  ·  " + Lang.t("found ") + ok + (cur.length() > 0 ? "\n" + cur : ""));
            }), cancel);
            runOnUiThread(() -> {
                status.setText(Lang.t("Done. Covers found: ") + found + (cancel.get() ? Lang.t(" (stopped)") : ""));
                btn.setText(Lang.t("Close"));
                cancel.set(true);
            });
        }).start();
    }

    private String appVersion() {
        try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception e) { return "?"; }
    }

    private int langIndex() {
        String p = Lang.pref(this);
        return "en".equals(p) ? 1 : "ar".equals(p) ? 2 : 0;
    }

    private int filterIndex() {
        String f = Prefs.filter(this);
        return "sharp".equals(f) ? 0 : "smooth".equals(f) ? 1 : 2;
    }

    private int rateIndex() {
        int r = Prefs.sampleRate(this);
        return r == 44100 ? 0 : r == 48000 ? 1 : r == 32000 ? 2 : 3;
    }

    private int countersIndex() {
        int m = Prefs.counters(this);
        for (int i = 0; i < COUNTER_MASKS.length; i++) if (COUNTER_MASKS[i] == m) return i;
        return m == 0 ? 0 : 1;
    }

    private String frameskipText() {
        int n = Prefs.frameskip(this);
        return n == 0 ? Lang.t("Off") : Lang.t("Draws every ") + (n + 1) + (n == 1 ? "nd" : n == 2 ? "rd" : "th") + Lang.t(" frame");
    }

    private int alphaIndex() {
        int p = Prefs.touchAlpha(this);
        int[] v = {25, 40, 55, 70, 90};
        int best = 2;
        for (int i = 0; i < v.length; i++) if (Math.abs(v[i] - p) < Math.abs(v[best] - p)) best = i;
        return best;
    }

    private void refresh() {
        String tn = Lang.t("Custom");
        for (int i = 0; i < Ui.THEMES.length; i++) if (Ui.THEMES[i][0] == Ui.BG && Ui.THEMES[i][1] == Ui.ACCENT) tn = Lang.t(Ui.THEME_NAMES[i]);
        Ui.setSub(themeRow, tn);
        Ui.setSub(bgRow, String.format("#%06X", Ui.BG & 0xFFFFFF));
        Ui.setSub(accentRow, String.format("#%06X", Ui.ACCENT & 0xFFFFFF));
        boolean ok = Prefs.hasAccess(this);
        Ui.setSub(accessRow, ok ? Lang.t("Granted") : Lang.t("Not granted - tap to allow (needed to read ROMs and Lua scripts)"));
        Ui.setSub(mainRow, Prefs.rootDir(this));
        Ui.setSub(dataRow, Prefs.dataDir(this));
        Ui.setSub(romRow, Prefs.romDir(this));
        Ui.setSub(luaRow, Prefs.luaDir(this));
        String d = Prefs.defaultLua(this);
        Ui.setSub(luaDefRow, d.length() == 0 ? Lang.t("None (you can pick a script per game)") : d);
        Ui.setSub(filterRow, new String[]{Lang.t("Sharp pixels"), Lang.t("Smooth"), Lang.t("Best")}[filterIndex()]);
        Ui.setSub(aspectRow, Lang.t(Prefs.ASPECTS[Prefs.aspect(this)][0]));
        Ui.setSub(stickRow, new String[]{Lang.t("Precise"), Lang.t("Arcade"), Lang.t("Forgiving")}[Prefs.stickFeel(this)]);
        Ui.setSub(rateRow, Prefs.sampleRate(this) + " Hz");
        Ui.setSub(countersRow, new String[]{Lang.t("Off"), Lang.t("FPS"), Lang.t("FPS and speed"), Lang.t("FPS, speed and screen refresh"), Lang.t("Speed and screen refresh")}[countersIndex()]);
        Ui.setSub(rendererRow, Prefs.vulkan(this) ? Lang.t("GPU (Vulkan, beta)") : Prefs.softRender(this) ? Lang.t("Software") : Lang.t("GPU (OpenGL ES)"));
        Ui.setSub(langRow, "en".equals(Lang.pref(this)) ? "English" : "ar".equals(Lang.pref(this)) ? "العربية"
                : Lang.t("Auto") + " (" + (Lang.isArabic() ? "العربية" : "English") + ")");
        Ui.setSub(latencyRow, new String[]{Lang.t("Low lag"), Lang.t("Balanced"), Lang.t("Smooth")}[Prefs.latency(this)]);
    }

    private void pick(int req, String start, String title) {
        Intent i = new Intent(this, FileBrowserActivity.class);
        i.putExtra("mode", "folder");
        i.putExtra("start", start);
        i.putExtra("title", title);
        startActivityForResult(i, req);
    }

    private void pickFile() {
        Intent i = new Intent(this, FileBrowserActivity.class);
        i.putExtra("mode", "file");
        i.putExtra("ext", ".lua");
        i.putExtra("start", Prefs.luaDir(this));
        i.putExtra("title", Lang.t("Choose a Lua script"));
        startActivityForResult(i, REQ_LUADEF);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (res != RESULT_OK || data == null) return;
        String p = data.getStringExtra("path");
        if (p == null) return;
        if (req == REQ_ROOT) {
            Prefs.sp(this).edit().remove("dataDir").remove("romDir").remove("luaDir").remove("mameDir").apply();
            Prefs.put(this, "rootDir", p);
            Prefs.migrateLayout(this);
        } else if (req == REQ_DATA) {
            boolean romsDefault = Prefs.romDir(this).equals(Prefs.dataDir(this) + "roms/");
            boolean luaDefault = Prefs.luaDir(this).equals(Prefs.dataDir(this) + "lua/");
            Prefs.put(this, "dataDir", p);
            if (romsDefault) Prefs.sp(this).edit().remove("romDir").apply();
            if (luaDefault) Prefs.sp(this).edit().remove("luaDir").apply();
        } else if (req == REQ_ROMS) Prefs.put(this, "romDir", p);
        else if (req == REQ_LUADIR) Prefs.put(this, "luaDir", p);
        else if (req == REQ_LUADEF) Prefs.put(this, "luaDefault", p);
        refresh();
    }
}
