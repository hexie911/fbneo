package com.fbneo.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class SettingsActivity extends Activity {
    private static final int REQ_DATA = 1, REQ_ROMS = 2, REQ_LUADIR = 3, REQ_LUADEF = 4;

    private LinearLayout root;
    private View aspectRow, stickRow, accessRow, dataRow, romRow, luaRow, luaDefRow, filterRow, rateRow, latencyRow;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = Ui.vertical(this);
        page.setBackgroundColor(Ui.BG);
        page.addView(Ui.topBar(this, "Settings", this::finish));
        ScrollView sv = new ScrollView(this);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root = Ui.vertical(this);
        root.setPadding(0, 0, 0, Ui.dp(this, 32));
        sv.addView(root);
        page.addView(sv, new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(page);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void build() {
        root.addView(Ui.section(this, "Games and files"));
        accessRow = Ui.row(this, Icons.FOLDER, "All files access", "", v -> Prefs.requestAccess(this));
        root.addView(accessRow);
        romRow = Ui.row(this, Icons.LIST, "ROM folder", "", v -> pick(REQ_ROMS, Prefs.romDir(this), "ROM folder"));
        root.addView(romRow);
        luaRow = Ui.row(this, Icons.SCRIPT, "Lua scripts folder", "", v -> pick(REQ_LUADIR, Prefs.luaDir(this), "Lua scripts folder"));
        root.addView(luaRow);
        luaDefRow = Ui.row(this, Icons.SCRIPT, "Default Lua script", "", v -> {
            if (Prefs.defaultLua(this).length() > 0) {
                Dialogs.choose(this, "Default Lua script", new String[]{"Choose another script", "Clear (no default)"}, -1, w -> {
                    if (w == 0) pickFile();
                    else { Prefs.put(this, "luaDefault", ""); refresh(); }
                });
            } else pickFile();
        });
        root.addView(luaDefRow);
        dataRow = Ui.row(this, Icons.FOLDER, "Data folder", "", v -> pick(REQ_DATA, Prefs.dataDir(this), "Data folder (config, saves, logs)"));
        root.addView(dataRow);

        root.addView(Ui.section(this, "Controller"));
        root.addView(Ui.row(this, Icons.GAMEPAD, "Map controller buttons",
                "Buttons, swap player, Lua hotkeys, save states",
                v -> startActivity(new Intent(this, MappingActivity.class))));
        root.addView(Ui.switchRow(this, "Arcade input smoothing", "Never loses a quick stick sweep, so half circles and fireballs come out reliably",
                Prefs.smoothInput(this), (v, on) -> Prefs.put(this, "smoothInput", on)));
        stickRow = Ui.row(this, "Stick and D-pad feel", "", v -> Dialogs.choose(this, "Stick and D-pad feel",
                new String[]{"Precise  (stick must be pushed far)", "Arcade  (recommended)", "Forgiving  (wide diagonals)"},
                Prefs.stickFeel(this), w -> {
                    Prefs.put(this, "stickFeel", w);
                    refresh();
                }));
        root.addView(stickRow);
        root.addView(Ui.switchRow(this, "Start with the pad on player 2", "You can also swap while playing", Prefs.startSwapped(this),
                (v, on) -> Prefs.put(this, "swap", on)));

        root.addView(Ui.section(this, "Video"));
        filterRow = Ui.row(this, "Scaling", "", v -> Dialogs.choose(this, "Scaling",
                new String[]{"Sharp pixels", "Smooth", "Best (smooth, high quality)"}, filterIndex(), w -> {
                    Prefs.put(this, "filter", w == 0 ? "sharp" : w == 1 ? "smooth" : "best");
                    refresh();
                }));
        root.addView(filterRow);
        aspectRow = Ui.row(this, "Screen shape", "", v -> {
            String[] names = new String[Prefs.ASPECTS.length];
            for (int i = 0; i < names.length; i++) names[i] = Prefs.ASPECTS[i][0];
            Dialogs.choose(this, "Screen shape", names, Prefs.aspect(this), w -> {
                Prefs.put(this, "aspect", w);
                refresh();
            });
        });
        root.addView(aspectRow);
        root.addView(Ui.switchRow(this, "Integer scaling", "Crisp pixels, may leave black borders", Prefs.integerScale(this),
                (v, on) -> Prefs.put(this, "integer", on)));
        root.addView(Ui.switchRow(this, "Show FPS", "Frames per second in the corner", Prefs.showFps(this),
                (v, on) -> Prefs.put(this, "fps", on)));
        root.addView(Ui.switchRow(this, "VSync", "Smooth picture. Turn off if the game feels choppy or slow", Prefs.vsync(this),
                (v, on) -> Prefs.put(this, "vsync", on)));
        root.addView(Ui.switchRow(this, "Prefer a 60 Hz screen mode", "Avoids uneven frames on 90/120 Hz phones", Prefs.match60(this),
                (v, on) -> Prefs.put(this, "match60", on)));
        root.addView(Ui.switchRow(this, "Rotate with the phone", "Off = always landscape", Prefs.autoRotate(this),
                (v, on) -> Prefs.put(this, "autoRotate", on)));

        root.addView(Ui.section(this, "On-screen controls"));
        root.addView(Ui.switchRow(this, "On-screen controls in every game", "Turn on to start every game with the touch controls. Off = physical controller or keyboard only. Can also be switched in the pause menu; edit the layout from there too",
                Prefs.touchOn(this), (v, on) -> Prefs.put(this, "touchOn", on)));
        root.addView(Ui.row(this, "Opacity", Prefs.touchAlpha(this) + "%", v -> Dialogs.choose(this, "Opacity of on-screen controls",
                new String[]{"25%", "40%", "55%", "70%", "90%"}, alphaIndex(), w -> {
                    Prefs.put(this, "touchAlpha", new int[]{25, 40, 55, 70, 90}[w]);
                    refresh();
                })));
        root.addView(Ui.section(this, "Performance"));
        root.addView(Ui.switchRow(this, "Use the fastest CPU cores", "Keeps the game off the slow cores. Recommended", Prefs.fastCores(this),
                (v, on) -> Prefs.put(this, "fastCores", on)));
        root.addView(Ui.switchRow(this, "Battery saver", "Sleeps between frames. Cooler, but heavy games like 3rd Strike can get slower", Prefs.batterySaver(this),
                (v, on) -> Prefs.put(this, "batterySaver", on)));

        root.addView(Ui.section(this, "Audio"));
        rateRow = Ui.row(this, "Sample rate", "", v -> Dialogs.choose(this, "Audio sample rate",
                new String[]{"44100 Hz", "48000 Hz", "22050 Hz"}, rateIndex(), w -> {
                    Prefs.put(this, "rate", w == 0 ? 44100 : w == 1 ? 48000 : 22050);
                    refresh();
                }));
        root.addView(rateRow);
        latencyRow = Ui.row(this, "Audio buffer", "", v -> Dialogs.choose(this, "Audio buffer",
                new String[]{"Low lag  (may crackle)", "Balanced", "Smooth  (recommended)"}, Prefs.latency(this), w -> {
                    Prefs.put(this, "latency", w);
                    refresh();
                }));
        root.addView(latencyRow);

        root.addView(Ui.section(this, "Help"));
        root.addView(Ui.row(this, Icons.LIST, "Last game log", "Shows errors and speed measurements (perf lines)",
                v -> Dialogs.log(this, Prefs.logTail(this, 80))));
        root.addView(Ui.row(this, Icons.INFO, "About", "FBNeo with Lua scripting on Android", v ->
                Dialogs.message(this, "About", java.util.Arrays.asList(
                        "FinalBurn Neo (SDL2 port) with its Lua engine, packaged as an Android app.",
                        "While playing, Back opens the pause menu. Lua hotkeys 1-9 are set in Controller mapping (L1 = hotkey 1 by default).",
                        "FBNeo is distributed under its own non-commercial licence (see the FBNeo project)."),
                        "OK", null, null, null)));
    }

    private int filterIndex() {
        String f = Prefs.filter(this);
        return "sharp".equals(f) ? 0 : "smooth".equals(f) ? 1 : 2;
    }

    private int rateIndex() {
        int r = Prefs.sampleRate(this);
        return r == 44100 ? 0 : r == 48000 ? 1 : 2;
    }

    private int alphaIndex() {
        int p = Prefs.touchAlpha(this);
        int[] v = {25, 40, 55, 70, 90};
        int best = 2;
        for (int i = 0; i < v.length; i++) if (Math.abs(v[i] - p) < Math.abs(v[best] - p)) best = i;
        return best;
    }

    private void refresh() {
        boolean ok = Prefs.hasAccess(this);
        Ui.setSub(accessRow, ok ? "Granted" : "Not granted - tap to allow (needed to read ROMs and Lua scripts)");
        Ui.setSub(dataRow, Prefs.dataDir(this));
        Ui.setSub(romRow, Prefs.romDir(this));
        Ui.setSub(luaRow, Prefs.luaDir(this));
        String d = Prefs.defaultLua(this);
        Ui.setSub(luaDefRow, d.length() == 0 ? "None (you can pick a script per game)" : d);
        Ui.setSub(filterRow, new String[]{"Sharp pixels", "Smooth", "Best"}[filterIndex()]);
        Ui.setSub(aspectRow, Prefs.ASPECTS[Prefs.aspect(this)][0]);
        Ui.setSub(stickRow, new String[]{"Precise", "Arcade", "Forgiving"}[Prefs.stickFeel(this)]);
        Ui.setSub(rateRow, Prefs.sampleRate(this) + " Hz");
        Ui.setSub(latencyRow, new String[]{"Low lag", "Balanced", "Smooth"}[Prefs.latency(this)]);
    }

    private void pick(int req, String start, String title) {
        Intent i = new Intent(this, FileBrowserActivity.class);
        i.putExtra("mode", "folder");
        i.putExtra("start", start);
        i.putExtra("title", title);
        startActivityForResult(i, req);
    }

    private void pickFile() {
        Intent i = new Intent(this, FileBrowserActivity.class);
        i.putExtra("mode", "file");
        i.putExtra("ext", ".lua");
        i.putExtra("start", Prefs.luaDir(this));
        i.putExtra("title", "Choose a Lua script");
        startActivityForResult(i, REQ_LUADEF);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (res != RESULT_OK || data == null) return;
        String p = data.getStringExtra("path");
        if (p == null) return;
        if (req == REQ_DATA) {
            boolean romsDefault = Prefs.romDir(this).equals(Prefs.dataDir(this) + "roms/");
            boolean luaDefault = Prefs.luaDir(this).equals(Prefs.dataDir(this) + "lua/");
            Prefs.put(this, "dataDir", p);
            if (romsDefault) Prefs.sp(this).edit().remove("romDir").apply();
            if (luaDefault) Prefs.sp(this).edit().remove("luaDir").apply();
        } else if (req == REQ_ROMS) Prefs.put(this, "romDir", p);
        else if (req == REQ_LUADIR) Prefs.put(this, "luaDir", p);
        else if (req == REQ_LUADEF) Prefs.put(this, "luaDefault", p);
        refresh();
    }
}
