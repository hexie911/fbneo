package com.fbneo.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class SettingsActivity extends Activity {
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Lang.wrap(base));
    }

    private static final int REQ_DATA = 1, REQ_ROMS = 2, REQ_LUADIR = 3, REQ_LUADEF = 4, REQ_ROOT = 5;

    private LinearLayout root;
    private static final int[] COUNTER_MASKS = {0, 1, 3, 7, 6};
    private View countersRow, rendererRow;
    private View langRow, mainRow, aspectRow, stickRow, accessRow, dataRow, romRow, luaRow, luaDefRow, filterRow, rateRow, latencyRow;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = Ui.vertical(this);
        page.setBackgroundColor(Ui.BG);
        page.addView(Ui.topBar(this, Lang.t("Settings"), this::finish));
        ScrollView sv = new ScrollView(this);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root = Ui.vertical(this);
        root.setPadding(0, 0, 0, Ui.dp(this, 32));
        sv.addView(root);
        page.addView(sv, new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(page);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void build() {
        root.addView(Ui.section(this, Lang.t("Games and files")));
        mainRow = Ui.row(this, Icons.FOLDER, Lang.t("Main folder (fbneo, mame)"), "", v -> pick(REQ_ROOT, Prefs.rootDir(this), Lang.t("Main folder")));
        root.addView(mainRow);
        accessRow = Ui.row(this, Icons.FOLDER, Lang.t("All files access"), "", v -> Prefs.requestAccess(this));
        root.addView(accessRow);
        romRow = Ui.row(this, Icons.LIST, Lang.t("ROM folder"), "", v -> pick(REQ_ROMS, Prefs.romDir(this), Lang.t("ROM folder")));
        root.addView(romRow);
        luaRow = Ui.row(this, Icons.SCRIPT, Lang.t("Lua scripts folder"), "", v -> pick(REQ_LUADIR, Prefs.luaDir(this), Lang.t("Lua scripts folder")));
        root.addView(luaRow);
        luaDefRow = Ui.row(this, Icons.SCRIPT, Lang.t("Default Lua script"), "", v -> {
            if (Prefs.defaultLua(this).length() > 0) {
                Dialogs.choose(this, Lang.t("Default Lua script"), new String[]{Lang.t("Choose another script"), Lang.t("Clear (no default)")}, -1, w -> {
                    if (w == 0) pickFile();
                    else { Prefs.put(this, "luaDefault", ""); refresh(); }
                });
            } else pickFile();
        });
        root.addView(luaDefRow);
        dataRow = Ui.row(this, Icons.FOLDER, Lang.t("FBNeo data folder"), "", v -> pick(REQ_DATA, Prefs.dataDir(this), Lang.t("Data folder (config, saves, logs)")));
        root.addView(dataRow);

        root.addView(Ui.section(this, Lang.t("Controller")));
        root.addView(Ui.row(this, Icons.GAMEPAD, Lang.t("Map controller buttons"),
                Lang.t("Buttons, swap player, Lua hotkeys, save states"),
                v -> startActivity(new Intent(this, MappingActivity.class))));
        root.addView(Ui.switchRow(this, Lang.t("Arcade input smoothing"), Lang.t("Never loses a quick stick sweep, so half circles and fireballs come out reliably"),
                Prefs.smoothInput(this), (v, on) -> Prefs.put(this, "smoothInput", on)));
        stickRow = Ui.row(this, Lang.t("Stick and D-pad feel"), "", v -> Dialogs.choose(this, Lang.t("Stick and D-pad feel"),
                new String[]{Lang.t("Precise  (stick must be pushed far)"), Lang.t("Arcade  (recommended)"), Lang.t("Forgiving  (wide diagonals)")},
                Prefs.stickFeel(this), w -> {
                    Prefs.put(this, "stickFeel", w);
                    refresh();
                }));
        root.addView(stickRow);
        root.addView(Ui.switchRow(this, Lang.t("Start with the pad on player 2"), Lang.t("You can also swap while playing"), Prefs.startSwapped(this),
                (v, on) -> Prefs.put(this, "swap", on)));

        root.addView(Ui.section(this, Lang.t("Video")));
        filterRow = Ui.row(this, Lang.t("Scaling"), "", v -> Dialogs.choose(this, Lang.t("Scaling"),
                new String[]{Lang.t("Sharp pixels"), Lang.t("Smooth"), Lang.t("Best (smooth, high quality)")}, filterIndex(), w -> {
                    Prefs.put(this, "filter", w == 0 ? "sharp" : w == 1 ? "smooth" : "best");
                    refresh();
                }));
        root.addView(filterRow);
        aspectRow = Ui.row(this, Lang.t("Screen shape"), "", v -> {
            String[] names = new String[Prefs.ASPECTS.length];
            for (int i = 0; i < names.length; i++) names[i] = Lang.t(Prefs.ASPECTS[i][0]);
            Dialogs.choose(this, Lang.t("Screen shape"), names, Prefs.aspect(this), w -> {
                Prefs.put(this, "aspect", w);
                refresh();
            });
        });
        root.addView(aspectRow);
        root.addView(Ui.switchRow(this, Lang.t("Integer scaling"), Lang.t("Crisp pixels, may leave black borders"), Prefs.integerScale(this),
                (v, on) -> Prefs.put(this, "integer", on)));
        countersRow = Ui.row(this, Lang.t("On-screen counters"), "", v -> Dialogs.choose(this, Lang.t("On-screen counters"),
                new String[]{Lang.t("Off"), Lang.t("FPS"), Lang.t("FPS and speed"), Lang.t("FPS, speed and screen refresh"), Lang.t("Speed and screen refresh")},
                countersIndex(), w -> {
                    Prefs.put(this, "counters", COUNTER_MASKS[w]);
                    refresh();
                }));
        root.addView(countersRow);
        rendererRow = Ui.row(this, Lang.t("Renderer"), "", v -> Dialogs.choose(this, Lang.t("Renderer"),
                new String[]{Lang.t("GPU  (OpenGL ES, recommended)"), Lang.t("Software  (compatibility, slower)"), Lang.t("GPU  (Vulkan, beta)")},
                Prefs.vulkan(this) ? 2 : Prefs.softRender(this) ? 1 : 0, w -> {
                    Prefs.put(this, "softRender", w == 1);
                    Prefs.put(this, "vulkan", w == 2);
                    refresh();
                }));
        root.addView(rendererRow);
        root.addView(Ui.switchRow(this, Lang.t("Multi-threaded video (experimental)"), Lang.t("Draws and shows the picture on a second thread so the game itself runs faster. Falls back by itself if the phone does not support it"),
                Prefs.videoThread(this), (v, on) -> Prefs.put(this, "videoThread", on)));
        root.addView(Ui.switchRow(this, Lang.t("VSync"), Lang.t("Smooth picture. Turn off if the game feels choppy or slow"), Prefs.vsync(this),
                (v, on) -> Prefs.put(this, "vsync", on)));
        root.addView(Ui.switchRow(this, Lang.t("Prefer a 60 Hz screen mode"), Lang.t("Avoids uneven frames on 90/120 Hz phones"), Prefs.match60(this),
                (v, on) -> Prefs.put(this, "match60", on)));
        root.addView(Ui.switchRow(this, Lang.t("Rotate with the phone"), Lang.t("Off = always landscape"), Prefs.autoRotate(this),
                (v, on) -> Prefs.put(this, "autoRotate", on)));

        root.addView(Ui.section(this, Lang.t("On-screen controls")));
        root.addView(Ui.switchRow(this, Lang.t("On-screen controls in every game"), Lang.t("Turn on to start every game with the touch controls. Off = physical controller or keyboard only. Can also be switched in the pause menu; edit the layout from there too"),
                Prefs.touchOn(this), (v, on) -> Prefs.put(this, "touchOn", on)));
        root.addView(Ui.row(this, Lang.t("Opacity"), Prefs.touchAlpha(this) + "%", v -> Dialogs.choose(this, Lang.t("Opacity of on-screen controls"),
                new String[]{"25%", "40%", "55%", "70%", "90%"}, alphaIndex(), w -> {
                    Prefs.put(this, "touchAlpha", new int[]{25, 40, 55, 70, 90}[w]);
                    refresh();
                })));
        root.addView(Ui.section(this, Lang.t("Performance")));
        root.addView(Ui.switchRow(this, Lang.t("Use the fastest CPU cores"), Lang.t("Keeps the game off the slow cores. Recommended"), Prefs.fastCores(this),
                (v, on) -> Prefs.put(this, "fastCores", on)));
        root.addView(Ui.switchRow(this, Lang.t("Battery saver"), Lang.t("Sleeps between frames. Cooler, but heavy games like 3rd Strike can get slower"), Prefs.batterySaver(this),
                (v, on) -> Prefs.put(this, "batterySaver", on)));

        root.addView(Ui.switchRow(this, Lang.t("Smooth frame timing"), Lang.t("Frames come at an even pace instead of in the audio device's bursts. Turn off only if something looks wrong"),
                Prefs.smoothPacing(this), (v, on) -> Prefs.put(this, "smoothPacing", on)));
        root.addView(Ui.switchRow(this, Lang.t("Match the screen's refresh rate"), Lang.t("Arcade games run at 59.6 fps but screens at 60 Hz. This runs the game at the screen's rate (up to 1% faster) so no frame is ever shown twice"),
                Prefs.matchRefresh(this), (v, on) -> Prefs.put(this, "matchRefresh", on)));
        root.addView(Ui.switchRow(this, Lang.t("Auto frame skip"), Lang.t("When the phone falls behind, skip drawing a few frames to keep the game at full speed"),
                Prefs.autoSkip(this), (v, on) -> Prefs.put(this, "autoSkip", on)));
        root.addView(Ui.switchRow(this, Lang.t("High priority"), Lang.t("Asks Android to give the game thread more CPU time"),
                Prefs.highPrio(this), (v, on) -> Prefs.put(this, "highPrio", on)));
        root.addView(Ui.switchRow(this, Lang.t("Sustained performance"), Lang.t("Keeps the speed steady when the phone gets hot (may lower the peak speed)"),
                Prefs.sustained(this), (v, on) -> Prefs.put(this, "sustained", on)));
        root.addView(Ui.row(this, Lang.t("Frame skip"), frameskipText(), v -> Dialogs.choose(this, Lang.t("Frame skip"),
                new String[]{Lang.t("Off  (every frame drawn)"), Lang.t("Draw every 2nd frame"), Lang.t("Draw every 3rd frame"), Lang.t("Draw every 4th frame")},
                Prefs.frameskip(this), w -> {
                    Prefs.put(this, "frameskip", w);
                    Ui.toast(this, Lang.t("Applies the next time a game starts"));
                    recreate();
                })));
        root.addView(Ui.switchRow(this, Lang.t("Faster sound mixing"), Lang.t("Cheaper sound for weak phones. Some voices may sound a little rougher"),
                Prefs.fastAudio(this), (v, on) -> Prefs.put(this, "fastAudio", on)));
        root.addView(Ui.row(this, Lang.t("Weak phone preset"), Lang.t("One tap: frame skip, faster sound, 22 kHz audio, safe audio buffer, no VSync"), v ->
                Dialogs.message(this, Lang.t("Weak phone preset"), java.util.Arrays.asList(
                        Lang.t("Turns on frame skip (every 2nd frame), automatic frame skip, faster sound mixing, 22 kHz audio, high priority, multi-threaded video and the fastest CPU cores, and turns VSync off."),
                        Lang.t("CPS3 games such as 3rd Strike benefit most. You can change each of these again here.")),
                        Lang.t("Apply"), () -> {
                            Prefs.put(this, "frameskip", 1);
                            Prefs.put(this, "fastAudio", true);
                            Prefs.put(this, "rate", 22050);
                            Prefs.put(this, "fastCores", true);
                            Prefs.put(this, "vsync", false);
                            Prefs.put(this, "latency", 2);
                            Prefs.put(this, "autoSkip", true);
                            Prefs.put(this, "smoothPacing", true);
                            Prefs.put(this, "highPrio", true);
                            Prefs.put(this, "videoThread", true);
                            recreate();
                        }, Lang.t("Cancel"), null)));

        root.addView(Ui.section(this, Lang.t("Audio")));
        rateRow = Ui.row(this, Lang.t("Sample rate"), "", v -> Dialogs.choose(this, Lang.t("Audio sample rate"),
                new String[]{Lang.t("44100 Hz"), Lang.t("48000 Hz"), Lang.t("32000 Hz  (lighter)"), Lang.t("22050 Hz  (lightest)")}, rateIndex(), w -> {
                    Prefs.put(this, "rate", w == 0 ? 44100 : w == 1 ? 48000 : w == 2 ? 32000 : 22050);
                    refresh();
                }));
        root.addView(rateRow);
        latencyRow = Ui.row(this, Lang.t("Audio buffer"), "", v -> Dialogs.choose(this, Lang.t("Audio buffer"),
                new String[]{Lang.t("Low lag  (may crackle)"), Lang.t("Balanced"), Lang.t("Smooth  (recommended)")}, Prefs.latency(this), w -> {
                    Prefs.put(this, "latency", w);
                    refresh();
                }));
        root.addView(latencyRow);

        root.addView(Ui.section(this, Lang.t("Language")));
        langRow = Ui.row(this, Lang.t("Language"), "", v -> Dialogs.choose(this, Lang.t("Language"),
                new String[]{Lang.t("Auto") + " (" + (Lang.isArabic() ? "العربية / English" : "English / العربية") + ")", "English", "العربية"},
                langIndex(), w -> {
                    String nv = w == 1 ? "en" : w == 2 ? "ar" : "auto";
                    if (nv.equals(Lang.pref(this))) return;
                    Lang.setPref(this, nv);
                    Intent it = new Intent(this, LauncherActivity.class);
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(it);
                    finish();
                }));
        root.addView(langRow);

        root.addView(Ui.section(this, Lang.t("Help")));
        root.addView(Ui.row(this, Icons.LIST, Lang.t("Last game log"), Lang.t("Shows errors and speed measurements (perf lines)"),
                v -> Dialogs.log(this, Prefs.logTail(this, 80))));
        root.addView(Ui.row(this, Icons.INFO, Lang.t("Credits"), Lang.t("Made by Hexie"), v ->
                Dialogs.message(this, Lang.t("Credits"), java.util.Arrays.asList(
                        Lang.t("Made by Hexie"),
                        Lang.t("FBNeo for Android, v1.20"),
                        Lang.t("Based on FinalBurn Neo, released under its non-commercial licence.")),
                        Lang.t("OK"), null, null, null)));
    }

    private int langIndex() {
        String p = Lang.pref(this);
        return "en".equals(p) ? 1 : "ar".equals(p) ? 2 : 0;
    }

    private int filterIndex() {
        String f = Prefs.filter(this);
        return "sharp".equals(f) ? 0 : "smooth".equals(f) ? 1 : 2;
    }

    private int rateIndex() {
        int r = Prefs.sampleRate(this);
        return r == 44100 ? 0 : r == 48000 ? 1 : r == 32000 ? 2 : 3;
    }

    private int countersIndex() {
        int m = Prefs.counters(this);
        for (int i = 0; i < COUNTER_MASKS.length; i++) if (COUNTER_MASKS[i] == m) return i;
        return m == 0 ? 0 : 1;
    }

    private String frameskipText() {
        int n = Prefs.frameskip(this);
        return n == 0 ? Lang.t("Off") : Lang.t("Draws every ") + (n + 1) + (n == 1 ? "nd" : n == 2 ? "rd" : "th") + Lang.t(" frame");
    }

    private int alphaIndex() {
        int p = Prefs.touchAlpha(this);
        int[] v = {25, 40, 55, 70, 90};
        int best = 2;
        for (int i = 0; i < v.length; i++) if (Math.abs(v[i] - p) < Math.abs(v[best] - p)) best = i;
        return best;
    }

    private void refresh() {
        boolean ok = Prefs.hasAccess(this);
        Ui.setSub(accessRow, ok ? Lang.t("Granted") : Lang.t("Not granted - tap to allow (needed to read ROMs and Lua scripts)"));
        Ui.setSub(mainRow, Prefs.rootDir(this));
        Ui.setSub(dataRow, Prefs.dataDir(this));
        Ui.setSub(romRow, Prefs.romDir(this));
        Ui.setSub(luaRow, Prefs.luaDir(this));
        String d = Prefs.defaultLua(this);
        Ui.setSub(luaDefRow, d.length() == 0 ? Lang.t("None (you can pick a script per game)") : d);
        Ui.setSub(filterRow, new String[]{Lang.t("Sharp pixels"), Lang.t("Smooth"), Lang.t("Best")}[filterIndex()]);
        Ui.setSub(aspectRow, Lang.t(Prefs.ASPECTS[Prefs.aspect(this)][0]));
        Ui.setSub(stickRow, new String[]{Lang.t("Precise"), Lang.t("Arcade"), Lang.t("Forgiving")}[Prefs.stickFeel(this)]);
        Ui.setSub(rateRow, Prefs.sampleRate(this) + " Hz");
        Ui.setSub(countersRow, new String[]{Lang.t("Off"), Lang.t("FPS"), Lang.t("FPS and speed"), Lang.t("FPS, speed and screen refresh"), Lang.t("Speed and screen refresh")}[countersIndex()]);
        Ui.setSub(rendererRow, Prefs.vulkan(this) ? Lang.t("GPU (Vulkan, beta)") : Prefs.softRender(this) ? Lang.t("Software") : Lang.t("GPU (OpenGL ES)"));
        Ui.setSub(langRow, "en".equals(Lang.pref(this)) ? "English" : "ar".equals(Lang.pref(this)) ? "العربية"
                : Lang.t("Auto") + " (" + (Lang.isArabic() ? "العربية" : "English") + ")");
        Ui.setSub(latencyRow, new String[]{Lang.t("Low lag"), Lang.t("Balanced"), Lang.t("Smooth")}[Prefs.latency(this)]);
    }

    private void pick(int req, String start, String title) {
        Intent i = new Intent(this, FileBrowserActivity.class);
        i.putExtra("mode", "folder");
        i.putExtra("start", start);
        i.putExtra("title", title);
        startActivityForResult(i, req);
    }

    private void pickFile() {
        Intent i = new Intent(this, FileBrowserActivity.class);
        i.putExtra("mode", "file");
        i.putExtra("ext", ".lua");
        i.putExtra("start", Prefs.luaDir(this));
        i.putExtra("title", Lang.t("Choose a Lua script"));
        startActivityForResult(i, REQ_LUADEF);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (res != RESULT_OK || data == null) return;
        String p = data.getStringExtra("path");
        if (p == null) return;
        if (req == REQ_ROOT) {
            Prefs.sp(this).edit().remove("dataDir").remove("romDir").remove("luaDir").remove("mameDir").apply();
            Prefs.put(this, "rootDir", p);
            Prefs.migrateLayout(this);
        } else if (req == REQ_DATA) {
            boolean romsDefault = Prefs.romDir(this).equals(Prefs.dataDir(this) + "roms/");
            boolean luaDefault = Prefs.luaDir(this).equals(Prefs.dataDir(this) + "lua/");
            Prefs.put(this, "dataDir", p);
            if (romsDefault) Prefs.sp(this).edit().remove("romDir").apply();
            if (luaDefault) Prefs.sp(this).edit().remove("luaDir").apply();
        } else if (req == REQ_ROMS) Prefs.put(this, "romDir", p);
        else if (req == REQ_LUADIR) Prefs.put(this, "luaDir", p);
        else if (req == REQ_LUADEF) Prefs.put(this, "luaDefault", p);
        refresh();
    }
}
