package com.fbneo.android;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class SettingsActivity extends Activity {
    private static final int REQ_DATA = 1, REQ_ROMS = 2, REQ_LUADIR = 3, REQ_LUADEF = 4;

    private LinearLayout root;
    private static final int[] COUNTER_MASKS = {0, 1, 3, 7, 6};
    private View countersRow, rendererRow;
    private View aspectRow, stickRow, accessRow, dataRow, romRow, luaRow, luaDefRow, filterRow, rateRow, latencyRow;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout page = Ui.vertical(this);
        page.setBackgroundColor(Ui.BG);
        page.addView(Ui.topBar(this, "Settings", this::finish));
        ScrollView sv = new ScrollView(this);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root = Ui.vertical(this);
        root.setPadding(0, 0, 0, Ui.dp(this, 32));
        sv.addView(root);
        page.addView(sv, new LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(page);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void build() {
        root.addView(Ui.section(this, "Games and files"));
        accessRow = Ui.row(this, Icons.FOLDER, "All files access", "", v -> Prefs.requestAccess(this));
        root.addView(accessRow);
        romRow = Ui.row(this, Icons.LIST, "ROM folder", "", v -> pick(REQ_ROMS, Prefs.romDir(this), "ROM folder"));
        root.addView(romRow);
        luaRow = Ui.row(this, Icons.SCRIPT, "Lua scripts folder", "", v -> pick(REQ_LUADIR, Prefs.luaDir(this), "Lua scripts folder"));
        root.addView(luaRow);
        luaDefRow = Ui.row(this, Icons.SCRIPT, "Default Lua script", "", v -> {
            if (Prefs.defaultLua(this).length() > 0) {
                Dialogs.choose(this, "Default Lua script", new String[]{"Choose another script", "Clear (no default)"}, -1, w -> {
                    if (w == 0) pickFile();
                    else { Prefs.put(this, "luaDefault", ""); refresh(); }
                });
            } else pickFile();
        });
        root.addView(luaDefRow);
        dataRow = Ui.row(this, Icons.FOLDER, "Data folder", "", v -> pick(REQ_DATA, Prefs.dataDir(this), "Data folder (config, saves, logs)"));
        root.addView(dataRow);

        root.addView(Ui.section(this, "Controller"));
        root.addView(Ui.row(this, Icons.GAMEPAD, "Map controller buttons",
                "Buttons, swap player, Lua hotkeys, save states",
                v -> startActivity(new Intent(this, MappingActivity.class))));
        root.addView(Ui.switchRow(this, "Arcade input smoothing", "Never loses a quick stick sweep, so half circles and fireballs come out reliably",
                Prefs.smoothInput(this), (v, on) -> Prefs.put(this, "smoothInput", on)));
        stickRow = Ui.row(this, "Stick and D-pad feel", "", v -> Dialogs.choose(this, "Stick and D-pad feel",
                new String[]{"Precise  (stick must be pushed far)", "Arcade  (recommended)", "Forgiving  (wide diagonals)"},
                Prefs.stickFeel(this), w -> {
                    Prefs.put(this, "stickFeel", w);
                    refresh();
                }));
        root.addView(stickRow);
        root.addView(Ui.switchRow(this, "Start with the pad on player 2", "You can also swap while playing", Prefs.startSwapped(this),
                (v, on) -> Prefs.put(this, "swap", on)));

        root.addView(Ui.section(this, "Video"));
        filterRow = Ui.row(this, "Scaling", "", v -> Dialogs.choose(this, "Scaling",
                new String[]{"Sharp pixels", "Smooth", "Best (smooth, high quality)"}, filterIndex(), w -> {
                    Prefs.put(this, "filter", w == 0 ? "sharp" : w == 1 ? "smooth" : "best");
                    refresh();
                }));
        root.addView(filterRow);
        aspectRow = Ui.row(this, "Screen shape", "", v -> {
            String[] names = new String[Prefs.ASPECTS.length];
            for (int i = 0; i < names.length; i++) names[i] = Prefs.ASPECTS[i][0];
            Dialogs.choose(this, "Screen shape", names, Prefs.aspect(this), w -> {
                Prefs.put(this, "aspect", w);
                refresh();
            });
        });
        root.addView(aspectRow);
        root.addView(Ui.switchRow(this, "Integer scaling", "Crisp pixels, may leave black borders", Prefs.integerScale(this),
                (v, on) -> Prefs.put(this, "integer", on)));
        countersRow = Ui.row(this, "On-screen counters", "", v -> Dialogs.choose(this, "On-screen counters",
                new String[]{"Off", "FPS", "FPS and speed", "FPS, speed and screen refresh", "Speed and screen refresh"},
                countersIndex(), w -> {
                    Prefs.put(this, "counters", COUNTER_MASKS[w]);
                    refresh();
                }));
        root.addView(countersRow);
        rendererRow = Ui.row(this, "Renderer", "", v -> Dialogs.choose(this, "Renderer",
                new String[]{"GPU  (OpenGL ES, recommended)", "Software  (compatibility, slower)"},
                Prefs.softRender(this) ? 1 : 0, w -> {
                    Prefs.put(this, "softRender", w == 1);
                    refresh();
                }));
        root.addView(rendererRow);
        root.addView(Ui.switchRow(this, "Multi-threaded video (experimental)", "Draws and shows the picture on a second thread so the game itself runs faster. Falls back by itself if the phone does not support it",
                Prefs.videoThread(this), (v, on) -> Prefs.put(this, "videoThread", on)));
        root.addView(Ui.switchRow(this, "VSync", "Smooth picture. Turn off if the game feels choppy or slow", Prefs.vsync(this),
                (v, on) -> Prefs.put(this, "vsync", on)));
        root.addView(Ui.switchRow(this, "Prefer a 60 Hz screen mode", "Avoids uneven frames on 90/120 Hz phones", Prefs.match60(this),
                (v, on) -> Prefs.put(this, "match60", on)));
        root.addView(Ui.switchRow(this, "Rotate with the phone", "Off = always landscape", Prefs.autoRotate(this),
                (v, on) -> Prefs.put(this, "autoRotate", on)));

        root.addView(Ui.section(this, "On-screen controls"));
        root.addView(Ui.switchRow(this, "On-screen controls in every game", "Turn on to start every game with the touch controls. Off = physical controller or keyboard only. Can also be switched in the pause menu; edit the layout from there too",
                Prefs.touchOn(this), (v, on) -> Prefs.put(this, "touchOn", on)));
        root.addView(Ui.row(this, "Opacity", Prefs.touchAlpha(this) + "%", v -> Dialogs.choose(this, "Opacity of on-screen controls",
                new String[]{"25%", "40%", "55%", "70%", "90%"}, alphaIndex(), w -> {
                    Prefs.put(this, "touchAlpha", new int[]{25, 40, 55, 70, 90}[w]);
                    refresh();
                })));
        root.addView(Ui.section(this, "Performance"));
        root.addView(Ui.switchRow(this, "Use the fastest CPU cores", "Keeps the game off the slow cores. Recommended", Prefs.fastCores(this),
                (v, on) -> Prefs.put(this, "fastCores", on)));
        root.addView(Ui.switchRow(this, "Battery saver", "Sleeps between frames. Cooler, but heavy games like 3rd Strike can get slower", Prefs.batterySaver(this),
                (v, on) -> Prefs.put(this, "batterySaver", on)));

        root.addView(Ui.switchRow(this, "Smooth frame timing", "Frames come at an even pace instead of in the audio device's bursts. Turn off only if something looks wrong",
                Prefs.smoothPacing(this), (v, on) -> Prefs.put(this, "smoothPacing", on)));
        root.addView(Ui.switchRow(this, "Match the screen's refresh rate", "Arcade games run at 59.6 fps but screens at 60 Hz. This runs the game at the screen's rate (up to 1% faster) so no frame is ever shown twice",
                Prefs.matchRefresh(this), (v, on) -> Prefs.put(this, "matchRefresh", on)));
        root.addView(Ui.switchRow(this, "Auto frame skip", "When the phone falls behind, skip drawing a few frames to keep the game at full speed",
                Prefs.autoSkip(this), (v, on) -> Prefs.put(this, "autoSkip", on)));
        root.addView(Ui.switchRow(this, "High priority", "Asks Android to give the game thread more CPU time",
                Prefs.highPrio(this), (v, on) -> Prefs.put(this, "highPrio", on)));
        root.addView(Ui.switchRow(this, "Sustained performance", "Keeps the speed steady when the phone gets hot (may lower the peak speed)",
                Prefs.sustained(this), (v, on) -> Prefs.put(this, "sustained", on)));
        root.addView(Ui.row(this, "Frame skip", frameskipText(), v -> Dialogs.choose(this, "Frame skip",
                new String[]{"Off  (every frame drawn)", "Draw every 2nd frame", "Draw every 3rd frame", "Draw every 4th frame"},
                Prefs.frameskip(this), w -> {
                    Prefs.put(this, "frameskip", w);
                    Ui.toast(this, "Applies the next time a game starts");
                    recreate();
                })));
        root.addView(Ui.switchRow(this, "Faster sound mixing", "Cheaper sound for weak phones. Some voices may sound a little rougher",
                Prefs.fastAudio(this), (v, on) -> Prefs.put(this, "fastAudio", on)));
        root.addView(Ui.row(this, "Weak phone preset", "One tap: frame skip, faster sound, 22 kHz audio, safe audio buffer, no VSync", v ->
                Dialogs.message(this, "Weak phone preset", java.util.Arrays.asList(
                        "Turns on frame skip (every 2nd frame), automatic frame skip, faster sound mixing, 22 kHz audio, high priority, multi-threaded video and the fastest CPU cores, and turns VSync off.",
                        "CPS3 games such as 3rd Strike benefit most. You can change each of these again here."),
                        "Apply", () -> {
                            Prefs.put(this, "frameskip", 1);
                            Prefs.put(this, "fastAudio", true);
                            Prefs.put(this, "rate", 22050);
                            Prefs.put(this, "fastCores", true);
                            Prefs.put(this, "vsync", false);
                            Prefs.put(this, "latency", 2);
                            Prefs.put(this, "autoSkip", true);
                            Prefs.put(this, "smoothPacing", true);
                            Prefs.put(this, "highPrio", true);
                            Prefs.put(this, "videoThread", true);
                            recreate();
                        }, "Cancel", null)));

        root.addView(Ui.section(this, "Audio"));
        rateRow = Ui.row(this, "Sample rate", "", v -> Dialogs.choose(this, "Audio sample rate",
                new String[]{"44100 Hz", "48000 Hz", "32000 Hz  (lighter)", "22050 Hz  (lightest)"}, rateIndex(), w -> {
                    Prefs.put(this, "rate", w == 0 ? 44100 : w == 1 ? 48000 : w == 2 ? 32000 : 22050);
                    refresh();
                }));
        root.addView(rateRow);
        latencyRow = Ui.row(this, "Audio buffer", "", v -> Dialogs.choose(this, "Audio buffer",
                new String[]{"Low lag  (may crackle)", "Balanced", "Smooth  (recommended)"}, Prefs.latency(this), w -> {
                    Prefs.put(this, "latency", w);
                    refresh();
                }));
        root.addView(latencyRow);

        root.addView(Ui.section(this, "Help"));
        root.addView(Ui.row(this, Icons.LIST, "Last game log", "Shows errors and speed measurements (perf lines)",
                v -> Dialogs.log(this, Prefs.logTail(this, 80))));
        root.addView(Ui.row(this, Icons.INFO, "Credits", "Made by Hexie", v ->
                Dialogs.message(this, "Credits", java.util.Arrays.asList(
                        "Made by Hexie",
                        "FBNeo for Android, v1.18",
                        "Based on FinalBurn Neo, released under its non-commercial licence."),
                        "OK", null, null, null)));
    }

    private int filterIndex() {
        String f = Prefs.filter(this);
        return "sharp".equals(f) ? 0 : "smooth".equals(f) ? 1 : 2;
    }

    private int rateIndex() {
        int r = Prefs.sampleRate(this);
        return r == 44100 ? 0 : r == 48000 ? 1 : r == 32000 ? 2 : 3;
    }

    private int countersIndex() {
        int m = Prefs.counters(this);
        for (int i = 0; i < COUNTER_MASKS.length; i++) if (COUNTER_MASKS[i] == m) return i;
        return m == 0 ? 0 : 1;
    }

    private String frameskipText() {
        int n = Prefs.frameskip(this);
        return n == 0 ? "Off" : "Draws every " + (n + 1) + (n == 1 ? "nd" : n == 2 ? "rd" : "th") + " frame";
    }

    private int alphaIndex() {
        int p = Prefs.touchAlpha(this);
        int[] v = {25, 40, 55, 70, 90};
        int best = 2;
        for (int i = 0; i < v.length; i++) if (Math.abs(v[i] - p) < Math.abs(v[best] - p)) best = i;
        return best;
    }

    private void refresh() {
        boolean ok = Prefs.hasAccess(this);
        Ui.setSub(accessRow, ok ? "Granted" : "Not granted - tap to allow (needed to read ROMs and Lua scripts)");
        Ui.setSub(dataRow, Prefs.dataDir(this));
        Ui.setSub(romRow, Prefs.romDir(this));
        Ui.setSub(luaRow, Prefs.luaDir(this));
        String d = Prefs.defaultLua(this);
        Ui.setSub(luaDefRow, d.length() == 0 ? "None (you can pick a script per game)" : d);
        Ui.setSub(filterRow, new String[]{"Sharp pixels", "Smooth", "Best"}[filterIndex()]);
        Ui.setSub(aspectRow, Prefs.ASPECTS[Prefs.aspect(this)][0]);
        Ui.setSub(stickRow, new String[]{"Precise", "Arcade", "Forgiving"}[Prefs.stickFeel(this)]);
        Ui.setSub(rateRow, Prefs.sampleRate(this) + " Hz");
        Ui.setSub(countersRow, new String[]{"Off", "FPS", "FPS and speed", "FPS, speed and screen refresh", "Speed and screen refresh"}[countersIndex()]);
        Ui.setSub(rendererRow, Prefs.softRender(this) ? "Software" : "GPU (OpenGL ES)");
        Ui.setSub(latencyRow, new String[]{"Low lag", "Balanced", "Smooth"}[Prefs.latency(this)]);
    }

    private void pick(int req, String start, String title) {
        Intent i = new Intent(this, FileBrowserActivity.class);
        i.putExtra("mode", "folder");
        i.putExtra("start", start);
        i.putExtra("title", title);
        startActivityForResult(i, req);
    }

    private void pickFile() {
        Intent i = new Intent(this, FileBrowserActivity.class);
        i.putExtra("mode", "file");
        i.putExtra("ext", ".lua");
        i.putExtra("start", Prefs.luaDir(this));
        i.putExtra("title", "Choose a Lua script");
        startActivityForResult(i, REQ_LUADEF);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (res != RESULT_OK || data == null) return;
        String p = data.getStringExtra("path");
        if (p == null) return;
        if (req == REQ_DATA) {
            boolean romsDefault = Prefs.romDir(this).equals(Prefs.dataDir(this) + "roms/");
            boolean luaDefault = Prefs.luaDir(this).equals(Prefs.dataDir(this) + "lua/");
            Prefs.put(this, "dataDir", p);
            if (romsDefault) Prefs.sp(this).edit().remove("romDir").apply();
            if (luaDefault) Prefs.sp(this).edit().remove("luaDir").apply();
        } else if (req == REQ_ROMS) Prefs.put(this, "romDir", p);
        else if (req == REQ_LUADIR) Prefs.put(this, "luaDir", p);
        else if (req == REQ_LUADEF) Prefs.put(this, "luaDefault", p);
        refresh();
    }
}
