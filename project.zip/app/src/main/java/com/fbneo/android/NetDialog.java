package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/** "Local multiplayer" menu: pick Wi-Fi or hotspot, then host (player 1) or join (player 2). */
final class NetDialog {
    private final Activity a;
    private final String game;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final NetDiscovery disc;
    private Dialog d;
    private LinearLayout card;
    private boolean hotspot;
    private String screen = "menu";      // menu, method, host, join, status
    private Runnable poll;
    private LinearLayout hostList;
    private TextView statusText;
    private EditText ipField;
    private String lastError = "";

    static void show(Activity a, String game) { new NetDialog(a, game).open(); }

    private NetDialog(Activity a, String game) {
        this.a = a;
        this.game = game;
        this.disc = new NetDiscovery(a);
    }

    private String[] status() {
        try {
            return Native.netStatus().split("\\|", 5);
        } catch (UnsatisfiedLinkError | RuntimeException e) {
            return new String[]{"idle", "0", "3", "0", ""};
        }
    }

    private void open() {
        final LinearLayout[] holder = new LinearLayout[1];
        d = Dialogs.base(a, holder);
        card = holder[0];
        d.setOnDismissListener(x -> {
            h.removeCallbacksAndMessages(null);
            String st = status()[0];
            if (!st.equals("run") && !st.equals("sync") && !st.equals("ready") && !st.equals("listen")) disc.stop();
        });
        String st = status()[0];
        if (st.equals("error")) {
            // a connection that broke earlier: scrap it so Host / Join start clean
            lastError = status().length > 4 ? status()[4] : "";
            stopAll();
            st = "idle";
        }
        if (st.equals("run")) screen = "status";
        else if (st.equals("listen") || st.equals("connecting") || st.equals("ready") || st.equals("sync")) {
            screen = status()[1].equals("1") ? "host" : "join";
        }
        render();
        d.show();
        poll = new Runnable() {
            @Override public void run() {
                tick();
                h.postDelayed(this, 500);
            }
        };
        h.postDelayed(poll, 500);
    }

    // ---- screens -----------------------------------------------------------------------

    private TextView title(String t) {
        TextView x = Ui.text(a, t, 22, Ui.TEXT, true);
        x.setPadding(0, 0, 0, Ui.dp(a, 6));
        return x;
    }

    private TextView note(String t) {
        TextView x = Ui.text(a, t, 13, Ui.SUB, false);
        x.setLineSpacing(0, 1.15f);
        x.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 8));
        return x;
    }

    private View choice(String head, String sub, View.OnClickListener l) {
        LinearLayout r = Ui.row(a, head, sub, l);
        r.setLayoutParams(Ui.fillMargins(a, 0, 4, 0, 4));
        r.setBackground(Ui.ripple(a, Ui.rounded(a, Ui.SURFACE2, 16), 16));
        return r;
    }

    private void back(String to) {
        card.addView(Ui.button(a, "Back", Ui.TEXTONLY, v -> { screen = to; render(); }), Ui.wrapMargins(a, 0, 6, 0, 0));
    }

    private void render() {
        card.removeAllViews();
        hostList = null;
        statusText = null;
        ipField = null;
        if (screen.equals("menu")) {
            card.addView(title("Local multiplayer"));
            if (lastError.length() > 0) {
                TextView err = Ui.text(a, lastError, 13, Ui.WARN, true);
                err.setPadding(0, 0, 0, Ui.dp(a, 8));
                card.addView(err);
            }
            card.addView(note("Play " + game + " with a friend. Both phones need the same game and the same ROM files. The host is player 1, the friend is player 2. The game restarts and syncs when you connect."));
            card.addView(choice("Same Wi-Fi network", "Both phones are on the same Wi-Fi", v -> { hotspot = false; screen = "method"; render(); }));
            card.addView(choice("Hotspot", "One phone shares its hotspot, the other connects to it", v -> { hotspot = true; screen = "method"; render(); }));
            card.addView(Ui.button(a, "Close", Ui.TEXTONLY, v -> d.dismiss()), Ui.wrapMargins(a, 0, 6, 0, 0));
        } else if (screen.equals("method")) {
            card.addView(title(hotspot ? "Hotspot" : "Same Wi-Fi network"));
            card.addView(note(hotspot ? "The phone that shares the hotspot should host. The other phone joins it." : "Either phone can host. The host is player 1."));
            card.addView(choice("Host", "You are player 1. Your friend joins you", v -> startHost()));
            card.addView(choice("Join", "You are player 2. Join your friend's game", v -> startJoin()));
            back("menu");
        } else if (screen.equals("host")) {
            renderHost();
        } else if (screen.equals("join")) {
            renderJoin();
        } else {
            renderStatus();
        }
    }

    private void startHost() {
        lastError = "";
        try {
            Native.netHost();
        } catch (UnsatisfiedLinkError | RuntimeException e) {
            Ui.toast(a, "Netplay is not available");
            return;
        }
        disc.startHosting(game);
        screen = "host";
        render();
    }

    private void startJoin() {
        lastError = "";
        disc.startListening();
        screen = "join";
        render();
    }

    private void renderHost() {
        card.addView(title("Hosting (you are player 1)"));
        if (hotspot) {
            card.addView(note("1. Turn on your phone's hotspot.\n2. Your friend connects their phone to it.\n3. Your friend opens this menu, taps Hotspot, then Join."));
            card.addView(Ui.button(a, "Open hotspot settings", Ui.TONAL, v -> openSettings(true)), Ui.fillMargins(a, 0, 4, 0, 4));
        } else {
            card.addView(note("Your friend opens this menu on their phone: Same Wi-Fi network, then Join. They should see your phone in the list."));
        }
        StringBuilder sb = new StringBuilder("Your address:");
        List<String> ips = NetDiscovery.localAddresses();
        if (ips.isEmpty()) sb.append(" none found. Connect to Wi-Fi or turn on the hotspot");
        for (String s : ips) sb.append("\n").append(s);
        TextView t = Ui.text(a, sb.toString(), 13, Ui.TEXT, false);
        t.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 8));
        t.setTextIsSelectable(true);
        card.addView(t);
        statusText = Ui.text(a, "", 14, Ui.ACCENT, true);
        card.addView(statusText);
        card.addView(Ui.button(a, "Cancel", Ui.TEXTONLY, v -> { stopAll(); screen = "menu"; render(); }), Ui.wrapMargins(a, 0, 8, 0, 0));
        tick();
    }

    private void renderJoin() {
        card.addView(title("Join (you are player 2)"));
        if (hotspot) {
            card.addView(note("First connect this phone to your friend's hotspot in Wi-Fi settings, then come back here."));
            card.addView(Ui.button(a, "Open Wi-Fi settings", Ui.TONAL, v -> openSettings(false)), Ui.fillMargins(a, 0, 4, 0, 4));
        }
        card.addView(Ui.text(a, "Games found nearby", 13, Ui.SUB, true));
        hostList = Ui.vertical(a);
        card.addView(hostList);
        card.addView(Ui.text(a, "Or type the host's address", 13, Ui.SUB, true), Ui.fillMargins(a, 0, 10, 0, 0));
        ipField = new EditText(a);
        ipField.setSingleLine(true);
        ipField.setHint("for example 192.168.1.20");
        ipField.setTextColor(Ui.TEXT);
        ipField.setHintTextColor(Ui.SUB);
        ipField.setInputType(InputType.TYPE_CLASS_PHONE);
        ipField.setBackground(Ui.rounded(a, Ui.SURFACE2, 12));
        ipField.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
        String gw = hotspot ? NetDiscovery.gateway(a) : "";
        String last = Prefs.sp(a).getString("netIp", "");
        ipField.setText(gw.length() > 0 ? gw : last);
        card.addView(ipField, Ui.fillMargins(a, 0, 4, 0, 4));
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.addView(Ui.button(a, "Cancel", Ui.TEXTONLY, v -> { stopAll(); screen = "menu"; render(); }));
        bar.addView(Ui.button(a, "Join", Ui.FILLED, v -> joinIp(ipField.getText().toString().trim())), Ui.wrapMargins(a, 8, 0, 0, 0));
        card.addView(bar, Ui.fillMargins(a, 0, 6, 0, 0));
        statusText = Ui.text(a, "", 14, Ui.ACCENT, true);
        card.addView(statusText);
        tick();
    }

    private void joinIp(String ip) {
        if (ip.length() == 0) { Ui.toast(a, "Enter the host's address"); return; }
        Prefs.put(a, "netIp", ip);
        try {
            Native.netJoin(ip);
        } catch (UnsatisfiedLinkError | RuntimeException e) {
            Ui.toast(a, "Netplay is not available");
        }
    }

    private void renderStatus() {
        String[] st = status();
        card.addView(title("Playing together"));
        card.addView(note("You are player " + (st[1].equals("1") ? "1 (host)" : "2") + ". Input delay " + st[2]
                + " frames. Both phones must keep the game open. Quitting the game on one phone ends the session."));
        statusText = Ui.text(a, "", 14, Ui.OK, true);
        card.addView(statusText);
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.addView(Ui.button(a, "Close", Ui.TEXTONLY, v -> d.dismiss()));
        TextView stop = Ui.button(a, "Disconnect", Ui.TONAL, v -> { stopAll(); screen = "menu"; render(); });
        stop.setTextColor(Ui.DANGER);
        bar.addView(stop, Ui.wrapMargins(a, 8, 0, 0, 0));
        card.addView(bar, Ui.fillMargins(a, 0, 8, 0, 0));
        tick();
    }

    private void stopAll() {
        try { Native.netStop(); } catch (UnsatisfiedLinkError | RuntimeException e) { /* ignore */ }
        disc.stop();
    }

    private void openSettings(boolean hotspotPage) {
        Intent i = new Intent(hotspotPage ? "android.settings.TETHER_SETTINGS" : Settings.ACTION_WIFI_SETTINGS);
        try {
            a.startActivity(i);
        } catch (Exception e) {
            try { a.startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); } catch (Exception e2) { Ui.toast(a, "Open Settings yourself"); }
        }
    }

    // ---- live updates ------------------------------------------------------------------

    private void tick() {
        String[] st = status();
        String state = st[0];
        String msg = st.length > 4 ? st[4] : "";
        if (state.equals("run") && !screen.equals("status")) {
            screen = "status";
            render();
            return;
        }
        if (state.equals("error")) {
            // show why it ended, then scrap the dead connection so a new Host / Join works right away
            lastError = msg;
            try { Native.netStop(); } catch (UnsatisfiedLinkError | RuntimeException e) { /* ignore */ }
            disc.stop();
            screen = "menu";
            render();
            return;
        }
        if (statusText != null) {
            String s;
            switch (state) {
                case "listen": s = msg.length() > 0 ? msg : "Waiting for your friend..."; break;
                case "connecting": s = msg; break;
                case "ready": s = "Syncing the two games... (starting)"; break;
                case "sync": s = msg.length() > 0 ? msg : "Syncing the two games..."; break;
                case "run": s = (st[3].equals("1") ? "Out of sync: " : "Connected. ") + msg; break;
                default: s = screen.equals("join") ? "" : "";
            }
            statusText.setText(s);
        }
        if (hostList != null) {
            hostList.removeAllViews();
            List<NetDiscovery.Host> hs = disc.found();
            if (hs.isEmpty()) {
                hostList.addView(note("Looking... Ask your friend to start hosting."));
            }
            for (final NetDiscovery.Host x : hs) {
                boolean same = x.game.equals(game);
                hostList.addView(choice(x.ip, same ? "Playing " + x.game + ". Tap to join" : "Plays " + x.game + ", you are on " + game,
                        v -> { if (ipField != null) ipField.setText(x.ip); joinIp(x.ip); }));
            }
        }
    }
}
