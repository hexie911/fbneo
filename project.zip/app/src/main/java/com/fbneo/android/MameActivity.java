package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;

/** Plays one game with the libretro MAME core (libmamehost.so). */
public class MameActivity extends Activity implements SurfaceHolder.Callback, MameNetDialog.Owner {
    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(Lang.wrap(base));
    }

    private final Object lock = new Object();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SurfaceView sv;
    private TouchPadView touch;
    private PadInput pad;
    private Thread thread;
    private volatile boolean running, paused, quitting;
    private volatile String failure;
    private String rom, romPath;
    private Dialog menu;
    private LinearLayout editBar;
    private android.widget.SeekBar sizeBar, alphaBar;
    private boolean syncing, editing;
    private interface SliderCb { void on(int value, boolean fromUser); }

    private android.widget.SeekBar slider(final int min, final int max, int start, final SliderCb cb) {
        android.widget.SeekBar sb = new android.widget.SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(start - min);
        sb.setProgressTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        sb.setThumbTintList(android.content.res.ColorStateList.valueOf(Ui.ACCENT));
        sb.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar s, int p, boolean user) {
                if (!syncing) cb.on(p + min, user);
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar s) { }
            @Override public void onStopTrackingTouch(android.widget.SeekBar s) { if (touch != null) touch.save(); }
        });
        return sb;
    }

    private void syncSliders(TouchPadView.El sel) {
        if (sizeBar == null || alphaBar == null) return;
        syncing = true;
        sizeBar.setEnabled(sel != null);
        alphaBar.setEnabled(sel != null);
        if (sel != null) {
            sizeBar.setProgress(Math.round(sel.size) - 40);
            float a = sel.alpha > 0 ? sel.alpha : (touch != null ? touch.globalAlpha() : 0.55f);
            alphaBar.setProgress(Math.round(a * 100) - 10);
        }
        syncing = false;
    }

    private TextView counters;
    private FrameLayout root;
    private volatile int frames, audioShorts, writeErr;
    private volatile double coreFps = 60, coreRate = 44100;
    private float refreshHz;
    private long cntT0, hzT0;
    private int hzN;
    private boolean hzLoop;
    private static final String[] SHAPES = {"Original shape", "Stretch to screen", "4:3", "16:9", "Pixel perfect (whole multiples)"};
    private static final int[] SIZES = {100, 90, 80, 70, 60, 50};
    private final boolean[][] held = new boolean[2][40];

    // libretro joypad ids
    private static final int B = 0, Y = 1, SELECT = 2, START = 3, UP = 4, DOWN = 5, LEFT = 6, RIGHT = 7, A = 8, X = 9, L = 10, R = 11;

    private static int retroId(int action) {
        switch (action) {
            case Actions.UP: return UP;
            case Actions.DOWN: return DOWN;
            case Actions.LEFT: return LEFT;
            case Actions.RIGHT: return RIGHT;
            case Actions.FIRE1: return B;
            case Actions.FIRE2: return A;
            case Actions.FIRE3: return Y;
            case Actions.FIRE4: return X;
            case Actions.FIRE5: return L;
            case Actions.FIRE6: return R;
            case Actions.COIN: return SELECT;
            case Actions.START: return START;
            default: return -1;
        }
    }

    private volatile boolean swapped;
    private volatile MameNet net;
    private volatile int localMask;
    private final int[] applied = new int[2];
    private int netFrame;
    private boolean netWasActive;

    @Override public MameNet net() { return net; }
    @Override public void setNet(MameNet n) { net = n; }

    private boolean netOn() { MameNet n = net; return n != null && n.active(); }

    private void applyMasks(int[] m) {
        for (int p = 0; p < 2; p++) {
            int diff = m[p] ^ applied[p];
            if (diff == 0) continue;
            for (int b = 0; b < 16; b++) if ((diff & (1 << b)) != 0) MameNative.setButton(p, b, (m[p] & (1 << b)) != 0);
            applied[p] = m[p];
        }
    }

    private void clearButtons() {
        for (int p = 0; p < 2; p++) { for (int b = 0; b < 16; b++) MameNative.setButton(p, b, false); applied[p] = 0; }
        localMask = 0;
    }

    /** One emulated frame, in lockstep with the other phone when a match is running. */
    private void runOne() {
        MameNet n = net;
        if (n != null) {
            try {
                if ("ready".equals(n.state)) {
                    clearButtons();
                    n.syncStart(new File(getCacheDir(), "net.state"));
                    netFrame = 0;
                    ui.post(() -> Ui.toast(this, Lang.t("Connected, game synced")));
                }
                if (n.active()) {
                    netWasActive = true;
                    applyMasks(n.step(netFrame, localMask));
                    MameNative.runFrame();
                    n.setHash(netFrame, MameNative.frameHash());
                    netFrame++;
                    return;
                }
            } catch (Exception e) {
                n.fail(String.valueOf(e.getMessage()));
            }
            if (netWasActive) {
                netWasActive = false;
                clearButtons();
                final String why = n.message;
                ui.post(() -> Ui.toast(this, Lang.t("Multiplayer ended: ") + why));
            }
        }
        MameNative.runFrame();
    }

    private void send(int slot, int action, boolean down) {
        if (slot < 0 || slot > 1) return;
        if (action == Actions.SWAP) {
            if (down) {
                swapped = !swapped;
                for (int p = 0; p < 2; p++) for (int b = 0; b < 16; b++) MameNative.setButton(p, b, false);
                ui.post(() -> Ui.toast(this, swapped ? Lang.t("Controls now drive player 2") : Lang.t("Controls now drive player 1")));
            }
            return;
        }
        if (netOn()) {
            int bit = retroId(action);
            if (bit >= 0) localMask = down ? (localMask | (1 << bit)) : (localMask & ~(1 << bit));
            return;
        }
        if (swapped) slot = 1 - slot;
        int id = retroId(action);
        if (id >= 0) {
            MameNative.setButton(slot, id, down);
            return;
        }
        if (!down) return;
        switch (action) {
            case Actions.SAVE: saveState(); break;
            case Actions.LOAD: loadState(); break;
            case Actions.RESET: MameNative.reset(); break;
            case Actions.PAUSE: paused = !paused; break;
            case Actions.QUIT: finish(); break;
            default: break;
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        rom = getIntent().getStringExtra("rom");
        romPath = getIntent().getStringExtra("path");
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        sv = new SurfaceView(this);
        sv.getHolder().addCallback(this);
        FrameLayout.LayoutParams svp = new FrameLayout.LayoutParams(-1, -1);
        svp.gravity = android.view.Gravity.CENTER;
        root.addView(sv, svp);
        PadInput.configure(this);
        pad = new PadInput(PadMap.load(this, 0), PadMap.load(this, 1), new PadInput.Sink() {
            @Override public void onAction(int slot, int action, boolean down) {
                if (action == Actions.MENU) { if (down) ui.post(MameActivity.this::showMenu); return; }
                if (action == Actions.CHAT) { if (down) ui.post(MameActivity.this::showChat); return; }
                send(slot, action, down);
            }
        });
        touch = new TouchPadView(this, new TouchPadView.Host() {
            @Override public void openMenu() { ui.post(MameActivity.this::showMenu); }
            @Override public void openChat() { ui.post(MameActivity.this::showChat); }
            @Override public void editChanged(TouchPadView.El sel) { syncSliders(sel); }
        });
        Native.touchSink = (action, down) -> send(0, action, down);
        root.addView(touch, new FrameLayout.LayoutParams(-1, -1));
        editBar = Ui.vertical(this);
        editBar.setBackground(Ui.rounded(this, 0xE6171A21, 16));
        editBar.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 6));
        LinearLayout row1 = Ui.horizontal(this);
        row1.setGravity(android.view.Gravity.CENTER);
        row1.addView(Ui.button(this, Lang.t("+ Button"), Ui.TEXTONLY, v -> TouchEditor.addButton(this, touch)));
        row1.addView(Ui.button(this, Lang.t("+ Macro"), Ui.TEXTONLY, v -> TouchEditor.addMacro(this, touch)));
        TextView del = Ui.button(this, Lang.t("Delete"), Ui.TEXTONLY, v -> touch.deleteSelected());
        del.setTextColor(Ui.DANGER);
        row1.addView(del);
        row1.addView(Ui.button(this, Lang.t("Reset"), Ui.TEXTONLY, v -> touch.resetLayout()));
        row1.addView(Ui.button(this, Lang.t("Done"), Ui.FILLED, v -> endEdit()));
        editBar.addView(row1);
        LinearLayout row2 = Ui.horizontal(this);
        row2.setGravity(android.view.Gravity.CENTER_VERTICAL);
        sizeBar = slider(40, 260, 80, (val, user) -> { if (user) touch.setSelectedSize(val); });
        alphaBar = slider(10, 100, 55, (val, user) -> { if (user) touch.setSelectedAlpha(val / 100f); });
        row2.addView(Ui.text(this, Lang.t("Size"), 13, Ui.SUB, false));
        row2.addView(sizeBar, new LinearLayout.LayoutParams(Ui.dp(this, 170), ViewGroup.LayoutParams.WRAP_CONTENT));
        row2.addView(Ui.text(this, Lang.t("Opacity"), 13, Ui.SUB, false));
        row2.addView(alphaBar, new LinearLayout.LayoutParams(Ui.dp(this, 170), ViewGroup.LayoutParams.WRAP_CONTENT));
        editBar.addView(row2);
        LinearLayout row3 = Ui.horizontal(this);
        row3.setGravity(android.view.Gravity.CENTER);
        final int[] blends = {0, 60, 80, 100};
        final TextView blendBtn = Ui.button(this, "", Ui.TONAL, null);
        blendBtn.setText(blendText());
        blendBtn.setOnClickListener(v -> {
            int cur = Prefs.touchBlend(this), n = 0;
            for (int i = 0; i < blends.length; i++) if (blends[i] == cur) n = (i + 1) % blends.length;
            Prefs.put(this, "touchBlend", blends[n]);
            touch.setBlend(blends[n]);
            blendBtn.setText(blendText());
        });
        row3.addView(blendBtn);
        final TextView stickBtn = Ui.button(this, "", Ui.TONAL, null);
        stickBtn.setText(stickText());
        stickBtn.setOnClickListener(v -> {
            boolean on = !Prefs.smoothStick(this);
            Prefs.put(this, "smoothStick", on);
            touch.setSmoothStick(on);
            stickBtn.setText(stickText());
        });
        row3.addView(stickBtn, Ui.wrapMargins(this, 0, 6, 0, 0));
        editBar.addView(row3);
        syncSliders(null);
        FrameLayout.LayoutParams elp = new FrameLayout.LayoutParams(-2, -2, android.view.Gravity.TOP | android.view.Gravity.CENTER_HORIZONTAL);
        elp.topMargin = Ui.dp(this, 6);
        root.addView(editBar, elp);
        editBar.setVisibility(View.GONE);
        counters = new TextView(this);
        counters.setTextColor(0xFFFFFFFF);
        counters.setTextSize(12);
        counters.setShadowLayer(3, 1, 1, 0xFF000000);
        counters.setPadding(Ui.dp(this, 10), Ui.dp(this, 6), Ui.dp(this, 10), 0);
        counters.setTypeface(android.graphics.Typeface.MONOSPACE);
        counters.setVisibility(View.GONE);
        root.addView(counters, new FrameLayout.LayoutParams(-2, -2, android.view.Gravity.TOP | android.view.Gravity.START));
        applyCounters();
        ui.post(netWatcher);
        touch.setVisibility(Prefs.touchOn(this) ? View.VISIBLE : View.GONE);
        setContentView(root);
        Lang.forceLtr(root);
        hideBars();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideBars(); }

    // ---- surface + emulation thread ----------------------------------------------------------

    @Override public void surfaceCreated(SurfaceHolder h) {
        synchronized (lock) {
            if (MameNative.loadLibraries()) {
                MameNative.setSurface(h.getSurface());
                // Vulkan picture output when chosen in Settings; if it cannot start, the normal path is used
                if (Prefs.vulkan(this)) {
                    boolean ok = false;
                    try { ok = MameNative.vkStart(h.getSurface(), Prefs.vsync(this), !"sharp".equals(Prefs.filter(this))); } catch (UnsatisfiedLinkError | RuntimeException e) { /* normal path */ }
                    if (!ok) Ui.toast(this, Lang.t("Vulkan is not available here: using the normal picture path"));
                }
            }
        }
        if (thread == null) start();
    }
    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) { }
    @Override public void surfaceDestroyed(SurfaceHolder h) {
        synchronized (lock) {
            if (MameNative.loadLibraries()) {
                try { MameNative.vkStop(); } catch (UnsatisfiedLinkError | RuntimeException e) { /* ignore */ }
                MameNative.setSurface(null);
            }
        }
    }

    private void start() {
        running = true;
        thread = new Thread(this::emulate, "mame-emu");
        thread.start();
    }

    private final StringBuilder runLog = new StringBuilder();

    static File logFile(android.content.Context c) {
        File d = new File(c.getFilesDir(), "mame");
        d.mkdirs();
        return new File(d, "last_run.log");
    }

    private void note(String s) {
        synchronized (runLog) { runLog.append(s).append('\n'); }
    }

    private void writeLog() {
        try {
            String core = MameNative.loadLibraries() ? MameNative.log() : "";
            long[] st = MameNative.loadLibraries() ? MameNative.audioStats() : null;
            StringBuilder b = new StringBuilder();
            synchronized (runLog) { b.append(runLog); }
            if (st != null) b.append("audio callbacks: batch ").append(st[0]).append(", single ").append(st[1]).append(", frames ").append(st[2]).append('\n');
            b.append("video frames run: ").append(frames).append('\n');
            b.append("--- core log ---\n").append(core == null ? "" : core).append('\n');
            try (java.io.FileOutputStream o = new java.io.FileOutputStream(logFile(this))) { o.write(b.toString().getBytes("UTF-8")); }
        } catch (Exception e) { /* log is best effort */ }
    }

    private void fail(String s) {
        failure = s;
        note(Lang.t("FAILED: ") + s);
        writeLog();
        ui.post(() -> {
            if (isFinishing()) return;
            Dialogs.message(this, Lang.t("Could not start"), java.util.Collections.singletonList(s), Lang.t("Close"), this::finish, null, null)
                    .setCancelable(false);
        });
    }

    private File statePath() {
        File d = new File(getFilesDir(), "mame/states");
        d.mkdirs();
        return new File(d, rom + ".state");
    }

    private void emulate() {
        try {
            note("MAME " + MameCore.current(this) + "  rom " + rom + "  " + romPath + "  android " + Build.VERSION.SDK_INT);
            if (!MameNative.loadLibraries()) { fail(Lang.t("The MAME host library could not load: ") + MameNative.loadError); return; }
            File core = MameCore.file(this, MameCore.current(this));
            if (core == null) { fail(Lang.t("No MAME core installed. Open the MAME section and download one.")); return; }
            if (!MameNative.load(core.getPath(), MameCore.sysDir(this).getPath(), MameCore.saveDir(this).getPath())) {
                fail(Lang.t("The core would not load.\n\n") + MameNative.log()); return;
            }
            MameNative.setOption("mame_cpu_overclock", "default");
            if (!MameNative.loadGame(romPath)) {
                String l = MameNative.log();
                MameNative.unload();
                fail(Lang.t("The game would not start. The ROM set usually has to match the core's MAME version.\n\n") + l);
                return;
            }
            MameNative.runFrame();
            double[] inf = MameNative.info();
            int rate = inf != null && inf.length > 3 && inf[3] > 8000 ? (int) inf[3] : 44100;
            double fps = inf != null && inf.length > 2 && inf[2] > 10 ? inf[2] : 60;
            coreFps = fps; coreRate = rate;
            note("started: " + (inf == null ? "" : inf[0] + "x" + inf[1]) + " fps " + fps + " audio " + rate + " Hz");
            writeLog();
            ui.post(this::layoutVideo);
            AudioTrack at = makeTrack(rate);
            at.setVolume(1f);
            at.play();
            short[] buf = new short[16384];
            long frameNs = (long) (1e9 / fps), next = System.nanoTime();
            boolean aclock = true;
            int emptyRuns = 0;
            while (running) {
                if (paused) { at.pause(); at.flush(); Thread.sleep(30); next = System.nanoTime(); if (!paused) at.play(); continue; }
                runOne();
                synchronized (lock) { MameNative.blit(); }
                frames++;
                int n = MameNative.audio(buf);
                audioShorts += Math.max(n, 0);
                if (n > 0) { int w = at.write(buf, 0, n, AudioTrack.WRITE_BLOCKING); if (w < 0) writeErr = w; emptyRuns = 0; }
                else if (++emptyRuns > 5) aclock = false;
                if (!aclock || n == 0) {
                    next += frameNs;
                    long d = next - System.nanoTime();
                    if (d > 0) Thread.sleep(d / 1000000, (int) (d % 1000000));
                    else if (d < -frameNs * 4) next = System.nanoTime();
                }
            }
            at.stop();
            at.release();
            File sp = statePath();
            note("ended normally");
            writeLog();
            MameNative.saveState(sp.getPath() + ".auto");
            MameNative.unload();
        } catch (InterruptedException e) {
            // closing
        } catch (Throwable t) {
            fail(Lang.t("Crashed: ") + t);
        }
    }

    private AudioTrack makeTrack(int rate) {
        int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack.Builder bld = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(Math.max(min, rate * 4 * 7 / 100));
        return bld.build();
    }

    private String blendText() {
        int b = Prefs.touchBlend(this);
        return Lang.t("Multi-touch between buttons: ") + (b == 0 ? Lang.t("Off") : b + "%");
    }

    private String stickText() {
        return Lang.t("Smooth stick: ") + (Prefs.smoothStick(this) ? Lang.t("On") : Lang.t("Off (8 directions)"));
    }

    private void startEdit() {
        Prefs.put(this, "touchOn", true);
        touch.setVisibility(View.VISIBLE);
        touch.setAlphaLevel(Prefs.touchAlpha(this));
        touch.setEdit(true);
        editing = true;
        paused = !netOn();
        editBar.setVisibility(View.VISIBLE);
    }

    private void endEdit() {
        touch.setEdit(false);
        touch.save();
        editing = false;
        paused = false;
        editBar.setVisibility(View.GONE);
    }

    // ---- chat while playing together -------------------------------------------------------------

    private boolean netWasRunning;
    private final Runnable netWatcher = new Runnable() {
        @Override public void run() {
            boolean on = netOn();
            if (on && !netWasRunning) ChatDialog.Log.clear();
            netWasRunning = on;
            touch.setNetActive(on);
            MameNet n = net;
            if (on && n != null) {
                String m;
                while ((m = n.pollChat()) != null) {
                    ChatDialog.Log.add(false, m);
                    if (!ChatDialog.isOpen()) Ui.toast(MameActivity.this, Lang.t("Friend: ") + m);
                }
                touch.setUnread(ChatDialog.isOpen() ? 0 : ChatDialog.Log.unread);
            } else {
                touch.setUnread(0);
            }
            ui.postDelayed(this, 400);
        }
    };

    private void showChat() {
        if (!netWasRunning) { Ui.toast(this, Lang.t("Chat works while playing together")); return; }
        pad.releaseAll();
        touch.releaseAllTouch();
        ChatDialog.show(this, text -> { MameNet n = net; if (n != null) n.sendChat(text); });
    }

    // ---- picture size and counters -------------------------------------------------------------

    private void layoutVideo() {
        if (sv == null || root.getWidth() == 0) { ui.postDelayed(this::layoutVideo, 100); return; }
        double[] inf = MameNative.loadLibraries() ? MameNative.info() : null;
        int cw = root.getWidth(), ch = root.getHeight();
        double asp = 4.0 / 3;
        double ow = 0, oh = 0;
        if (inf != null && inf[1] > 0) { ow = inf[0]; oh = inf[1]; asp = inf[5] > 0.1 ? inf[5] : inf[0] / inf[1]; }
        int shape = Prefs.sp(this).getInt("mameShape", 0);
        int pct = Prefs.sp(this).getInt("mameSize", 100);
        int w, h;
        if (shape == 1) { w = cw; h = ch; }
        else {
            double a = shape == 2 ? 4.0 / 3 : shape == 3 ? 16.0 / 9 : asp;
            if (shape == 4 && oh > 0) {
                int k = (int) Math.max(1, Math.min(ch / oh, cw / (oh * asp)));
                h = (int) (oh * k); w = (int) (oh * asp * k);
            } else if (cw / (double) ch > a) { h = ch; w = (int) (ch * a); }
            else { w = cw; h = (int) (cw / a); }
        }
        if (shape != 4) { w = w * pct / 100; h = h * pct / 100; }
        FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) sv.getLayoutParams();
        if (p.width != w || p.height != h) { p.width = w; p.height = h; sv.setLayoutParams(p); }
    }

    private void applyCounters() {
        boolean on = Prefs.sp(this).getBoolean("mameCounters", false);
        counters.setVisibility(on ? View.VISIBLE : View.GONE);
        hzLoop = on;
        cntT0 = 0; hzT0 = 0; hzN = 0;
        if (on) {
            ui.post(new Runnable() { @Override public void run() { if (hzLoop) { updateCounters(); ui.postDelayed(this, 500); } } });
            android.view.Choreographer.getInstance().postFrameCallback(new android.view.Choreographer.FrameCallback() {
                @Override public void doFrame(long ns) {
                    if (!hzLoop) return;
                    if (hzT0 == 0) hzT0 = ns;
                    hzN++;
                    if (ns - hzT0 >= 1000000000L) { refreshHz = hzN * 1e9f / (ns - hzT0); hzT0 = ns; hzN = 0; }
                    android.view.Choreographer.getInstance().postFrameCallback(this);
                }
            });
        }
    }

    private String audioCb() {
        long[] st = MameNative.audioStats();
        return st == null ? "" : "\nCore audio calls " + st[0] + " / " + st[1];
    }

    private int lastFrames, lastAudio;
    private void updateCounters() {
        long now = System.nanoTime();
        if (cntT0 != 0) {
            double dt = (now - cntT0) / 1e9;
            double fps = (frames - lastFrames) / dt;
            double snd = (audioShorts - lastAudio) / 2.0 / dt;
            counters.setText(String.format(java.util.Locale.US, "FPS %.1f / %.1f\nSpeed %.0f%%\nScreen %.1f Hz\nSound %.0f Hz (core %.0f) err %d",
                    fps, coreFps, fps * 100 / coreFps, refreshHz, snd, coreRate, writeErr) + audioCb());
        }
        cntT0 = now; lastFrames = frames; lastAudio = audioShorts;
        layoutVideo();
    }

    // ---- state -------------------------------------------------------------------------------

    private void saveState() {
        if (netOn()) { ui.post(() -> Ui.toast(this, Lang.t("Not while playing together"))); return; }
        boolean ok = MameNative.saveState(statePath().getPath());
        ui.post(() -> Ui.toast(this, ok ? Lang.t("State saved") : Lang.t("Could not save state")));
    }

    private void loadState() {
        if (netOn()) { ui.post(() -> Ui.toast(this, Lang.t("Not while playing together"))); return; }
        File f = statePath();
        boolean ok = f.isFile() && MameNative.loadState(f.getPath());
        ui.post(() -> Ui.toast(this, ok ? Lang.t("State loaded") : Lang.t("No saved state")));
    }

    /** Press a keyboard key inside the core for a moment (F2 = service mode). */
    private void tapKey(int code, int ms) {
        MameNative.setKey(code, true);
        ui.postDelayed(() -> MameNative.setKey(code, false), ms);
    }

    /** Opens MAME's own menu (Tab) where "Dip Switches" lives; steer it with the on-screen D-pad and buttons. */
    private void openMameMenu() {
        Ui.toast(this, Lang.t("Pick Dip Switches with the D-pad, Tab again to close"));
        tapKey(9, 200);
    }

    // ---- menu --------------------------------------------------------------------------------

    private void showMenu() {
        if (menu != null && menu.isShowing()) return;
        pad.releaseAll();
        touch.releaseAllTouch();
        paused = !netOn();
        final LinearLayout[] h = new LinearLayout[1];
        menu = Dialogs.base(this, h);
        menu.setOnDismissListener(d -> { if (!editing) paused = false; hideBars(); });
        LinearLayout card = h[0];
        TextView t = Ui.text(this, Lang.t("Paused - MAME"), 22, Ui.TEXT, true);
        t.setPadding(0, 0, 0, Ui.dp(this, 12));
        card.addView(t);
        card.addView(Ui.button(this, Lang.t("Resume"), Ui.FILLED, v -> menu.dismiss()), Ui.fillMargins(this, 0, 5, 0, 5));
        card.addView(Ui.switchRow(this, Lang.t("On-screen controls"), Lang.t("Stick and buttons on the screen"), Prefs.touchOn(this), (v, on) -> {
            Prefs.put(this, "touchOn", on);
            touch.setVisibility(on ? View.VISIBLE : View.GONE);
            if (!on) touch.releaseAllTouch();
        }), Ui.fillMargins(this, 0, 5, 0, 5));
        LinearLayout two = Ui.horizontal(this);
        two.addView(Ui.button(this, Lang.t("Save state"), Ui.TONAL, v -> { menu.dismiss(); saveState(); }), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.leftMargin = Ui.dp(this, 10);
        two.addView(Ui.button(this, Lang.t("Load state"), Ui.TONAL, v -> { menu.dismiss(); loadState(); }), lp);
        card.addView(two, Ui.fillMargins(this, 0, 5, 0, 5));
        LinearLayout two2 = Ui.horizontal(this);
        two2.addView(Ui.button(this, Lang.t("Reset game"), Ui.TONAL, v -> { menu.dismiss(); if (netOn()) Ui.toast(this, Lang.t("Not while playing together")); else MameNative.reset(); }), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, -2, 1f);
        lp2.leftMargin = Ui.dp(this, 10);
        two2.addView(Ui.button(this, Lang.t("Insert coin"), Ui.TONAL, v -> {
            menu.dismiss();
            MameNative.setButton(0, SELECT, true);
            ui.postDelayed(() -> MameNative.setButton(0, SELECT, false), 150);
        }), lp2);
        card.addView(two2, Ui.fillMargins(this, 0, 5, 0, 5));
        LinearLayout two4 = Ui.horizontal(this);
        two4.addView(Ui.button(this, Lang.t("DIP settings"), Ui.TONAL, v -> { menu.dismiss(); openMameMenu(); }), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp4 = new LinearLayout.LayoutParams(0, -2, 1f);
        lp4.leftMargin = Ui.dp(this, 10);
        two4.addView(Ui.button(this, Lang.t("Service menu"), Ui.TONAL, v -> { menu.dismiss(); tapKey(283, 200); }), lp4);
        card.addView(two4, Ui.fillMargins(this, 0, 5, 0, 5));
        card.addView(Ui.button(this, Lang.t("Edit on-screen controls"), Ui.TONAL, v -> { menu.dismiss(); startEdit(); }), Ui.fillMargins(this, 0, 5, 0, 5));
        card.addView(Ui.button(this, Lang.t("Controller mapping"), Ui.TONAL, v -> { menu.dismiss(); startActivity(new android.content.Intent(this, MappingActivity.class)); }), Ui.fillMargins(this, 0, 5, 0, 5));
        card.addView(Ui.switchRow(this, Lang.t("Show counters"), Lang.t("FPS, refresh rate, speed and sound"), Prefs.sp(this).getBoolean("mameCounters", false), (v, on) -> {
            Prefs.put(this, "mameCounters", on);
            applyCounters();
        }), Ui.fillMargins(this, 0, 5, 0, 5));
        LinearLayout two3 = Ui.horizontal(this);
        two3.addView(Ui.button(this, Lang.t("Screen shape"), Ui.TONAL, v -> {
            menu.dismiss();
            Dialogs.choose(this, Lang.t("Screen shape"), SHAPES, Prefs.sp(this).getInt("mameShape", 0), i -> { Prefs.put(this, "mameShape", i); layoutVideo(); });
        }), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp3 = new LinearLayout.LayoutParams(0, -2, 1f);
        lp3.leftMargin = Ui.dp(this, 10);
        two3.addView(Ui.button(this, Lang.t("Screen size"), Ui.TONAL, v -> {
            menu.dismiss();
            String[] o = new String[SIZES.length];
            int cur = 0;
            for (int i = 0; i < o.length; i++) { o[i] = SIZES[i] + "%"; if (SIZES[i] == Prefs.sp(this).getInt("mameSize", 100)) cur = i; }
            Dialogs.choose(this, Lang.t("Screen size"), o, cur, i -> { Prefs.put(this, "mameSize", SIZES[i]); layoutVideo(); });
        }), lp3);
        card.addView(two3, Ui.fillMargins(this, 0, 5, 0, 5));
        card.addView(Ui.button(this, netOn() ? Lang.t("Local multiplayer (connected)") : Lang.t("Local multiplayer"), Ui.TONAL, v -> {
            menu.dismiss();
            File c = MameCore.file(this, MameCore.current(this));
            MameNetDialog.show(this, this, rom, MameCore.current(this) + ":" + (c == null ? 0 : c.length()));
        }), Ui.fillMargins(this, 0, 5, 0, 5));
        TextView quit = Ui.button(this, Lang.t("Quit game"), Ui.TEXTONLY, v -> { menu.dismiss(); finish(); });
        quit.setTextColor(Ui.DANGER);
        card.addView(quit, Ui.fillMargins(this, 0, 5, 0, 0));
        menu.show();
    }

    // ---- input -------------------------------------------------------------------------------

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (menu != null && menu.isShowing()) return super.dispatchKeyEvent(e);
        if (e.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (e.getAction() == KeyEvent.ACTION_UP) showMenu();
            return true;
        }
        if (pad.onKey(e)) return true;
        return super.dispatchKeyEvent(e);
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        if (menu != null && menu.isShowing()) return super.dispatchGenericMotionEvent(ev);
        if (pad.onMotion(ev)) return true;
        return super.dispatchGenericMotionEvent(ev);
    }

    @Override protected void onPause() {
        super.onPause();
        pad.releaseAll();
        touch.releaseAllTouch();
        paused = true;
    }

    @Override protected void onResume() {
        super.onResume();
        pad.setMaps(PadMap.load(this, 0), PadMap.load(this, 1));
        PadInput.configure(this);
        if (!editing && (menu == null || !menu.isShowing())) paused = false;
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        Native.touchSink = null;
        if (net != null) net.stop();
        running = false;
        if (thread != null) {
            try { thread.join(3000); } catch (InterruptedException e) { /* ignore */ }
        }
    }
}
