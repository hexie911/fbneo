package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;

/** Plays one game with the libretro MAME core (libmamehost.so). */
public class MameActivity extends Activity implements SurfaceHolder.Callback {
    private final Object lock = new Object();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private SurfaceView sv;
    private TouchPadView touch;
    private PadInput pad;
    private Thread thread;
    private volatile boolean running, paused, quitting;
    private volatile String failure;
    private String rom, romPath;
    private Dialog menu;
    private final boolean[][] held = new boolean[2][40];

    // libretro joypad ids
    private static final int B = 0, Y = 1, SELECT = 2, START = 3, UP = 4, DOWN = 5, LEFT = 6, RIGHT = 7, A = 8, X = 9, L = 10, R = 11;

    private static int retroId(int action) {
        switch (action) {
            case Actions.UP: return UP;
            case Actions.DOWN: return DOWN;
            case Actions.LEFT: return LEFT;
            case Actions.RIGHT: return RIGHT;
            case Actions.FIRE1: return B;
            case Actions.FIRE2: return A;
            case Actions.FIRE3: return Y;
            case Actions.FIRE4: return X;
            case Actions.FIRE5: return L;
            case Actions.FIRE6: return R;
            case Actions.COIN: return SELECT;
            case Actions.START: return START;
            default: return -1;
        }
    }

    private void send(int slot, int action, boolean down) {
        if (slot < 0 || slot > 1) return;
        int id = retroId(action);
        if (id >= 0) {
            MameNative.setButton(slot, id, down);
            return;
        }
        if (!down) return;
        switch (action) {
            case Actions.SAVE: saveState(); break;
            case Actions.LOAD: loadState(); break;
            case Actions.RESET: MameNative.reset(); break;
            case Actions.PAUSE: paused = !paused; break;
            case Actions.QUIT: finish(); break;
            default: break;
        }
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        if (Build.VERSION.SDK_INT >= 28) {
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        rom = getIntent().getStringExtra("rom");
        romPath = getIntent().getStringExtra("path");
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        sv = new SurfaceView(this);
        sv.getHolder().addCallback(this);
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        PadInput.configure(this);
        pad = new PadInput(PadMap.load(this, 0), PadMap.load(this, 1), new PadInput.Sink() {
            @Override public void onAction(int slot, int action, boolean down) {
                if (action == Actions.MENU) { if (down) ui.post(MameActivity.this::showMenu); return; }
                send(slot, action, down);
            }
        });
        touch = new TouchPadView(this, new TouchPadView.Host() {
            @Override public void openMenu() { ui.post(MameActivity.this::showMenu); }
            @Override public void editChanged(TouchPadView.El sel) { }
        });
        Native.touchSink = (action, down) -> send(0, action, down);
        root.addView(touch, new FrameLayout.LayoutParams(-1, -1));
        touch.setVisibility(Prefs.touchOn(this) ? View.VISIBLE : View.GONE);
        setContentView(root);
        hideBars();
    }

    private void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideBars(); }

    // ---- surface + emulation thread ----------------------------------------------------------

    @Override public void surfaceCreated(SurfaceHolder h) {
        synchronized (lock) { if (MameNative.loadLibraries()) MameNative.setSurface(h.getSurface()); }
        if (thread == null) start();
    }
    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) { }
    @Override public void surfaceDestroyed(SurfaceHolder h) {
        synchronized (lock) { if (MameNative.loadLibraries()) MameNative.setSurface(null); }
    }

    private void start() {
        running = true;
        thread = new Thread(this::emulate, "mame-emu");
        thread.start();
    }

    private void fail(String s) {
        failure = s;
        ui.post(() -> {
            if (isFinishing()) return;
            Dialogs.message(this, "Could not start", java.util.Collections.singletonList(s), "Close", this::finish, null, null)
                    .setCancelable(false);
        });
    }

    private File statePath() {
        File d = new File(getFilesDir(), "mame/states");
        d.mkdirs();
        return new File(d, rom + ".state");
    }

    private void emulate() {
        try {
            if (!MameNative.loadLibraries()) { fail("The MAME host library could not load: " + MameNative.loadError); return; }
            File core = MameCore.file(this, MameCore.current(this));
            if (core == null) { fail("No MAME core installed. Open the MAME section and download one."); return; }
            if (!MameNative.load(core.getPath(), MameCore.sysDir(this).getPath(), MameCore.saveDir(this).getPath())) {
                fail("The core would not load.\n\n" + MameNative.log()); return;
            }
            MameNative.setOption("mame_cpu_overclock", "default");
            if (!MameNative.loadGame(romPath)) {
                String l = MameNative.log();
                MameNative.unload();
                fail("The game would not start. The ROM set usually has to match the core's MAME version.\n\n" + l);
                return;
            }
            double[] inf = MameNative.info();
            int rate = inf != null && inf.length > 3 && inf[3] > 8000 ? (int) inf[3] : 44100;
            double fps = inf != null && inf.length > 2 && inf[2] > 10 ? inf[2] : 60;
            AudioTrack at = makeTrack(rate);
            at.play();
            short[] buf = new short[16384];
            long frameNs = (long) (1e9 / fps), next = System.nanoTime();
            boolean aclock = true;
            int emptyRuns = 0;
            while (running) {
                if (paused) { at.pause(); at.flush(); Thread.sleep(30); next = System.nanoTime(); if (!paused) at.play(); continue; }
                MameNative.runFrame();
                synchronized (lock) { MameNative.blit(); }
                int n = MameNative.audio(buf);
                if (n > 0) { at.write(buf, 0, n, AudioTrack.WRITE_BLOCKING); emptyRuns = 0; }
                else if (++emptyRuns > 5) aclock = false;
                if (!aclock || n == 0) {
                    next += frameNs;
                    long d = next - System.nanoTime();
                    if (d > 0) Thread.sleep(d / 1000000, (int) (d % 1000000));
                    else if (d < -frameNs * 4) next = System.nanoTime();
                }
            }
            at.stop();
            at.release();
            File sp = statePath();
            MameNative.saveState(sp.getPath() + ".auto");
            MameNative.unload();
        } catch (InterruptedException e) {
            // closing
        } catch (Throwable t) {
            fail("Crashed: " + t);
        }
    }

    private AudioTrack makeTrack(int rate) {
        int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT);
        AudioTrack.Builder bld = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder().setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
                .setBufferSizeInBytes(Math.max(min, rate / 10 * 4));
        if (Build.VERSION.SDK_INT >= 26) bld.setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY);
        return bld.build();
    }

    // ---- state -------------------------------------------------------------------------------

    private void saveState() {
        boolean ok = MameNative.saveState(statePath().getPath());
        ui.post(() -> Ui.toast(this, ok ? "State saved" : "Could not save state"));
    }

    private void loadState() {
        File f = statePath();
        boolean ok = f.isFile() && MameNative.loadState(f.getPath());
        ui.post(() -> Ui.toast(this, ok ? "State loaded" : "No saved state"));
    }

    // ---- menu --------------------------------------------------------------------------------

    private void showMenu() {
        if (menu != null && menu.isShowing()) return;
        pad.releaseAll();
        touch.releaseAllTouch();
        paused = true;
        final LinearLayout[] h = new LinearLayout[1];
        menu = Dialogs.base(this, h);
        menu.setOnDismissListener(d -> { paused = false; hideBars(); });
        LinearLayout card = h[0];
        TextView t = Ui.text(this, "Paused - MAME", 22, Ui.TEXT, true);
        t.setPadding(0, 0, 0, Ui.dp(this, 12));
        card.addView(t);
        card.addView(Ui.button(this, "Resume", Ui.FILLED, v -> menu.dismiss()), Ui.fillMargins(this, 0, 5, 0, 5));
        card.addView(Ui.switchRow(this, "On-screen controls", "Stick and buttons on the screen", Prefs.touchOn(this), (v, on) -> {
            Prefs.put(this, "touchOn", on);
            touch.setVisibility(on ? View.VISIBLE : View.GONE);
            if (!on) touch.releaseAllTouch();
        }), Ui.fillMargins(this, 0, 5, 0, 5));
        LinearLayout two = Ui.horizontal(this);
        two.addView(Ui.button(this, "Save state", Ui.TONAL, v -> { menu.dismiss(); saveState(); }), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.leftMargin = Ui.dp(this, 10);
        two.addView(Ui.button(this, "Load state", Ui.TONAL, v -> { menu.dismiss(); loadState(); }), lp);
        card.addView(two, Ui.fillMargins(this, 0, 5, 0, 5));
        LinearLayout two2 = Ui.horizontal(this);
        two2.addView(Ui.button(this, "Reset game", Ui.TONAL, v -> { menu.dismiss(); MameNative.reset(); }), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(0, -2, 1f);
        lp2.leftMargin = Ui.dp(this, 10);
        two2.addView(Ui.button(this, "Insert coin", Ui.TONAL, v -> {
            menu.dismiss();
            MameNative.setButton(0, SELECT, true);
            ui.postDelayed(() -> MameNative.setButton(0, SELECT, false), 150);
        }), lp2);
        card.addView(two2, Ui.fillMargins(this, 0, 5, 0, 5));
        TextView quit = Ui.button(this, "Quit game", Ui.TEXTONLY, v -> { menu.dismiss(); finish(); });
        quit.setTextColor(Ui.DANGER);
        card.addView(quit, Ui.fillMargins(this, 0, 5, 0, 0));
        menu.show();
    }

    // ---- input -------------------------------------------------------------------------------

    @Override public boolean dispatchKeyEvent(KeyEvent e) {
        if (menu != null && menu.isShowing()) return super.dispatchKeyEvent(e);
        if (e.getKeyCode() == KeyEvent.KEYCODE_BACK) {
            if (e.getAction() == KeyEvent.ACTION_UP) showMenu();
            return true;
        }
        if (pad.onKey(e)) return true;
        return super.dispatchKeyEvent(e);
    }

    @Override public boolean dispatchGenericMotionEvent(MotionEvent ev) {
        if (menu != null && menu.isShowing()) return super.dispatchGenericMotionEvent(ev);
        if (pad.onMotion(ev)) return true;
        return super.dispatchGenericMotionEvent(ev);
    }

    @Override protected void onPause() {
        super.onPause();
        pad.releaseAll();
        touch.releaseAllTouch();
        paused = true;
    }

    @Override protected void onResume() {
        super.onResume();
        if (menu == null || !menu.isShowing()) paused = false;
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        Native.touchSink = null;
        running = false;
        if (thread != null) {
            try { thread.join(3000); } catch (InterruptedException e) { /* ignore */ }
        }
    }
}
