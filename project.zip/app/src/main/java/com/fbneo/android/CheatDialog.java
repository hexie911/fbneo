package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.os.Environment;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** In-game cheat list: switch cheats on and off, add your own, delete them, load cheat files. */
final class CheatDialog {
    private CheatDialog() {}

    private static File iniFile(String rom) {
        return new File(Native.cheatsPath(), rom + ".ini");
    }

    private static String read(File f) {
        try (InputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) o.write(b, 0, n);
            return new String(o.toByteArray(), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private static boolean write(File f, String text) {
        try {
            File dir = f.getParentFile();
            if (dir != null) dir.mkdirs();
            try (FileOutputStream o = new FileOutputStream(f)) {
                o.write(text.getBytes(StandardCharsets.UTF_8));
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    /** Names of the cheats written in the game's own .ini (only those can be deleted from here). */
    private static List<String> userCheats(String rom) {
        List<String> out = new ArrayList<>();
        for (String line : read(iniFile(rom)).split("\n")) {
            String t = line.trim();
            if (t.toLowerCase(Locale.ROOT).startsWith("cheat ")) {
                int a = t.indexOf('"'), b = t.indexOf('"', a + 1);
                if (a >= 0 && b > a) out.add(t.substring(a + 1, b));
            }
        }
        return out;
    }

    private static boolean deleteUser(String rom, String name) {
        String[] lines = read(iniFile(rom)).split("\n", -1);
        StringBuilder out = new StringBuilder();
        boolean skipping = false, found = false;
        for (String line : lines) {
            String t = line.trim();
            if (!skipping && t.toLowerCase(Locale.ROOT).startsWith("cheat ")) {
                int a = t.indexOf('"'), b = t.indexOf('"', a + 1);
                if (a >= 0 && b > a && t.substring(a + 1, b).equals(name)) {
                    skipping = true;
                    found = true;
                    if (t.endsWith("}")) skipping = false;
                    continue;
                }
            }
            if (skipping) {
                if (t.startsWith("}")) skipping = false;
                continue;
            }
            out.append(line).append('\n');
        }
        return found && write(iniFile(rom), out.toString().replaceAll("\n+$", "\n"));
    }

    private static void reload() {
        try { Native.cheatReload(); } catch (UnsatisfiedLinkError | RuntimeException e) { /* not ready */ }
    }

    static void show(final Activity a, final String rom) {
        final LinearLayout[] h = new LinearLayout[1];
        final Dialog d = Dialogs.base(a, h);
        LinearLayout card = h[0];
        card.addView(Ui.text(a, "Cheats", 22, Ui.TEXT, true));

        String[] lines;
        try { lines = Native.cheatList(); } catch (UnsatisfiedLinkError | RuntimeException e) { lines = new String[0]; }
        final List<String> mine = userCheats(rom);

        LinearLayout list = Ui.vertical(a);
        if (lines.length == 0) {
            TextView none = Ui.text(a, "No cheats for this game yet. Add one below, or load a cheat file.", 14, Ui.SUB, false);
            none.setPadding(0, Ui.dp(a, 12), 0, Ui.dp(a, 4));
            list.addView(none);
        }
        for (String line : lines) {
            final String[] p = line.split("\t", -1);
            if (p.length < 5) continue;
            final int index = Integer.parseInt(p[0]);
            final String name = p[1];
            final int cur = Integer.parseInt(p[2]);
            final String[] opts = new String[p.length - 3];
            System.arraycopy(p, 3, opts, 0, opts.length);
            final boolean deletable = mine.contains(name);

            LinearLayout row = Ui.horizontal(a);
            row.setBackground(Ui.ripple(a, Ui.rounded(a, Ui.SURFACE2, 14), 14));
            row.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12));
            row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout col = Ui.vertical(a);
            col.addView(Ui.text(a, name, 15, Ui.TEXT, cur > 0));
            col.addView(Ui.text(a, cur > 0 && cur < opts.length ? opts[cur] : "Off", 12, cur > 0 ? Ui.OK : Ui.SUB, false));
            row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            if (deletable) {
                row.addView(Ui.button(a, "Delete", Ui.TEXTONLY, v -> {
                    if (deleteUser(rom, name)) { reload(); d.dismiss(); show(a, rom); }
                    else Ui.toast(a, "Could not delete");
                }));
            }
            row.setClickable(true);
            row.setOnClickListener(v -> {
                if (opts.length <= 2) {
                    try { Native.cheatSet(index, cur > 0 ? 0 : 1); } catch (UnsatisfiedLinkError | RuntimeException e) { /* */ }
                    d.dismiss();
                    show(a, rom);
                } else {
                    d.dismiss();
                    Dialogs.choose(a, name, opts, cur, w -> {
                        try { Native.cheatSet(index, w); } catch (UnsatisfiedLinkError | RuntimeException e) { /* */ }
                        show(a, rom);
                    });
                }
            });
            list.addView(row, Ui.fillMargins(a, 0, 5, 0, 5));
        }
        ScrollView sv = new Dialogs.MaxHeightScroll(a, (int) (Dialogs.screenHeight(a) * 0.5f));
        sv.addView(list);
        card.addView(sv, Ui.fillMargins(a, 0, 8, 0, 0));

        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.setPadding(0, Ui.dp(a, 12), 0, 0);
        bar.addView(Ui.button(a, "Add", Ui.TONAL, v -> { d.dismiss(); add(a, rom); }));
        TextView load = Ui.button(a, "Load file", Ui.TONAL, v -> { d.dismiss(); load(a, rom); });
        bar.addView(load, Ui.wrapMargins(a, 8, 0, 0, 0));
        bar.addView(Ui.button(a, "Close", Ui.TEXTONLY, v -> d.dismiss()), Ui.wrapMargins(a, 8, 0, 0, 0));
        card.addView(bar);
        d.show();
    }

    private static EditText field(Activity a, String hint, boolean hex) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setTextColor(Ui.TEXT);
        e.setHintTextColor(Ui.SUB);
        e.setTextSize(15);
        if (hex) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        e.setBackground(Ui.rounded(a, Ui.SURFACE2, 12));
        e.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
        return e;
    }

    private static Long parseHex(String s) {
        try {
            s = s.trim().toLowerCase(Locale.ROOT);
            if (s.startsWith("0x")) s = s.substring(2);
            return Long.parseLong(s, 16);
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** New cheat: a memory address that is set to a value on every frame. */
    private static void add(final Activity a, final String rom) {
        final LinearLayout[] h = new LinearLayout[1];
        final Dialog d = Dialogs.base(a, h);
        LinearLayout card = h[0];
        card.addView(Ui.text(a, "Add a cheat", 22, Ui.TEXT, true));
        TextView info = Ui.text(a, "The value is written to that memory address on every frame while the cheat is on. "
                + "Addresses and values are in hex (for example FF8000 and 63). CPU 0 is the main processor.", 13, Ui.SUB, false);
        info.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 6));
        card.addView(info);
        final EditText name = field(a, "Name (e.g. Infinite time)", false);
        final EditText cpu = field(a, "CPU number (0 = main)", false);
        cpu.setInputType(InputType.TYPE_CLASS_NUMBER);
        cpu.setText("0");
        final EditText addr = field(a, "Address (hex)", true);
        final EditText val = field(a, "Value (hex)", true);
        card.addView(name, Ui.fillMargins(a, 0, 6, 0, 0));
        card.addView(cpu, Ui.fillMargins(a, 0, 6, 0, 0));
        card.addView(addr, Ui.fillMargins(a, 0, 6, 0, 0));
        card.addView(val, Ui.fillMargins(a, 0, 6, 0, 0));
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.setPadding(0, Ui.dp(a, 12), 0, 0);
        bar.addView(Ui.button(a, "Cancel", Ui.TEXTONLY, v -> { d.dismiss(); show(a, rom); }));
        bar.addView(Ui.button(a, "Save", Ui.FILLED, v -> {
            String n = name.getText().toString().trim().replace('"', '\'');
            Long ad = parseHex(addr.getText().toString());
            Long va = parseHex(val.getText().toString());
            int c;
            try { c = Integer.parseInt(cpu.getText().toString().trim()); } catch (RuntimeException e) { c = -1; }
            if (n.length() == 0 || ad == null || va == null || c < 0) {
                Ui.toast(a, "Fill in a name, a hex address and a hex value");
                return;
            }
            File f = iniFile(rom);
            String old = read(f);
            if (old.length() > 0 && !old.endsWith("\n")) old += "\n";
            String block = "cheat \"" + n + "\" {\n\ttype 0\n\tdefault 0\n\t0 \"Disabled\"\n\t1 \"Enabled\", "
                    + c + ", 0x" + Long.toHexString(ad) + ", 0x" + Long.toHexString(va) + "\n}\n";
            if (!write(f, old + block)) { Ui.toast(a, "Could not write " + f); return; }
            reload();
            d.dismiss();
            show(a, rom);
        }), Ui.wrapMargins(a, 8, 0, 0, 0));
        card.addView(bar);
        d.show();
    }

    /** Pick a cheat file (.ini, .dat, .cht, .txt) from the cheats or Download folder and add it to this game. */
    private static void load(final Activity a, final String rom) {
        final List<File> found = new ArrayList<>();
        scan(new File(Native.cheatsPath()), found, 0);
        scan(new File(Environment.getExternalStorageDirectory(), "Download"), found, 0);
        scan(new File(Prefs.dataDir(a), "cheats"), found, 0);
        List<File> files = new ArrayList<>();
        for (File f : found) {
            if (f.equals(iniFile(rom))) continue;
            if (!files.contains(f)) files.add(f);
        }
        if (files.isEmpty()) {
            List<String> t = new ArrayList<>();
            t.add("Put a cheat file (.ini or .dat) into the Download folder or into " + Native.cheatsPath()
                    + ", then try again.");
            Dialogs.message(a, "No cheat files found", t, "OK", () -> show(a, rom), null, null);
            return;
        }
        String[] names = new String[files.size()];
        for (int i = 0; i < names.length; i++) names[i] = files.get(i).getName();
        final List<File> fl = files;
        Dialogs.choose(a, "Load which file?", names, -1, w -> {
            File src = fl.get(w);
            String lower = src.getName().toLowerCase(Locale.ROOT);
            boolean ok;
            if (lower.endsWith(".dat")) {
                ok = write(new File(Native.cheatsPath(), rom + ".dat"), read(src));
            } else {
                String old = read(iniFile(rom));
                if (old.length() > 0 && !old.endsWith("\n")) old += "\n";
                ok = write(iniFile(rom), old + read(src) + "\n");
            }
            if (ok) reload(); else Ui.toast(a, "Could not load that file");
            show(a, rom);
        });
    }

    private static void scan(File dir, List<File> out, int depth) {
        File[] fs = dir.listFiles();
        if (fs == null || depth > 1) return;
        for (File f : fs) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (f.isDirectory()) scan(f, out, depth + 1);
            else if (n.endsWith(".ini") || n.endsWith(".dat") || n.endsWith(".cht") || n.endsWith(".txt")) out.add(f);
        }
    }
}
