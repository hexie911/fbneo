package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Dialogs for adding buttons and macros to the on-screen controls. */
final class TouchEditor {
    private TouchEditor() {}

    /** Actions a touch button or macro can trigger, in display order. */
    static final int[] CHOICES = {
            Actions.FIRE1, Actions.FIRE2, Actions.FIRE3, Actions.FIRE4, Actions.FIRE5, Actions.FIRE6,
            Actions.UP, Actions.DOWN, Actions.LEFT, Actions.RIGHT,
            Actions.COIN, Actions.START, Actions.SWAP, Actions.MENU, Actions.PAUSE, Actions.FFWD,
            Actions.SAVE, Actions.LOAD, Actions.RESET, Actions.SERVICE, Actions.SERVICEBTN,
            Actions.HK1, Actions.HK1 + 1, Actions.HK1 + 2, Actions.HK1 + 3, Actions.HK1 + 4,
            Actions.HK1 + 5, Actions.HK1 + 6, Actions.HK1 + 7, Actions.HK1 + 8};

    static String shortName(int a) {
        switch (a) {
            case Actions.FIRE1: return "LP";
            case Actions.FIRE2: return "MP";
            case Actions.FIRE3: return "HP";
            case Actions.FIRE4: return "LK";
            case Actions.FIRE5: return "MK";
            case Actions.FIRE6: return "HK";
            case Actions.UP: return "Up";
            case Actions.DOWN: return "Down";
            case Actions.LEFT: return "Left";
            case Actions.RIGHT: return "Right";
            case Actions.COIN: return "Coin";
            case Actions.START: return "Start";
            case Actions.SWAP: return "P1/P2";
            case Actions.MENU: return "Menu";
            case Actions.PAUSE: return "Pause";
            case Actions.FFWD: return "FF";
            case Actions.SAVE: return "Save";
            case Actions.LOAD: return "Load";
            case Actions.RESET: return "Reset";
            case Actions.SERVICE: return "Test";
            case Actions.SERVICEBTN: return "Svc";
            default:
                if (a >= Actions.HK1 && a < Actions.HK1 + 9) return "HK" + (a - Actions.HK1 + 1);
                return "?";
        }
    }

    private static String longName(int a) {
        String n = Actions.name(a);
        int i = n.indexOf("  (");
        return i > 0 ? n.substring(0, i) : n;
    }

    /** One action on one button. */
    static void addButton(final Activity a, final TouchPadView v) {
        String[] names = new String[CHOICES.length];
        for (int i = 0; i < names.length; i++) names[i] = shortName(CHOICES[i]) + "   " + longName(CHOICES[i]);
        Dialogs.choose(a, "What should the button do?", names, -1, w -> {
            TouchPadView.El e = new TouchPadView.El();
            e.type = TouchPadView.BUTTON;
            e.actions = new int[]{CHOICES[w]};
            e.label = shortName(CHOICES[w]);
            e.size = 66;
            v.add(e);
        });
    }

    interface MacroCb { void on(String name, int[] actions); }

    /** A macro on the touch screen: one touch presses several actions at once (for example LP + LK). */
    static void addMacro(final Activity a, final TouchPadView v) {
        macroDialog(a, (name, acts) -> {
            TouchPadView.El e = new TouchPadView.El();
            e.type = TouchPadView.MACRO;
            e.actions = acts;
            e.label = name;
            e.size = 70;
            v.add(e);
        });
    }

    /** Asks for a name and the buttons a macro presses together. */
    static void macroDialog(final Activity a, final MacroCb done) {
        final LinearLayout[] h = new LinearLayout[1];
        final Dialog d = Dialogs.base(a, h);
        LinearLayout card = h[0];
        card.addView(Ui.text(a, "New macro", 22, Ui.TEXT, true));
        TextView info = Ui.text(a, "Tick the buttons it presses together, then name it (for example \"Throw\" = LP + LK).", 13, Ui.SUB, false);
        info.setPadding(0, Ui.dp(a, 6), 0, Ui.dp(a, 6));
        card.addView(info);
        final EditText name = new EditText(a);
        name.setHint("Name on the button (short)");
        name.setSingleLine(true);
        name.setTextColor(Ui.TEXT);
        name.setHintTextColor(Ui.SUB);
        name.setInputType(InputType.TYPE_CLASS_TEXT);
        name.setBackground(Ui.rounded(a, Ui.SURFACE2, 12));
        name.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
        card.addView(name, Ui.fillMargins(a, 0, 4, 0, 4));
        LinearLayout list = Ui.vertical(a);
        final List<CheckBox> boxes = new ArrayList<>();
        for (int act : CHOICES) {
            CheckBox cb = new CheckBox(a);
            cb.setText(shortName(act) + "   " + longName(act));
            cb.setTextColor(Ui.TEXT);
            cb.setTag(act);
            boxes.add(cb);
            list.addView(cb);
        }
        // no scroll view of its own: the dialog card already scrolls as a whole (needed in landscape)
        card.addView(list);
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.setPadding(0, Ui.dp(a, 12), 0, 0);
        bar.addView(Ui.button(a, "Cancel", Ui.TEXTONLY, x -> d.dismiss()));
        bar.addView(Ui.button(a, "Add", Ui.FILLED, x -> {
            List<Integer> acts = new ArrayList<>();
            StringBuilder auto = new StringBuilder();
            for (CheckBox cb : boxes) {
                if (cb.isChecked()) {
                    int act = (Integer) cb.getTag();
                    acts.add(act);
                    if (auto.length() > 0) auto.append("+");
                    auto.append(shortName(act));
                }
            }
            if (acts.size() < 1) { Ui.toast(a, "Tick at least one button"); return; }
            int[] arr = new int[acts.size()];
            for (int i = 0; i < arr.length; i++) arr[i] = acts.get(i);
            String n = name.getText().toString().trim();
            d.dismiss();
            done.on(n.length() > 0 ? n : auto.toString(), arr);
        }), Ui.wrapMargins(a, 8, 0, 0, 0));
        card.addView(bar);
        d.show();
    }
}
