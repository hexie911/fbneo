package com.fbneo.android;

import android.content.Context;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Which libretro MAME core is used, where it lives, and how it is downloaded. */
final class MameCore {
    private MameCore() {}

    static final String[] IDS = {"mame", "mame2003_plus", "mame2010"};
    static final String[] NAMES = {
            "MAME (current) - best, runs Tekken 3 and System 12/PlayStation arcade",
            "MAME 2003-Plus - light, older games only",
            "MAME 2010 - medium"};

    interface Progress { void on(String text); }

    static String current(Context c) { return Prefs.sp(c).getString("mameCore", "mame"); }
    static void setCurrent(Context c, String id) { Prefs.put(c, "mameCore", id); }

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "mame/cores");
        d.mkdirs();
        return d;
    }

    static File sysDir(Context c) {
        File d = new File(Prefs.mameDir(c), "system");
        d.mkdirs();
        return d;
    }

    static File saveDir(Context c) {
        File d = new File(Prefs.mameDir(c), "saves");
        d.mkdirs();
        return d;
    }

    /** The installed core file for an id, or null. A custom core picked from a file is id "custom". */
    static File file(Context c, String id) {
        if ("custom".equals(id)) {
            String p = Prefs.sp(c).getString("mameCustom", "");
            File f = new File(dir(c), "custom_libretro.so");
            return f.isFile() ? f : (p.isEmpty() ? null : null);
        }
        File f = new File(dir(c), id + "_libretro_android.so");
        return f.isFile() && f.length() > 100000 ? f : null;
    }

    static boolean installed(Context c) { return file(c, current(c)) != null; }

    static String url(String id) {
        return "https://buildbot.libretro.com/nightly/android/latest/arm64-v8a/" + id + "_libretro_android.so.zip";
    }

    /** Copies a core file the person picked by hand. */
    static void useFile(Context c, File src) throws Exception {
        File dst = new File(dir(c), "custom_libretro.so");
        if (dst.exists()) { dst.setWritable(true); dst.delete(); }
        try (InputStream in = new java.io.FileInputStream(src); OutputStream out = new FileOutputStream(dst)) {
            copy(in, out);
        }
        dst.setReadOnly();
        setCurrent(c, "custom");
    }

    /** Blocking download + unzip. Throws with a readable message. */
    static void download(Context c, String id, Progress p) throws Exception {
        File tmp = new File(dir(c), id + ".zip.part");
        HttpURLConnection h = (HttpURLConnection) new URL(url(id)).openConnection();
        h.setConnectTimeout(15000);
        h.setReadTimeout(30000);
        h.setInstanceFollowRedirects(true);
        int code = h.getResponseCode();
        if (code != 200) throw new Exception("Server answered " + code + " for " + url(id));
        long total = h.getContentLengthLong();
        try (InputStream in = new BufferedInputStream(h.getInputStream()); OutputStream out = new FileOutputStream(tmp)) {
            byte[] b = new byte[65536];
            long done = 0;
            int n;
            long last = 0;
            while ((n = in.read(b)) > 0) {
                out.write(b, 0, n);
                done += n;
                long now = System.currentTimeMillis();
                if (p != null && now - last > 300) {
                    last = now;
                    p.on("Downloading " + (done / 1048576) + (total > 0 ? " / " + (total / 1048576) : "") + " MB");
                }
            }
        }
        if (p != null) p.on("Unpacking");
        File dst = new File(dir(c), id + "_libretro_android.so");
        boolean got = false;
        try (ZipInputStream z = new ZipInputStream(new java.io.FileInputStream(tmp))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (e.getName().endsWith(".so")) {
                    File part = new File(dst.getPath() + ".part");
                    try (OutputStream out = new FileOutputStream(part)) { copy(z, out); }
                    if (dst.exists()) { dst.setWritable(true); dst.delete(); }
                    if (!part.renameTo(dst)) throw new Exception("Could not store the core");
                    got = true;
                    break;
                }
            }
        }
        tmp.delete();
        if (!got) throw new Exception("The download did not contain a core");
        dst.setReadOnly(); // Android refuses to load writable code files
    }

    private static void copy(InputStream in, OutputStream out) throws Exception {
        byte[] b = new byte[65536];
        int n;
        while ((n = in.read(b)) > 0) out.write(b, 0, n);
    }
}
