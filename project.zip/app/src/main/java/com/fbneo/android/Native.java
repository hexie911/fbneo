package com.fbneo.android;

/** JNI entry points implemented in libmain.so (src/burner/sdl/android_app.cpp). */
final class Native {
    private Native() {}

    private static boolean sLoaded;

    /** Loads the native libraries in the launcher process (used for game names only). */
    static synchronized boolean loadLibraries() {
        if (sLoaded) return true;
        try {
            System.loadLibrary("SDL2");
            System.loadLibrary("main");
            sLoaded = true;
        } catch (Throwable t) {
            sLoaded = false;
        }
        return sLoaded;
    }

    /** When set (the MAME section), the on-screen controls send their actions here instead of to libmain.so. */
    interface TouchSink { void onTouch(int action, boolean down); }
    static volatile TouchSink touchSink;

    static native void setAction(int slot, int action, boolean down);

    static native void releaseAll();

    /** Background/foreground: lets the optional video thread hand the GL context back before Android takes the surface. */
    static native void videoThreadHold(boolean hold);

    /** How fast the screen really refreshes (measured with the Choreographer), for the on-screen counter. */
    static native void setDisplayHz(float hz);

    /** One-shot menu command (an Actions number: save, load, reset, swap, quit). */
    static native void command(int action);

    /** Local multiplayer. Host = player 1, guest = player 2. */
    /** Online multiplayer: our public "ip:port" (plus "|sym" when the router cannot be punched), or "". Blocks a few seconds. */
    static native String netStun();
    static native String netRoomCode();
    static native boolean vkStart(android.view.Surface s, boolean vsync);
    static native void vkStop();
    static native int vkStatus();
    static native void netSetDelay(int frames);
    /** Online multiplayer: connect to the friend's "ip:port" (both phones call this at the same time). */
    static native void netOnline(boolean host, String peer);
    /** Online multiplayer: true = rollback netcode (default), false = plain delay-based. Only the host's choice counts. */
    static native void netSetRollback(boolean on);
    /** Chat with the other player (while playing together). Messages sent are queued for the game thread. */
    static native void chatSend(String text);
    /** Messages received since the last call, separated by the character U+0001, or "". */
    static native String chatPoll();
    static native void netHost();

    static native void netJoin(String ip);

    static native void netStop();

    /** "state|isHost(1/0)|delay|desync|message"; state = idle listen connecting ready sync run error. */
    static native String netStatus();

    /** Pauses / resumes the emulation (used while editing the on-screen controls). */
    static native void setPaused(boolean paused);

    /** On-screen controls: always player 1's pad. */
    static native void setTouch(int action, boolean down);

    /** Flips the arcade test switch (Service); returns the new state. */
    static native boolean toggleService();

    static native boolean serviceOn();

    /** Cheats of the running game: "index \t name \t selected option \t option 0 \t option 1 ..." */
    static native String[] cheatList();

    static native void cheatSet(int index, int option);

    /** Re-reads the cheat files (after adding / deleting / loading). */
    static native void cheatReload();

    static native String cheatsPath();

    static native void requestQuit();

    /** Screen shape while playing: 0,0 = the game's own, -1,-1 = stretch, otherwise width,height of the ratio. */
    static native void setAspect(int ax, int ay);

    /** DIP switches of the running game: "group \t selected option \t option 0 \t option 1 ..." per group. */
    static native String[] dipList();

    static native void dipSet(int group, int option);

    /** "fullname \t year \t manufacturer \t flags" per ROM set name; empty string when FBNeo doesn't know the set. */
    static native String[] describe(String[] names);

    // ---- TAS tools (see the TAS section of android_app.cpp) ----
    static final int T_SAVE = 1, T_LOAD = 2, T_UNDO = 3, T_REDO = 4, T_REC = 5, T_STOP = 6, T_PLAY = 7,
            T_PAUSE = 8, T_STEP = 9, T_READONLY = 10, T_TAKEOVER = 11;
    static native void tasCmd(int op, int arg, String s);
    /** frame|mode|paused|speed|rerecords|readOnly|movieFrames|p1 buttons|p2 buttons|undo|redo|slots|steps|noteSeq|net|note */
    static native String tasStatus();
    static native void tasSetSpeed(int percent);
    static native void tasSetButtons(int player, boolean turbo, int mask);
    static native int tasGetButtons(int player, boolean turbo);
    static native String[] tasMovies();
    static native long tasMemRead(long addr, int size);
    static native byte[] tasMemBytes(long addr, int len);
    static native boolean tasMemWrite(long addr, long value, int size);
    static native int tasSearchStart(long start, long end, int size, boolean signed);
    static native String tasSearchError();
    static native int tasSearchFilter(int op, long value);
    static native String[] tasSearchResults(int max);
}
