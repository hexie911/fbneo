package com.fbneo.android;

/** JNI entry points implemented in libmain.so (src/burner/sdl/android_app.cpp). */
final class Native {
    private Native() {}

    private static boolean sLoaded;

    /** Loads the native libraries in the launcher process (used for game names only). */
    static synchronized boolean loadLibraries() {
        if (sLoaded) return true;
        try {
            System.loadLibrary("SDL2");
            System.loadLibrary("main");
            sLoaded = true;
        } catch (Throwable t) {
            sLoaded = false;
        }
        return sLoaded;
    }

    static native void setAction(int slot, int action, boolean down);

    static native void releaseAll();

    /** Background/foreground: lets the optional video thread hand the GL context back before Android takes the surface. */
    static native void videoThreadHold(boolean hold);

    /** How fast the screen really refreshes (measured with the Choreographer), for the on-screen counter. */
    static native void setDisplayHz(float hz);

    /** One-shot menu command (an Actions number: save, load, reset, swap, quit). */
    static native void command(int action);

    /** Local multiplayer. Host = player 1, guest = player 2. */
    static native void netHost();

    static native void netJoin(String ip);

    static native void netStop();

    /** "state|isHost(1/0)|delay|desync|message"; state = idle listen connecting ready sync run error. */
    static native String netStatus();

    /** Pauses / resumes the emulation (used while editing the on-screen controls). */
    static native void setPaused(boolean paused);

    /** On-screen controls: always player 1's pad. */
    static native void setTouch(int action, boolean down);

    /** Flips the arcade test switch (Service); returns the new state. */
    static native boolean toggleService();

    static native boolean serviceOn();

    /** Cheats of the running game: "index \t name \t selected option \t option 0 \t option 1 ..." */
    static native String[] cheatList();

    static native void cheatSet(int index, int option);

    /** Re-reads the cheat files (after adding / deleting / loading). */
    static native void cheatReload();

    static native String cheatsPath();

    static native void requestQuit();

    /** Screen shape while playing: 0,0 = the game's own, -1,-1 = stretch, otherwise width,height of the ratio. */
    static native void setAspect(int ax, int ay);

    /** DIP switches of the running game: "group \t selected option \t option 0 \t option 1 ..." per group. */
    static native String[] dipList();

    static native void dipSet(int group, int option);

    /** "fullname \t year \t manufacturer \t flags" per ROM set name; empty string when FBNeo doesn't know the set. */
    static native String[] describe(String[] names);
}
