package com.fbneo.android;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;

/**
 * Two-player lockstep for the MAME section. Both phones run the same core from the same saved state and
 * swap one small packet per frame (the pad of frame f+delay plus a picture checksum); a frame only runs
 * once the other phone's pad for it has arrived. Host = player 1, guest = player 2.
 */
final class MameNet {
    static final int PORT = 7255;

    volatile String state = "idle";   // idle, listen, connecting, ready, run, error
    volatile String message = "";
    volatile boolean desync;
    boolean host;
    int delay = 3;

    private final String tag;
    private ServerSocket server;
    private Socket sock;
    private DataInputStream in;
    private DataOutputStream out;
    private volatile boolean closed;

    private final int[] ownMask = new int[256];
    private final int[] remoteMask = new int[256];
    private final int[] remoteFrame = new int[256];
    private final int[] ownHash = new int[256];
    private final int[] ownHashFrame = new int[256];
    private final Object lock = new Object();

    private final int manualDelay;

    /** manualDelay 0 = pick from the measured ping; otherwise that many frames. */
    MameNet(String rom, String coreTag, int manualDelay) { this.tag = "MAMENET1|" + rom + "|" + coreTag; this.manualDelay = manualDelay; }

    boolean active() { return "run".equals(state); }

    // ---- connecting ----------------------------------------------------------------------------

    void startHost() {
        host = true;
        state = "listen";
        message = "Waiting for your friend...";
        new Thread(() -> {
            try {
                server = new ServerSocket();
                server.setReuseAddress(true);
                server.bind(new InetSocketAddress(PORT));
                Socket s = server.accept();
                attach(s);
                handshake();
            } catch (Exception e) {
                fail(closed ? "Cancelled" : "Connection failed: " + e.getMessage());
            }
        }, "mame-net-host").start();
    }

    void startJoin(final String ip) {
        host = false;
        state = "connecting";
        message = "Connecting to " + ip + "...";
        new Thread(() -> {
            try {
                Socket s = new Socket();
                s.connect(new InetSocketAddress(ip, PORT), 6000);
                attach(s);
                handshake();
            } catch (Exception e) {
                fail(closed ? "Cancelled" : "Could not connect: " + e.getMessage());
            }
        }, "mame-net-join").start();
    }

    private void attach(Socket s) throws Exception {
        sock = s;
        s.setTcpNoDelay(true);
        s.setSoTimeout(0);
        in = new DataInputStream(new java.io.BufferedInputStream(s.getInputStream(), 65536));
        out = new DataOutputStream(new java.io.BufferedOutputStream(s.getOutputStream(), 65536));
        state = "connecting";
        message = "Connected, checking the games...";
    }

    private void handshake() throws Exception {
        out.writeUTF(tag);
        out.flush();
        String theirs = in.readUTF();
        if (!theirs.equals(tag)) {
            fail("The two phones do not have the same game or core.\nYours: " + tag + "\nTheirs: " + theirs);
            return;
        }
        if (host) {
            // measure the round trip to pick an input delay
            long total = 0;
            for (int i = 0; i < 6; i++) {
                long t = System.nanoTime();
                out.writeLong(t); out.flush();
                in.readLong();
                total += System.nanoTime() - t;
            }
            double rttMs = total / 6e6;
            delay = manualDelay > 0 ? manualDelay : (int) Math.max(2, Math.min(10, Math.ceil(rttMs / 2 / 16.7) + 1));
            out.writeInt(delay);
            out.flush();
            message = "Linked (" + Math.round(rttMs) + " ms). Waiting for the game to sync...";
        } else {
            for (int i = 0; i < 6; i++) { long t = in.readLong(); out.writeLong(t); out.flush(); }
            delay = in.readInt();
            message = "Linked. Waiting for the game to sync...";
        }
        state = "ready";
    }

    // ---- start of the match: host's state goes to the guest -------------------------------------------

    /** Called by the emulation thread once state is "ready". */
    void syncStart(File tmp) throws Exception {
        if (host) {
            MameNative.reset();
            if (!MameNative.saveState(tmp.getPath())) throw new Exception("The core could not save its state");
            byte[] b = readAll(tmp);
            out.writeInt(b.length);
            out.write(b);
            out.flush();
            if (in.readByte() != 'G') throw new Exception("Bad sync answer");
        } else {
            int n = in.readInt();
            if (n <= 0 || n > 200_000_000) throw new Exception("Bad state size");
            byte[] b = new byte[n];
            in.readFully(b);
            try (FileOutputStream f = new FileOutputStream(tmp)) { f.write(b); }
            if (!MameNative.loadState(tmp.getPath())) throw new Exception("The core could not load the host's state");
            out.writeByte('G');
            out.flush();
        }
        tmp.delete();
        synchronized (lock) {
            for (int i = 0; i < 256; i++) { remoteFrame[i] = -1; ownHashFrame[i] = -1; ownMask[i] = 0; }
            for (int f = 0; f < delay; f++) { remoteFrame[f] = f; remoteMask[f] = 0; }
        }
        state = "run";
        message = "Connected";
        Thread t = new Thread(this::receiver, "mame-net-rx");
        t.setDaemon(true);
        t.start();
    }

    private static byte[] readAll(File f) throws Exception {
        byte[] b = new byte[(int) f.length()];
        try (DataInputStream d = new DataInputStream(new FileInputStream(f))) { d.readFully(b); }
        return b;
    }

    // ---- per frame -----------------------------------------------------------------------------------

    private void receiver() {
        try {
            byte[] b = new byte[16];
            ByteBuffer bb = ByteBuffer.wrap(b);
            while (!closed) {
                in.readFully(b);
                bb.rewind();
                int f = bb.getInt(), m = bb.getInt(), hf = bb.getInt(), h = bb.getInt();
                synchronized (lock) {
                    remoteMask[f & 255] = m;
                    remoteFrame[f & 255] = f;
                    if (hf >= 0 && ownHashFrame[hf & 255] == hf && ownHash[hf & 255] != h) desync = true;
                    lock.notifyAll();
                }
            }
        } catch (Exception e) {
            if (!closed) fail("The other phone disconnected");
        }
    }

    /** Sends this phone's pad for frame f+delay and waits for the pad of frame f; returns {player1, player2}. */
    int[] step(int f, int local) throws Exception {
        int hf = f - 12;
        int h = 0;
        synchronized (lock) {
            ownMask[(f + delay) & 255] = local;
            if (hf >= 0 && ownHashFrame[hf & 255] == hf) h = ownHash[hf & 255]; else hf = -1;
        }
        ByteBuffer bb = ByteBuffer.allocate(16);
        bb.putInt(f + delay).putInt(local).putInt(hf).putInt(h);
        out.write(bb.array());
        out.flush();
        int remote;
        long end = System.currentTimeMillis() + 8000;
        synchronized (lock) {
            while (remoteFrame[f & 255] != f) {
                if (closed || "error".equals(state)) throw new Exception(message);
                long left = end - System.currentTimeMillis();
                if (left <= 0) throw new Exception("The other phone stopped answering");
                lock.wait(Math.min(left, 100));
            }
            remote = remoteMask[f & 255];
        }
        int mine = ownMask[f & 255];
        return host ? new int[]{mine, remote} : new int[]{remote, mine};
    }

    void setHash(int f, int h) {
        synchronized (lock) { ownHash[f & 255] = h; ownHashFrame[f & 255] = f; }
    }

    // ---- ending --------------------------------------------------------------------------------------

    void fail(String why) {
        if (!"error".equals(state)) { message = why; state = "error"; }
        closeSockets();
    }

    void stop() {
        closed = true;
        state = "idle";
        message = "";
        closeSockets();
    }

    private void closeSockets() {
        closed = true;
        try { if (server != null) server.close(); } catch (Exception e) { /* ignore */ }
        try { if (sock != null) sock.close(); } catch (Exception e) { /* ignore */ }
        synchronized (lock) { lock.notifyAll(); }
    }
}
