package com.fbneo.android;

/** Action numbers shared with the native side (src/burner/sdl/android_app.h). */
final class Actions {
    private Actions() {}

    static final int UP = 0, DOWN = 1, LEFT = 2, RIGHT = 3;
    static final int FIRE1 = 4, FIRE2 = 5, FIRE3 = 6, FIRE4 = 7, FIRE5 = 8, FIRE6 = 9;
    static final int COIN = 10, START = 11;
    static final int SWAP = 16, PAUSE = 17, FFWD = 18, SAVE = 19, LOAD = 20, QUIT = 21, RESET = 22, MENU = 23;
    static final int HK1 = 24; // HK1..HK9 = 24..32
    static final int SERVICE = 33, SERVICEBTN = 34, CHAT = 35;
    static final int COUNT = 40;

    /** Everything the mapping screen lists, in display order. */
    static final int[] PLAYER = {UP, DOWN, LEFT, RIGHT, FIRE1, FIRE2, FIRE3, FIRE4, FIRE5, FIRE6, COIN, START};
    static final int[] EMULATOR = {MENU, CHAT, SERVICE, SERVICEBTN, SWAP, PAUSE, FFWD, SAVE, LOAD, RESET, QUIT,
            HK1, HK1 + 1, HK1 + 2, HK1 + 3, HK1 + 4, HK1 + 5, HK1 + 6, HK1 + 7, HK1 + 8};

    /** The order used by "Guided setup". */
    static final int[] GUIDED = {UP, DOWN, LEFT, RIGHT, FIRE1, FIRE2, FIRE3, FIRE4, FIRE5, FIRE6, COIN, START, SWAP, HK1};

    static String key(int a) {
        switch (a) {
            case UP: return "up";
            case DOWN: return "down";
            case LEFT: return "left";
            case RIGHT: return "right";
            case FIRE1: return "b1";
            case FIRE2: return "b2";
            case FIRE3: return "b3";
            case FIRE4: return "b4";
            case FIRE5: return "b5";
            case FIRE6: return "b6";
            case COIN: return "coin";
            case START: return "start";
            case SWAP: return "swap";
            case PAUSE: return "pause";
            case FFWD: return "ffwd";
            case SAVE: return "save";
            case LOAD: return "load";
            case QUIT: return "quit";
            case RESET: return "reset";
            case MENU: return "menu";
            case SERVICE: return "service";
            case SERVICEBTN: return "servbtn";
            case CHAT: return "chat";
            default:
                if (a >= HK1 && a < HK1 + 9) return "hk" + (a - HK1 + 1);
                return "x" + a;
        }
    }

    static int fromKey(String k) {
        for (int a : PLAYER) if (key(a).equals(k)) return a;
        for (int a : EMULATOR) if (key(a).equals(k)) return a;
        return -1;
    }

    static String name(int a) {
        switch (a) {
            case UP: return "Up";
            case DOWN: return "Down";
            case LEFT: return "Left";
            case RIGHT: return "Right";
            case FIRE1: return "Button 1  (LP)";
            case FIRE2: return "Button 2  (MP)";
            case FIRE3: return "Button 3  (HP)";
            case FIRE4: return "Button 4  (LK)";
            case FIRE5: return "Button 5  (MK)";
            case FIRE6: return "Button 6  (HK)";
            case COIN: return "Insert coin";
            case START: return "Start";
            case SWAP: return "Swap player 1 / player 2";
            case PAUSE: return "Pause";
            case FFWD: return "Fast forward (hold)";
            case SAVE: return "Quick save state";
            case LOAD: return "Quick load state";
            case QUIT: return "Quit game";
            case RESET: return "Reset game";
            case MENU: return "Open pause menu";
            case CHAT: return "Open chat (while playing together)";
            case SERVICE: return "Service / test menu (on/off)";
            case SERVICEBTN: return "Service button (hold; moves the test menu cursor)";
            default:
                if (a >= HK1 && a < HK1 + 9) return "Lua hotkey " + (a - HK1 + 1) + "  (Alt+" + (a - HK1 + 1) + ")";
                return "Action " + a;
        }
    }
}
