package com.fbneo.android;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

/** Small helpers so the screens can be built in code (no layout XML, no support libraries). */
final class Ui {
    private Ui() {}

    // Palette (dark only)
    static final int BG = 0xFF0E1014;
    static final int SURFACE = 0xFF171A21;
    static final int SURFACE2 = 0xFF1F242D;
    static final int OUTLINE = 0xFF2B313C;
    static final int TEXT = 0xFFE8EAF0;
    static final int SUB = 0xFF98A0AE;
    static final int ACCENT = 0xFF8BB4FF;
    static final int ACCENT_DIM = 0xFF1F2E4D;
    static final int ON_ACCENT = 0xFF0A1730;
    static final int DANGER = 0xFFFF7A74;
    static final int OK = 0xFF7BDCA1;
    static final int WARN = 0xFFFFC266;
    static final int WARN_DIM = 0xFF3A2D14;

    static final int FILLED = 0, TONAL = 1, TEXTONLY = 2;

    static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable rounded(Context c, int color, float radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static GradientDrawable outlined(Context c, int fill, int stroke, float radiusDp) {
        GradientDrawable d = rounded(c, fill, radiusDp);
        d.setStroke(Math.max(1, dp(c, 1)), stroke);
        return d;
    }

    /** Background with a touch ripple that follows the rounded corners. */
    static Drawable ripple(Context c, Drawable content, float radiusDp) {
        return new RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), content, rounded(c, Color.WHITE, radiusDp));
    }

    static TextView text(Context c, CharSequence s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(MEDIUM);
        t.setIncludeFontPadding(false);
        return t;
    }

    /** Tiny scale-down feedback while a view is pressed. Doesn't consume the touch. */
    static void press(final View v) {
        v.setOnTouchListener((view, e) -> {
            int a = e.getActionMasked();
            if (a == MotionEvent.ACTION_DOWN) {
                view.animate().scaleX(0.97f).scaleY(0.97f).setDuration(90).start();
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                view.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
            }
            return false;
        });
    }

    static TextView button(Context c, String label, int style, View.OnClickListener l) {
        TextView b = new TextView(c);
        b.setText(label);
        b.setTextSize(15);
        b.setTypeface(MEDIUM);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setMinHeight(dp(c, 46));
        b.setPadding(dp(c, 22), 0, dp(c, 22), 0);
        int fill = style == FILLED ? ACCENT : style == TONAL ? SURFACE2 : Color.TRANSPARENT;
        b.setTextColor(style == FILLED ? ON_ACCENT : style == TONAL ? TEXT : ACCENT);
        b.setBackground(ripple(c, rounded(c, fill, 23), 23));
        b.setClickable(true);
        b.setFocusable(true);
        b.setOnClickListener(l);
        press(b);
        return b;
    }

    static ImageView icon(Context c, int kind, int color, float sizeDp) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(Icons.get(kind, color));
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp)));
        return v;
    }

    static View iconButton(Context c, int kind, String description, View.OnClickListener l) {
        ImageView v = new ImageView(c);
        v.setImageDrawable(Icons.get(kind, TEXT));
        int pad = dp(c, 11);
        v.setPadding(pad, pad, pad, pad);
        v.setBackground(ripple(c, rounded(c, SURFACE, 22), 22));
        v.setContentDescription(description);
        v.setClickable(true);
        v.setFocusable(true);
        v.setOnClickListener(l);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(c, 44), dp(c, 44)));
        press(v);
        return v;
    }

    static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    static LinearLayout.LayoutParams margins(Context c, LinearLayout.LayoutParams p, int l, int t, int r, int b) {
        p.setMargins(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
        return p;
    }

    static LinearLayout.LayoutParams wrapMargins(Context c, int l, int t, int r, int b) {
        return margins(c, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT), l, t, r, b);
    }

    static LinearLayout.LayoutParams fillMargins(Context c, int l, int t, int r, int b) {
        return margins(c, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT), l, t, r, b);
    }

    static LinearLayout vertical(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    static LinearLayout horizontal(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    /** A rounded surface that can hold content. */
    static LinearLayout card(Context c, int color, float radiusDp) {
        LinearLayout l = vertical(c);
        l.setBackground(rounded(c, color, radiusDp));
        return l;
    }

    /** Page header: back arrow + title. */
    static LinearLayout topBar(Context c, String title, final Runnable back) {
        LinearLayout bar = horizontal(c);
        bar.setPadding(dp(c, 12), dp(c, 12), dp(c, 16), dp(c, 8));
        bar.addView(iconButton(c, Icons.BACK, "Back", v -> back.run()));
        TextView t = text(c, title, 22, TEXT, true);
        t.setPadding(dp(c, 14), 0, 0, 0);
        bar.addView(t);
        return bar;
    }

    /** Settings-style row on a card: optional icon, title, subtitle, chevron when clickable. */
    static LinearLayout row(Context c, String title, String subtitle, View.OnClickListener click) {
        return row(c, -1, title, subtitle, click);
    }

    static LinearLayout row(Context c, int iconKind, String title, String subtitle, View.OnClickListener click) {
        LinearLayout r = horizontal(c);
        r.setBackground(click != null ? ripple(c, rounded(c, SURFACE, 16), 16) : rounded(c, SURFACE, 16));
        r.setPadding(dp(c, 16), dp(c, 14), dp(c, 12), dp(c, 14));
        if (iconKind >= 0) {
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(c, 22), dp(c, 22));
            ip.rightMargin = dp(c, 14);
            ImageView ic = icon(c, iconKind, ACCENT, 22);
            ic.setLayoutParams(ip);
            r.addView(ic);
        }
        LinearLayout col = vertical(c);
        TextView t = text(c, title, 16, TEXT, false);
        t.setTag("title");
        col.addView(t);
        if (subtitle != null) {
            TextView s = text(c, subtitle, 13, SUB, false);
            s.setTag("sub");
            s.setLineSpacing(0, 1.1f);
            s.setPadding(0, dp(c, 3), 0, 0);
            col.addView(s);
        }
        r.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (click != null) {
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(dp(c, 18), dp(c, 18));
            cp.leftMargin = dp(c, 8);
            ImageView ch = icon(c, Icons.CHEVRON, SUB, 18);
            ch.setLayoutParams(cp);
            r.addView(ch);
            r.setClickable(true);
            r.setFocusable(true);
            r.setOnClickListener(click);
            press(r);
        }
        r.setLayoutParams(fillMargins(c, 16, 3, 16, 3));
        return r;
    }

    static LinearLayout switchRow(Context c, String title, String subtitle, boolean checked,
                                  final CompoundButton.OnCheckedChangeListener l) {
        final LinearLayout r = row(c, title, subtitle, null);
        final Switch sw = new Switch(c);
        int[][] states = {{android.R.attr.state_checked}, {}};
        sw.setThumbTintList(new ColorStateList(states, new int[]{ON_ACCENT, 0xFF8A93A3}));
        sw.setTrackTintList(new ColorStateList(states, new int[]{ACCENT, 0xFF343B47}));
        sw.setChecked(checked);
        sw.setOnCheckedChangeListener(l);
        r.addView(sw);
        r.setClickable(true);
        r.setFocusable(true);
        r.setBackground(ripple(c, rounded(c, SURFACE, 16), 16));
        r.setOnClickListener(v -> sw.toggle());
        press(r);
        return r;
    }

    static void setSub(View row, String s) {
        View v = row.findViewWithTag("sub");
        if (v instanceof TextView) ((TextView) v).setText(s);
    }

    static TextView section(Context c, String s) {
        TextView t = text(c, s.toUpperCase(), 12, ACCENT, true);
        t.setLetterSpacing(0.1f);
        t.setPadding(dp(c, 24), dp(c, 22), dp(c, 24), dp(c, 8));
        return t;
    }

    static TextView heading(Context c, String s) {
        return section(c, s);
    }

    /** Small rounded label. */
    static TextView chip(Context c, String s, int textColor, int fillColor) {
        TextView t = text(c, s, 11, textColor, true);
        t.setBackground(rounded(c, fillColor, 8));
        t.setPadding(dp(c, 8), dp(c, 4), dp(c, 8), dp(c, 4));
        return t;
    }

    static void toast(Activity a, String s) {
        android.widget.Toast.makeText(a, s, android.widget.Toast.LENGTH_LONG).show();
    }
}
