package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/**
 * "Online multiplayer": play over the internet with no server. Each phone learns its public address from a
 * public STUN server and shows it as a short code; you swap codes in any chat app, paste the friend's code and
 * both tap Connect at the same time. The phones then punch through their routers and talk directly.
 */
final class OnlineDialog {
    private final Activity a;
    private final String game;
    private final Handler h = new Handler(Looper.getMainLooper());
    private Dialog d;
    private LinearLayout card;
    private String screen = "menu";      // menu, code, status
    private boolean host;
    private String myCode = "", myAddr = "", warn = "";
    private boolean finding;
    private TextView statusText;
    private EditText friend;
    private String lastError = "";
    private static String sMyCode = "", sMyAddr = "", sWarn = "";   // survives closing the dialog while waiting

    static void show(Activity a, String game) { new OnlineDialog(a, game).open(); }

    private OnlineDialog(Activity a, String game) { this.a = a; this.game = game; }

    // ---- codes ---------------------------------------------------------------------------------

    static String encode(String addr) {
        try {
            String[] p = addr.split("[:|]");
            String[] ip = p[0].split("\\.");
            long v = 0;
            for (String s : ip) v = (v << 8) | Integer.parseInt(s);
            v = (v << 16) | Integer.parseInt(p[1]);
            String b = Long.toString(v, 36).toUpperCase(Locale.ROOT);
            while (b.length() < 10) b = "0" + b;
            int sum = 0;
            for (char c : b.toCharArray()) sum += Character.digit(c, 36);
            String all = b + Character.toUpperCase(Character.forDigit(sum % 36, 36));
            return all.substring(0, 4) + "-" + all.substring(4, 8) + "-" + all.substring(8);
        } catch (RuntimeException e) {
            return "";
        }
    }

    /** "ip:port" or null when the code is mistyped. */
    static String decode(String code) {
        String c = code.replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
        if (c.length() != 11) return null;
        try {
            int sum = 0;
            for (int i = 0; i < 10; i++) sum += Character.digit(c.charAt(i), 36);
            if (Character.toUpperCase(Character.forDigit(sum % 36, 36)) != c.charAt(10)) return null;
            long v = Long.parseLong(c.substring(0, 10), 36);
            int port = (int) (v & 0xFFFF);
            long ip = v >> 16;
            if (ip > 0xFFFFFFFFL || port == 0) return null;
            return ((ip >> 24) & 255) + "." + ((ip >> 16) & 255) + "." + ((ip >> 8) & 255) + "." + (ip & 255) + ":" + port;
        } catch (RuntimeException e) {
            return null;
        }
    }

    // ---- screens -------------------------------------------------------------------------------

    private String[] status() {
        try { return Native.netStatus().split("\\|", 5); }
        catch (UnsatisfiedLinkError | RuntimeException e) { return new String[]{"idle", "0", "3", "0", ""}; }
    }

    private void open() {
        final LinearLayout[] holder = new LinearLayout[1];
        d = Dialogs.base(a, holder);
        card = holder[0];
        String st = status()[0];
        if (st.equals("error")) { lastError = status().length > 4 ? status()[4] : ""; stopAll(); st = "idle"; }
        if (st.equals("run")) screen = "status";
        else if (st.equals("connecting") || st.equals("ready") || st.equals("sync") || st.equals("listen")) {
            screen = "code";
            host = status()[1].equals("1");
            myCode = sMyCode; myAddr = sMyAddr; warn = sWarn;
        }
        d.setOnDismissListener(x -> h.removeCallbacksAndMessages(null));
        render();
        d.show();
        h.postDelayed(new Runnable() { @Override public void run() { tick(); h.postDelayed(this, 500); } }, 500);
    }

    private TextView note(String t) {
        TextView x = Ui.text(a, t, 13, Ui.SUB, false);
        x.setLineSpacing(0, 1.15f);
        x.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 8));
        return x;
    }

    private View choice(String head, String sub, View.OnClickListener l) {
        LinearLayout r = Ui.row(a, head, sub, l);
        r.setLayoutParams(Ui.fillMargins(a, 0, 4, 0, 4));
        r.setBackground(Ui.ripple(a, Ui.rounded(a, Ui.SURFACE2, 16), 16));
        return r;
    }

    private void render() {
        card.removeAllViews();
        statusText = null;
        friend = null;
        TextView t = Ui.text(a, "Online multiplayer", 22, Ui.TEXT, true);
        t.setPadding(0, 0, 0, Ui.dp(a, 6));
        card.addView(t);
        if (screen.equals("menu")) {
            if (lastError.length() > 0) {
                TextView err = Ui.text(a, lastError, 13, Ui.WARN, true);
                err.setPadding(0, 0, 0, Ui.dp(a, 8));
                card.addView(err);
            }
            card.addView(note("Play " + game + " with a friend on a different network, with no server. "
                    + "You swap short codes in any chat app, then both tap Connect. Both of you need the same game and the same ROM files. "
                    + "The host is player 1."));
            final boolean rb = Prefs.sp(a).getBoolean("onlineRollback", true);
            card.addView(choice("Netcode: " + (rb ? "Rollback" : "Delay-based"),
                    rb ? "Smooth like GGPO: guesses your friend's moves and corrects them. Tap to switch"
                       : "Waits for your friend every frame: steadier but laggier. Tap to switch",
                    v -> { Prefs.put(a, "onlineRollback", !rb); render(); }));
            card.addView(choice("Host", "You are player 1", v -> begin(true)));
            card.addView(choice("Join", "You are player 2", v -> begin(false)));
            card.addView(Ui.button(a, "Close", Ui.TEXTONLY, v -> d.dismiss()), Ui.wrapMargins(a, 0, 6, 0, 0));
        } else if (screen.equals("code")) {
            renderCode();
        } else {
            renderStatus();
        }
    }

    private void begin(boolean asHost) {
        host = asHost;
        lastError = "";
        myCode = ""; myAddr = ""; warn = "";
        sMyCode = ""; sMyAddr = ""; sWarn = "";
        screen = "code";
        finding = true;
        render();
        new Thread(() -> {
            String r;
            try { r = Native.netStun(); } catch (UnsatisfiedLinkError | RuntimeException e) { r = ""; }
            final String res = r;
            h.post(() -> {
                finding = false;
                if (res.length() == 0) {
                    lastError = "Could not find your public address. Check your internet connection.";
                    screen = "menu";
                } else {
                    myAddr = res.split("\\|")[0];
                    myCode = encode(res);
                    warn = res.contains("|sym")
                            ? "Your network gives a different address for every connection, so connecting will probably fail. A Wi-Fi network (not mobile data) usually works."
                            : "";
                    sMyCode = myCode; sMyAddr = myAddr; sWarn = warn;
                }
                render();
            });
        }, "net-stun").start();
    }

    private void renderCode() {
        card.addView(Ui.text(a, host ? "You are player 1 (host)" : "You are player 2", 14, Ui.ACCENT, true));
        if (finding) {
            card.addView(note("Finding your address..."));
        } else {
            card.addView(note("1. Send your code to your friend.\n2. Paste their code below.\n3. Both of you tap Connect at the same time."));
            card.addView(Ui.text(a, "Your code", 13, Ui.SUB, true), Ui.fillMargins(a, 0, 4, 0, 0));
            TextView code = Ui.text(a, myCode, 26, Ui.TEXT, true);
            code.setLetterSpacing(0.08f);
            code.setTextIsSelectable(true);
            code.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 4));
            card.addView(code);
            LinearLayout bar = Ui.horizontal(a);
            bar.addView(Ui.button(a, "Copy", Ui.TONAL, v -> {
                ((ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("code", myCode));
                Ui.toast(a, "Copied");
            }));
            bar.addView(Ui.button(a, "Share", Ui.TONAL, v -> {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, "My FBNeo code for " + game + ": " + myCode);
                a.startActivity(Intent.createChooser(i, "Send your code"));
            }), Ui.wrapMargins(a, 8, 0, 0, 0));
            card.addView(bar);
            if (warn.length() > 0) {
                TextView w = Ui.text(a, warn, 12, Ui.WARN, false);
                w.setPadding(0, Ui.dp(a, 8), 0, 0);
                card.addView(w);
            }
            card.addView(Ui.text(a, "Friend's code", 13, Ui.SUB, true), Ui.fillMargins(a, 0, 12, 0, 0));
            friend = new EditText(a);
            friend.setSingleLine(true);
            friend.setHint("paste it here");
            friend.setTextColor(Ui.TEXT);
            friend.setHintTextColor(Ui.SUB);
            friend.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
            friend.setBackground(Ui.rounded(a, Ui.SURFACE2, 12));
            friend.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
            card.addView(friend, Ui.fillMargins(a, 0, 4, 0, 4));
            String st = status()[0];
            boolean busy = st.equals("connecting") || st.equals("ready") || st.equals("sync");
            if (busy) friend.setEnabled(false);
        }
        statusText = Ui.text(a, "", 14, Ui.ACCENT, true);
        statusText.setPadding(0, Ui.dp(a, 6), 0, 0);
        card.addView(statusText);
        LinearLayout bar2 = Ui.horizontal(a);
        bar2.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar2.addView(Ui.button(a, "Cancel", Ui.TEXTONLY, v -> { stopAll(); screen = "menu"; render(); }));
        if (!finding) bar2.addView(Ui.button(a, "Connect", Ui.FILLED, v -> connect()), Ui.wrapMargins(a, 8, 0, 0, 0));
        card.addView(bar2, Ui.fillMargins(a, 0, 8, 0, 0));
    }

    private void connect() {
        if (friend == null) return;
        String peer = decode(friend.getText().toString());
        if (peer == null) { Ui.toast(a, "That code does not look right"); return; }
        if (peer.equals(myAddr)) { Ui.toast(a, "That is your own code"); return; }
        try {
            Native.netSetRollback(Prefs.sp(a).getBoolean("onlineRollback", true));
            Native.netOnline(host, peer);
        } catch (UnsatisfiedLinkError | RuntimeException e) { Ui.toast(a, "Netplay is not available"); return; }
        friend.setEnabled(false);
    }

    private void renderStatus() {
        String[] st = status();
        card.addView(note("You are player " + (st[1].equals("1") ? "1 (host)" : "2") + ". Input delay " + st[2]
                + " frames. Both phones must keep the game open. Quitting the game on one phone ends the session."));
        statusText = Ui.text(a, "", 14, Ui.OK, true);
        card.addView(statusText);
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.addView(Ui.button(a, "Close", Ui.TEXTONLY, v -> d.dismiss()));
        TextView stop = Ui.button(a, "Disconnect", Ui.TONAL, v -> { stopAll(); screen = "menu"; render(); });
        stop.setTextColor(Ui.DANGER);
        bar.addView(stop, Ui.wrapMargins(a, 8, 0, 0, 0));
        card.addView(bar, Ui.fillMargins(a, 0, 8, 0, 0));
    }

    private void stopAll() {
        try { Native.netStop(); } catch (UnsatisfiedLinkError | RuntimeException e) { /* ignore */ }
    }

    private void tick() {
        String[] st = status();
        String state = st[0];
        String msg = st.length > 4 ? st[4] : "";
        if (state.equals("run") && !screen.equals("status")) { screen = "status"; render(); return; }
        if (state.equals("error")) {
            lastError = msg;
            stopAll();
            screen = "menu";
            render();
            return;
        }
        if (statusText != null) {
            String s;
            switch (state) {
                case "connecting": s = msg; break;
                case "ready":
                case "sync": s = "Syncing the two games..."; break;
                case "run": s = (st[3].equals("1") ? "Out of sync: " : "Connected. ") + msg; break;
                default: s = finding ? "" : "";
            }
            statusText.setText(s);
        }
    }
}
