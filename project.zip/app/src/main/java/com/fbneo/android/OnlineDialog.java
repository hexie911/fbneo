package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

/**
 * "Online multiplayer": play over the internet with no server of ours. The host gets a short room code and
 * waits; the friend types it. The phones meet through a free public MQTT broker, try a direct connection and
 * fall back to relaying the game through the broker when the networks do not allow a direct one.
 */
final class OnlineDialog {
    private final Activity a;
    private final String game;
    private final Handler h = new Handler(Looper.getMainLooper());
    private Dialog d;
    private LinearLayout card;
    private String screen = "menu";      // menu, code, status
    private boolean host;
    private String myCode = "";
    private boolean finding;
    private TextView statusText;
    private EditText friend;
    private String lastError = "";
    private static String sMyCode = "";   // survives closing the dialog while waiting

    static void show(Activity a, String game) { new OnlineDialog(a, game).open(); }

    private OnlineDialog(Activity a, String game) { this.a = a; this.game = game; }

    static String pretty(String c) {
        c = c.replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
        return c.length() == 7 ? c.substring(0, 4) + "-" + c.substring(4) : c;
    }

    // ---- screens -------------------------------------------------------------------------------

    private String[] status() {
        try { return Native.netStatus().split("\\|", 5); }
        catch (UnsatisfiedLinkError | RuntimeException e) { return new String[]{"idle", "0", "3", "0", ""}; }
    }

    private void open() {
        final LinearLayout[] holder = new LinearLayout[1];
        d = Dialogs.base(a, holder);
        card = holder[0];
        String st = status()[0];
        if (st.equals("error")) { lastError = status().length > 4 ? status()[4] : ""; stopAll(); st = "idle"; }
        if (st.equals("run")) screen = "status";
        else if (st.equals("connecting") || st.equals("ready") || st.equals("sync") || st.equals("listen")) {
            screen = "code";
            host = status()[1].equals("1");
            myCode = sMyCode;
        }
        d.setOnDismissListener(x -> h.removeCallbacksAndMessages(null));
        render();
        d.show();
        h.postDelayed(new Runnable() { @Override public void run() { tick(); h.postDelayed(this, 500); } }, 500);
    }

    private TextView note(String t) {
        TextView x = Ui.text(a, t, 13, Ui.SUB, false);
        x.setLineSpacing(0, 1.15f);
        x.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 8));
        return x;
    }

    private View choice(String head, String sub, View.OnClickListener l) {
        LinearLayout r = Ui.row(a, head, sub, l);
        r.setLayoutParams(Ui.fillMargins(a, 0, 4, 0, 4));
        r.setBackground(Ui.ripple(a, Ui.rounded(a, Ui.SURFACE2, 16), 16));
        return r;
    }

    private void render() {
        card.removeAllViews();
        statusText = null;
        friend = null;
        TextView t = Ui.text(a, "Online multiplayer", 22, Ui.TEXT, true);
        t.setPadding(0, 0, 0, Ui.dp(a, 6));
        card.addView(t);
        if (screen.equals("menu")) {
            if (lastError.length() > 0) {
                TextView err = Ui.text(a, lastError, 13, Ui.WARN, true);
                err.setPadding(0, 0, 0, Ui.dp(a, 8));
                card.addView(err);
            }
            card.addView(note("Play " + game + " with a friend anywhere. The host gets a short code, the friend types it, "
                    + "and you are connected. Both of you need the same game and the same ROM files. The host is player 1."));
            final boolean rb = Prefs.sp(a).getBoolean("onlineRollback", true);
            card.addView(choice("Netcode: " + (rb ? "Rollback" : "Delay-based"),
                    rb ? "Smooth like GGPO: guesses your friend's moves and corrects them. Tap to switch"
                       : "Waits for your friend every frame: steadier but laggier. Tap to switch",
                    v -> { Prefs.put(a, "onlineRollback", !rb); render(); }));
            card.addView(choice("Host a game", "You get a code to give your friend. You are player 1", v -> begin(true)));
            card.addView(choice("Join a game", "Type the code your friend gave you. You are player 2", v -> begin(false)));
            card.addView(Ui.button(a, "Close", Ui.TEXTONLY, v -> d.dismiss()), Ui.wrapMargins(a, 0, 6, 0, 0));
        } else if (screen.equals("code")) {
            renderCode();
        } else {
            renderStatus();
        }
    }

    private void begin(boolean asHost) {
        host = asHost;
        lastError = "";
        myCode = ""; sMyCode = "";
        screen = "code";
        finding = asHost;
        render();
        if (!asHost) return;
        new Thread(() -> {
            String r;
            try { r = Native.netRoomCode(); } catch (UnsatisfiedLinkError | RuntimeException e) { r = ""; }
            final String res = r;
            h.post(() -> {
                finding = false;
                if (res.length() == 0) {
                    lastError = "Could not reach the matchmaking service. Check your internet connection.";
                    screen = "menu";
                } else {
                    myCode = pretty(res);
                    sMyCode = myCode;
                    startOnline(res);
                }
                render();
            });
        }, "net-room").start();
    }

    private void startOnline(String code) {
        try {
            Native.netSetRollback(Prefs.sp(a).getBoolean("onlineRollback", true));
            Native.netOnline(host, code);
        } catch (UnsatisfiedLinkError | RuntimeException e) { Ui.toast(a, "Netplay is not available"); }
    }

    private void renderCode() {
        String st = status()[0];
        boolean busy = st.equals("connecting") || st.equals("ready") || st.equals("sync") || st.equals("listen");
        card.addView(Ui.text(a, host ? "You are player 1 (host)" : "You are player 2", 14, Ui.ACCENT, true));
        if (host) {
            if (finding) {
                card.addView(note("Setting up your room..."));
            } else {
                card.addView(note("Give this code to your friend. They choose Join a game and type it. "
                        + "Keep this screen open: you connect automatically as soon as they do."));
                TextView code = Ui.text(a, myCode, 34, Ui.TEXT, true);
                code.setLetterSpacing(0.1f);
                code.setTextIsSelectable(true);
                code.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 8));
                card.addView(code);
                LinearLayout bar = Ui.horizontal(a);
                bar.addView(Ui.button(a, "Copy", Ui.TONAL, v -> {
                    ((ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("code", myCode));
                    Ui.toast(a, "Copied");
                }));
                bar.addView(Ui.button(a, "Share", Ui.TONAL, v -> {
                    Intent i = new Intent(Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(Intent.EXTRA_TEXT, "Join me in FBNeo (" + game + "): Online multiplayer > Join a game > code " + myCode);
                    a.startActivity(Intent.createChooser(i, "Send the code"));
                }), Ui.wrapMargins(a, 8, 0, 0, 0));
                card.addView(bar);
            }
        } else {
            card.addView(note("Type the code from your friend, then tap Join."));
            friend = new EditText(a);
            friend.setSingleLine(true);
            friend.setHint("XXXX-XXX");
            friend.setTextSize(24);
            friend.setLetterSpacing(0.1f);
            friend.setTextColor(Ui.TEXT);
            friend.setHintTextColor(Ui.SUB);
            friend.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                    | android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
            friend.setBackground(Ui.rounded(a, Ui.SURFACE2, 12));
            friend.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
            card.addView(friend, Ui.fillMargins(a, 0, 4, 0, 4));
            if (busy) { friend.setText(sMyCode); friend.setEnabled(false); }
        }
        statusText = Ui.text(a, "", 14, Ui.ACCENT, true);
        statusText.setPadding(0, Ui.dp(a, 8), 0, 0);
        card.addView(statusText);
        LinearLayout bar2 = Ui.horizontal(a);
        bar2.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar2.addView(Ui.button(a, "Cancel", Ui.TEXTONLY, v -> { stopAll(); screen = "menu"; render(); }));
        if (!host && !busy) bar2.addView(Ui.button(a, "Join", Ui.FILLED, v -> join()), Ui.wrapMargins(a, 8, 0, 0, 0));
        card.addView(bar2, Ui.fillMargins(a, 0, 8, 0, 0));
    }

    private void join() {
        if (friend == null) return;
        String c = friend.getText().toString().replaceAll("[^A-Za-z0-9]", "").toUpperCase(Locale.ROOT);
        if (c.length() != 7) { Ui.toast(a, "The code has 7 characters, like K7M2-QX3"); return; }
        sMyCode = pretty(c);
        startOnline(c);
        friend.setEnabled(false);
        render();
    }

    private void renderStatus() {
        String[] st = status();
        card.addView(note("You are player " + (st[1].equals("1") ? "1 (host)" : "2") + ". Input delay " + st[2]
                + " frames. Both phones must keep the game open. Quitting the game on one phone ends the session."));
        statusText = Ui.text(a, "", 14, Ui.OK, true);
        card.addView(statusText);
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        bar.addView(Ui.button(a, "Close", Ui.TEXTONLY, v -> d.dismiss()));
        TextView stop = Ui.button(a, "Disconnect", Ui.TONAL, v -> { stopAll(); screen = "menu"; render(); });
        stop.setTextColor(Ui.DANGER);
        bar.addView(stop, Ui.wrapMargins(a, 8, 0, 0, 0));
        card.addView(bar, Ui.fillMargins(a, 0, 8, 0, 0));
    }

    private void stopAll() {
        try { Native.netStop(); } catch (UnsatisfiedLinkError | RuntimeException e) { /* ignore */ }
    }

    private void tick() {
        String[] st = status();
        String state = st[0];
        String msg = st.length > 4 ? st[4] : "";
        if (state.equals("run") && !screen.equals("status")) { screen = "status"; render(); return; }
        if (state.equals("error")) {
            lastError = msg;
            stopAll();
            screen = "menu";
            render();
            return;
        }
        if (statusText != null) {
            String s;
            switch (state) {
                case "connecting": s = msg; break;
                case "listen": s = msg; break;
                case "ready":
                case "sync": s = "Syncing the two games..."; break;
                case "run": s = (st[3].equals("1") ? "Out of sync: " : "Connected. ") + msg; break;
                default: s = finding ? "" : "";
            }
            statusText.setText(s);
        }
    }
}
