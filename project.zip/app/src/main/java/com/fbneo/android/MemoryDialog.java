package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** RAM search, RAM watch list and hex editor. Open it while the game is paused. */
final class MemoryDialog {
    private MemoryDialog() {}

    static final class Watch {
        String name;
        long addr;
        int size;
        boolean signed;
    }

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("tas_watch", Context.MODE_PRIVATE);
    }

    static List<Watch> loadWatches(Context c, String game) {
        List<Watch> out = new ArrayList<>();
        String s = sp(c).getString("w_" + game, "");
        for (String line : s.split("\n")) {
            String[] p = line.split("\t");
            if (p.length < 4) continue;
            try {
                Watch w = new Watch();
                w.addr = Long.parseLong(p[0], 16);
                w.size = Integer.parseInt(p[1]);
                w.signed = "1".equals(p[2]);
                w.name = p[3];
                out.add(w);
            } catch (NumberFormatException e) { /* skip */ }
        }
        return out;
    }

    static void saveWatches(Context c, String game, List<Watch> l) {
        StringBuilder b = new StringBuilder();
        for (Watch w : l) {
            b.append(Long.toHexString(w.addr)).append('\t').append(w.size).append('\t')
                    .append(w.signed ? "1" : "0").append('\t').append(w.name.replace('\t', ' ').replace('\n', ' ')).append('\n');
        }
        sp(c).edit().putString("w_" + game, b.toString()).apply();
    }

    static String format(long v, int size, boolean signed) {
        if (signed) {
            int bits = size * 8;
            if (bits < 64 && (v & (1L << (bits - 1))) != 0) v -= (1L << bits);
        } else if (size == 4) {
            v &= 0xFFFFFFFFL;
        }
        return Long.toString(v);
    }

    private static String hex(long v, int size) {
        return String.format("%0" + (size * 2) + "X", size == 4 ? v & 0xFFFFFFFFL : v & ((1L << (size * 8)) - 1));
    }

    private static long parseHex(String s, long def) {
        try { return Long.parseLong(s.trim().replace("0x", "").replace("0X", ""), 16); } catch (RuntimeException e) { return def; }
    }

    private static long parseNum(String s, long def) {
        try {
            s = s.trim();
            if (s.startsWith("0x") || s.startsWith("0X")) return Long.parseLong(s.substring(2), 16);
            return Long.parseLong(s);
        } catch (RuntimeException e) { return def; }
    }

    private static EditText field(Activity a, String hint, String text, boolean number) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setText(text);
        e.setSingleLine(true);
        e.setTextColor(Ui.TEXT);
        e.setHintTextColor(Ui.SUB);
        e.setTextSize(14);
        e.setTypeface(Typeface.MONOSPACE);
        if (number) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        return e;
    }

    private static LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
    }

    private static TextView mono(Activity a, String s, int color) {
        TextView t = Ui.text(a, s, 12, color, false);
        t.setTypeface(Typeface.MONOSPACE);
        return t;
    }

    static void show(final Activity a, final String game) {
        final LinearLayout[] h = new LinearLayout[1];
        final Dialog d = Dialogs.base(a, h);
        final LinearLayout card = h[0];
        card.addView(Ui.text(a, Lang.t("Memory"), 20, Ui.TEXT, true));
        TextView hint = Ui.text(a, Lang.t("The game is stopped while this window is open. Close it and play to change values, then search again."), 12, Ui.SUB, false);
        hint.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 6));
        card.addView(hint);
        LinearLayout tabs = Ui.horizontal(a);
        final LinearLayout body = Ui.vertical(a);
        final Runnable[] tabs3 = new Runnable[3];
        String[] names = {Lang.t("Search"), Lang.t("Watch"), Lang.t("Hex")};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            tabs.addView(Ui.button(a, names[i], Ui.TONAL, v -> { body.removeAllViews(); tabs3[idx].run(); }), weight());
        }
        card.addView(tabs);
        card.addView(body);
        final State st = new State();
        tabs3[0] = () -> searchTab(a, body, st);
        tabs3[1] = () -> watchTab(a, game, body, st);
        tabs3[2] = () -> hexTab(a, body, st);
        tabs3[0].run();
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END);
        bar.setPadding(0, Ui.dp(a, 10), 0, 0);
        bar.addView(Ui.button(a, Lang.t("Close"), Ui.TEXTONLY, v -> d.dismiss()));
        card.addView(bar);
        st.game = game;
        st.tabs = tabs3;
        st.body = body;
        d.show();
    }

    private static final class State {
        String game;
        Runnable[] tabs;
        LinearLayout body;
        String start = "FF0000", end = "FFFFFF";
        int size = 1;
        boolean signed;
        long hexAddr = 0xFF0000L;
        String msg = "";
    }

    private static void searchTab(final Activity a, final LinearLayout body, final State st) {
        LinearLayout r1 = Ui.horizontal(a);
        final EditText s = field(a, Lang.t("Start (hex)"), st.start, true);
        final EditText e = field(a, Lang.t("End (hex)"), st.end, true);
        r1.addView(s, weight());
        r1.addView(e, weight());
        body.addView(r1);
        LinearLayout r2 = Ui.horizontal(a);
        final TextView sizeB = Ui.button(a, "", Ui.TONAL, null);
        final TextView signB = Ui.button(a, "", Ui.TONAL, null);
        final Runnable upd = () -> {
            sizeB.setText(Lang.t("Size") + " " + st.size);
            signB.setText(st.signed ? Lang.t("Signed") : Lang.t("Unsigned"));
        };
        upd.run();
        sizeB.setOnClickListener(v -> { st.size = st.size == 1 ? 2 : st.size == 2 ? 4 : 1; upd.run(); });
        signB.setOnClickListener(v -> { st.signed = !st.signed; upd.run(); });
        r2.addView(sizeB, weight());
        r2.addView(signB, weight());
        body.addView(r2);
        final LinearLayout results = Ui.vertical(a);
        final TextView status = Ui.text(a, st.msg, 12, Ui.SUB, false);
        final Runnable[] refresh = new Runnable[1];
        body.addView(Ui.button(a, Lang.t("New search"), Ui.FILLED, v -> {
            st.start = s.getText().toString();
            st.end = e.getText().toString();
            int n = Native.tasSearchStart(parseHex(st.start, 0xFF0000L), parseHex(st.end, 0xFFFFFFL), st.size, st.signed);
            String err = Native.tasSearchError();
            st.msg = (err != null && err.length() > 0) ? err : (n + " " + Lang.t("addresses"));
            refresh[0].run();
        }));
        final EditText val = field(a, Lang.t("Value"), "", true);
        String[] ops = {"=", "≠", ">", "<", Lang.t("changed"), Lang.t("same"), Lang.t("up"), Lang.t("down"), "Δ ="};
        LinearLayout grid = Ui.vertical(a);
        LinearLayout row = null;
        for (int i = 0; i < ops.length; i++) {
            if (i % 3 == 0) { row = Ui.horizontal(a); grid.addView(row); }
            final int op = i;
            row.addView(Ui.button(a, ops[i], Ui.TONAL, v -> {
                long x = parseNum(val.getText().toString(), 0);
                int n = Native.tasSearchFilter(op, x);
                String err = Native.tasSearchError();
                st.msg = (err != null && err.length() > 0) ? err : (n + " " + Lang.t("addresses"));
                refresh[0].run();
            }), weight());
        }
        TextView lbl = Ui.text(a, Lang.t("Then filter"), 12, Ui.SUB, false);
        lbl.setPadding(0, Ui.dp(a, 8), 0, 0);
        body.addView(lbl);
        body.addView(val);
        body.addView(grid);
        body.addView(status);
        body.addView(results);
        refresh[0] = () -> {
            status.setText(st.msg);
            results.removeAllViews();
            String[] rs = null;
            try { rs = Native.tasSearchResults(40); } catch (RuntimeException ex) { /* none */ }
            if (rs == null) return;
            for (String line : rs) {
                final String[] p = line.split("\\|");
                if (p.length < 4) continue;
                final int sz = Integer.parseInt(p[3]);
                final long addr = parseHex(p[0], 0);
                LinearLayout r = Ui.horizontal(a);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.addView(mono(a, p[0] + "  " + format(Long.parseLong(p[1]), sz, st.signed) + "  (" + format(Long.parseLong(p[2]), sz, st.signed) + ")", Ui.TEXT), weight());
                r.addView(Ui.button(a, Lang.t("Watch"), Ui.TEXTONLY, v -> {
                    List<Watch> l = loadWatches(a, st.game);
                    Watch w = new Watch();
                    w.addr = addr;
                    w.size = sz;
                    w.signed = st.signed;
                    w.name = Long.toHexString(addr).toUpperCase();
                    l.add(w);
                    saveWatches(a, st.game, l);
                    Ui.toast(a, Lang.t("Added to watch list"));
                }));
                r.addView(Ui.button(a, Lang.t("Hex"), Ui.TEXTONLY, v -> {
                    st.hexAddr = addr & ~0xFL;
                    body.removeAllViews();
                    st.tabs[2].run();
                }));
                results.addView(r);
            }
        };
        refresh[0].run();
    }

    private static void watchTab(final Activity a, final String game, final LinearLayout body, final State st) {
        final List<Watch> l = loadWatches(a, game);
        if (l.isEmpty()) body.addView(Ui.text(a, Lang.t("No watches yet. Add one from the search results or below."), 13, Ui.SUB, false));
        for (int i = 0; i < l.size(); i++) {
            final int idx = i;
            final Watch w = l.get(i);
            long v = 0;
            try { v = Native.tasMemRead(w.addr, w.size); } catch (RuntimeException ex) { /* none */ }
            LinearLayout r = Ui.horizontal(a);
            r.setGravity(Gravity.CENTER_VERTICAL);
            r.addView(mono(a, w.name + "  " + Long.toHexString(w.addr).toUpperCase() + "  = " + format(v, w.size, w.signed) + " (0x" + hex(v, w.size) + ")", Ui.TEXT), weight());
            r.addView(Ui.button(a, Lang.t("Remove"), Ui.TEXTONLY, vv -> {
                l.remove(idx);
                saveWatches(a, game, l);
                body.removeAllViews();
                watchTab(a, game, body, st);
            }));
            body.addView(r);
        }
        TextView lbl = Ui.text(a, Lang.t("Add address"), 12, Ui.SUB, false);
        lbl.setPadding(0, Ui.dp(a, 10), 0, 0);
        body.addView(lbl);
        LinearLayout r = Ui.horizontal(a);
        final EditText addr = field(a, Lang.t("Address (hex)"), "", true);
        final EditText name = field(a, Lang.t("Name"), "", false);
        r.addView(addr, weight());
        r.addView(name, weight());
        body.addView(r);
        body.addView(Ui.button(a, Lang.t("Add") + " (" + st.size + (st.signed ? "s" : "u") + ")", Ui.TONAL, v -> {
            Watch w = new Watch();
            w.addr = parseHex(addr.getText().toString(), -1);
            if (w.addr < 0) return;
            w.size = st.size;
            w.signed = st.signed;
            String n = name.getText().toString().trim();
            w.name = n.length() > 0 ? n : Long.toHexString(w.addr).toUpperCase();
            l.add(w);
            saveWatches(a, game, l);
            body.removeAllViews();
            watchTab(a, game, body, st);
        }));
        TextView note = Ui.text(a, Lang.t("Watches show on the TAS bar (first 5). Size and sign follow the Search tab."), 12, Ui.SUB, false);
        note.setPadding(0, Ui.dp(a, 6), 0, 0);
        body.addView(note);
    }

    private static void hexTab(final Activity a, final LinearLayout body, final State st) {
        LinearLayout r = Ui.horizontal(a);
        final EditText addr = field(a, Lang.t("Address (hex)"), Long.toHexString(st.hexAddr).toUpperCase(), true);
        r.addView(addr, weight());
        r.addView(Ui.button(a, Lang.t("Go"), Ui.TONAL, v -> { st.hexAddr = parseHex(addr.getText().toString(), st.hexAddr); body.removeAllViews(); hexTab(a, body, st); }));
        body.addView(r);
        LinearLayout nav = Ui.horizontal(a);
        nav.addView(Ui.button(a, "−256", Ui.TONAL, v -> { st.hexAddr = Math.max(0, st.hexAddr - 256); body.removeAllViews(); hexTab(a, body, st); }), weight());
        nav.addView(Ui.button(a, "+256", Ui.TONAL, v -> { st.hexAddr += 256; body.removeAllViews(); hexTab(a, body, st); }), weight());
        body.addView(nav);
        byte[] b = null;
        try { b = Native.tasMemBytes(st.hexAddr, 256); } catch (RuntimeException ex) { /* none */ }
        StringBuilder sb = new StringBuilder();
        if (b == null) {
            sb.append(Lang.t("This game has no readable memory."));
        } else {
            for (int i = 0; i < b.length; i += 16) {
                sb.append(String.format("%06X ", (st.hexAddr + i) & 0xFFFFFF));
                for (int j = 0; j < 16 && i + j < b.length; j++) sb.append(String.format("%02X ", b[i + j] & 0xFF));
                sb.append('\n');
            }
        }
        TextView t = mono(a, sb.toString(), Ui.TEXT);
        t.setTextSize(11);
        t.setPadding(0, Ui.dp(a, 8), 0, Ui.dp(a, 8));
        ScrollView sv = new Dialogs.MaxHeightScroll(a, (int) (Dialogs.screenHeight(a) * 0.3f));
        sv.addView(t);
        body.addView(sv);
        TextView lbl = Ui.text(a, Lang.t("Write value (decimal or 0x…) to the address above"), 12, Ui.SUB, false);
        body.addView(lbl);
        LinearLayout w = Ui.horizontal(a);
        final EditText val = field(a, Lang.t("Value"), "", true);
        w.addView(val, weight());
        w.addView(Ui.button(a, Lang.t("Write"), Ui.FILLED, v -> {
            long x = parseNum(val.getText().toString(), Long.MIN_VALUE);
            if (x == Long.MIN_VALUE) return;
            long ad = parseHex(addr.getText().toString(), st.hexAddr);
            boolean ok = false;
            try { ok = Native.tasMemWrite(ad, x, st.size); } catch (RuntimeException ex) { /* none */ }
            Ui.toast(a, ok ? Lang.t("Written") : Lang.t("Write failed"));
            body.removeAllViews();
            hexTab(a, body, st);
        }));
        body.addView(w);
        body.addView(Ui.text(a, Lang.t("Size"), 12, Ui.SUB, false));
        body.addView(Ui.button(a, Lang.t("Size") + " " + st.size, Ui.TONAL, v -> { st.size = st.size == 1 ? 2 : st.size == 2 ? 4 : 1; body.removeAllViews(); hexTab(a, body, st); }));
    }
}
