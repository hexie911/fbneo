package com.fbneo.android;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.SparseIntArray;
import android.view.MotionEvent;
import android.view.View;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * On-screen controls drawn over the game: a stick, buttons and macros (several buttons at once).
 * Every element can be moved, resized, added and deleted in edit mode. Touches go to player 1's pad.
 */
final class TouchPadView extends View {
    static final int STICK = 0, BUTTON = 1, MACRO = 2;

    static final class El {
        int type;
        String label = "";
        int[] actions = new int[0];
        float x, y;      // centre, as a fraction of the screen
        float size;      // diameter in dp
        float alpha = -1; // 0.1..1, -1 = the global opacity
        boolean pressed;

        JSONObject toJson() throws Exception {
            JSONObject o = new JSONObject();
            o.put("t", type).put("l", label).put("x", x).put("y", y).put("s", size).put("o", alpha);
            JSONArray a = new JSONArray();
            for (int v : actions) a.put(v);
            o.put("a", a);
            return o;
        }

        static El fromJson(JSONObject o) throws Exception {
            El e = new El();
            e.type = o.getInt("t");
            e.label = o.optString("l", "");
            e.x = (float) o.getDouble("x");
            e.y = (float) o.getDouble("y");
            e.size = (float) o.getDouble("s");
            e.alpha = (float) o.optDouble("o", -1);
            JSONArray a = o.optJSONArray("a");
            e.actions = new int[a == null ? 0 : a.length()];
            for (int i = 0; i < e.actions.length; i++) e.actions[i] = a.getInt(i);
            return e;
        }
    }

    interface Host {
        void openMenu();
        void editChanged(El selected);
    }

    private final List<El> els = new ArrayList<>();
    private final Host host;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint txt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private boolean edit;
    private El selected;
    private float dragDX, dragDY;
    private int dragPointer = -1;
    private float alpha = 0.55f;

    // runtime
    private final SparseIntArray stickOwner = new SparseIntArray(); // pointerId -> 1 while it holds the stick
    private int stickPointer = -1;
    private float stickDX, stickDY;
    private final boolean[] sent = new boolean[Actions.COUNT];
    private final int[] want = new int[Actions.COUNT];

    TouchPadView(Context c, Host host) {
        super(c);
        this.host = host;
        dp = c.getResources().getDisplayMetrics().density;
        txt.setTextAlign(Paint.Align.CENTER);
        txt.setFakeBoldText(true);
        line.setStyle(Paint.Style.STROKE);
        load();
        setAlphaLevel(Prefs.touchAlpha(c));
    }

    void setAlphaLevel(int percent) { alpha = Math.max(0.15f, Math.min(1f, percent / 100f)); invalidate(); }

    // ---- layout storage ----------------------------------------------------------------

    private static El btn(String label, int action, float x, float y, float size) {
        El e = new El();
        e.type = BUTTON; e.label = label; e.actions = new int[]{action}; e.x = x; e.y = y; e.size = size;
        return e;
    }

    static List<El> defaults() {
        List<El> l = new ArrayList<>();
        El s = new El();
        s.type = STICK; s.x = 0.14f; s.y = 0.70f; s.size = 150; s.label = "";
        l.add(s);
        float bx = 0.70f, dx = 0.095f, y1 = 0.60f, y2 = 0.80f, sz = 66;
        l.add(btn("LP", Actions.FIRE1, bx, y1, sz));
        l.add(btn("MP", Actions.FIRE2, bx + dx, y1 - 0.03f, sz));
        l.add(btn("HP", Actions.FIRE3, bx + 2 * dx, y1, sz));
        l.add(btn("LK", Actions.FIRE4, bx, y2, sz));
        l.add(btn("MK", Actions.FIRE5, bx + dx, y2 - 0.03f, sz));
        l.add(btn("HK", Actions.FIRE6, bx + 2 * dx, y2, sz));
        l.add(btn("Coin", Actions.COIN, 0.40f, 0.90f, 46));
        l.add(btn("Start", Actions.START, 0.50f, 0.90f, 46));
        l.add(btn("P1/P2", Actions.SWAP, 0.60f, 0.90f, 46));
        l.add(btn("Menu", Actions.MENU, 0.50f, 0.07f, 40));
        return l;
    }

    private void load() {
        els.clear();
        try {
            String s = Prefs.sp(getContext()).getString("touchLayout", "");
            if (s.length() > 0) {
                JSONArray a = new JSONArray(s);
                for (int i = 0; i < a.length(); i++) els.add(El.fromJson(a.getJSONObject(i)));
            }
        } catch (Exception e) {
            els.clear();
        }
        if (els.isEmpty()) els.addAll(defaults());
    }

    void save() {
        try {
            JSONArray a = new JSONArray();
            for (El e : els) a.put(e.toJson());
            Prefs.put(getContext(), "touchLayout", a.toString());
        } catch (Exception e) {
            // keep the old layout
        }
    }

    void resetLayout() {
        els.clear();
        els.addAll(defaults());
        selected = null;
        save();
        host.editChanged(null);
        invalidate();
    }

    void add(El e) {
        e.x = 0.5f;
        e.y = 0.5f;
        els.add(e);
        selected = e;
        save();
        host.editChanged(e);
        invalidate();
    }

    void deleteSelected() {
        if (selected == null) return;
        els.remove(selected);
        selected = null;
        save();
        host.editChanged(null);
        invalidate();
    }

    void setSelectedSize(float dpSize) {
        if (selected == null) return;
        selected.size = Math.max(32, Math.min(260, dpSize));
        invalidate();
    }

    void setSelectedAlpha(float a) {
        if (selected == null) return;
        selected.alpha = Math.max(0.1f, Math.min(1f, a));
        invalidate();
    }

    float globalAlpha() { return alpha; }

    El selected() { return selected; }

    void setEdit(boolean on) {
        edit = on;
        selected = null;
        releaseAllTouch();
        host.editChanged(null);
        invalidate();
    }

    boolean isEdit() { return edit; }

    // ---- sending -----------------------------------------------------------------------

    private void setTouch(int action, boolean down) {
        if (action < 0 || action >= Actions.COUNT || sent[action] == down) return;
        sent[action] = down;
        if (action == Actions.MENU) {
            if (down) host.openMenu();
            return;
        }
        try {
            Native.setTouch(action, down);
        } catch (UnsatisfiedLinkError | RuntimeException e) {
            // native library not ready yet
        }
    }

    void releaseAllTouch() {
        for (int i = 0; i < sent.length; i++) setTouch(i, false);
        for (El e : els) e.pressed = false;
        stickPointer = -1;
        stickDX = stickDY = 0;
        invalidate();
    }

    // ---- touch -------------------------------------------------------------------------

    private float cx(El e) { return e.x * getWidth(); }
    private float cy(El e) { return e.y * getHeight(); }

    private El hit(float x, float y, boolean forStick) {
        El best = null;
        float bestD = Float.MAX_VALUE;
        for (El e : els) {
            if (forStick && e.type != STICK) continue;
            float r = e.size * dp / 2f * (e.type == STICK ? 1.25f : 1.1f);
            float d = (float) Math.hypot(x - cx(e), y - cy(e));
            if (d <= r && d < bestD) { best = e; bestD = d; }
        }
        return best;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        if (edit) return editTouch(ev);
        int act = ev.getActionMasked();
        if (act == MotionEvent.ACTION_CANCEL) { releaseAllTouch(); return true; }

        // which pointer holds the stick
        int idx = ev.getActionIndex();
        if (act == MotionEvent.ACTION_DOWN || act == MotionEvent.ACTION_POINTER_DOWN) {
            if (stickPointer < 0) {
                El s = hit(ev.getX(idx), ev.getY(idx), true);
                if (s != null) stickPointer = ev.getPointerId(idx);
            }
        }
        boolean up = act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_POINTER_UP;
        int upId = up ? ev.getPointerId(idx) : -1;
        if (up && upId == stickPointer) stickPointer = -1;

        java.util.Arrays.fill(want, 0);
        for (El e : els) e.pressed = false;
        stickDX = stickDY = 0;
        for (int i = 0; i < ev.getPointerCount(); i++) {
            int id = ev.getPointerId(i);
            if (up && id == upId) continue;
            float x = ev.getX(i), y = ev.getY(i);
            if (id == stickPointer) {
                for (El e : els) {
                    if (e.type != STICK) continue;
                    float dx = x - cx(e), dy = y - cy(e);
                    float r = e.size * dp / 2f;
                    float len = (float) Math.hypot(dx, dy);
                    float lim = r * 0.9f;
                    if (len > lim) { dx *= lim / len; dy *= lim / len; }
                    stickDX = dx; stickDY = dy;
                    e.pressed = true;
                    if (len > r * 0.28f) {
                        double ang = Math.toDegrees(Math.atan2(-dy, dx)); // 0 = right, 90 = up
                        if (ang < 0) ang += 360;
                        // 8 sectors; diagonals a little wider than the straight directions help special moves
                        if (ang >= 337.5 || ang < 22.5) want[Actions.RIGHT] = 1;
                        if (ang >= 22.5 && ang < 67.5) { want[Actions.RIGHT] = 1; want[Actions.UP] = 1; }
                        if (ang >= 67.5 && ang < 112.5) want[Actions.UP] = 1;
                        if (ang >= 112.5 && ang < 157.5) { want[Actions.UP] = 1; want[Actions.LEFT] = 1; }
                        if (ang >= 157.5 && ang < 202.5) want[Actions.LEFT] = 1;
                        if (ang >= 202.5 && ang < 247.5) { want[Actions.LEFT] = 1; want[Actions.DOWN] = 1; }
                        if (ang >= 247.5 && ang < 292.5) want[Actions.DOWN] = 1;
                        if (ang >= 292.5 && ang < 337.5) { want[Actions.DOWN] = 1; want[Actions.RIGHT] = 1; }
                    }
                    break;
                }
            } else {
                El e = hit(x, y, false);
                if (e != null && e.type != STICK) {
                    e.pressed = true;
                    for (int a : e.actions) if (a >= 0 && a < want.length) want[a] = 1;
                }
            }
        }
        for (int a = 0; a < want.length; a++) setTouch(a, want[a] != 0);
        invalidate();
        return true;
    }

    private boolean editTouch(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                El e = hit(ev.getX(), ev.getY(), false);
                selected = e;
                if (e != null) {
                    dragPointer = ev.getPointerId(0);
                    dragDX = ev.getX() - cx(e);
                    dragDY = ev.getY() - cy(e);
                }
                host.editChanged(e);
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (selected != null && dragPointer >= 0) {
                    int i = ev.findPointerIndex(dragPointer);
                    if (i >= 0 && getWidth() > 0 && getHeight() > 0) {
                        selected.x = Math.max(0.02f, Math.min(0.98f, (ev.getX(i) - dragDX) / getWidth()));
                        selected.y = Math.max(0.03f, Math.min(0.97f, (ev.getY(i) - dragDY) / getHeight()));
                        invalidate();
                    }
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (selected != null) save();
                dragPointer = -1;
                return true;
            default:
                return true;
        }
    }

    // ---- drawing -----------------------------------------------------------------------

    @Override
    protected void onDraw(Canvas c) {
        for (El e : els) {
            float x = cx(e), y = cy(e), r = e.size * dp / 2f;
            boolean sel = edit && e == selected;
            int a = (int) (255 * (e.alpha > 0 ? e.alpha : alpha));
            if (e.type == STICK) {
                fill.setColor(0x1B2128 | (int) (a * 0.7f) << 24);
                c.drawCircle(x, y, r, fill);
                line.setStrokeWidth(2 * dp);
                line.setColor(0xFFFFFF | (int) (a * 0.8f) << 24);
                c.drawCircle(x, y, r, line);
                float kx = x + (e.pressed ? stickDX : 0), ky = y + (e.pressed ? stickDY : 0);
                fill.setColor(0x8BB4FF | (Math.min(255, a + (e.pressed ? 70 : 0))) << 24);
                c.drawCircle(kx, ky, r * 0.42f, fill);
            } else {
                int base = e.type == MACRO ? 0xFFC266 : 0x8BB4FF;
                int alp = Math.min(255, e.pressed ? a + 90 : a);
                fill.setColor((e.pressed ? 0xFFFFFF : base) & 0xFFFFFF | alp << 24);
                c.drawCircle(x, y, r, fill);
                line.setStrokeWidth(2 * dp);
                line.setColor(0x0E1014 | (int) (a * 0.9f) << 24);
                c.drawCircle(x, y, r, line);
                txt.setColor(0xFF0A1730);
                txt.setTextSize(Math.max(10 * dp, r * (e.label.length() > 3 ? 0.42f : 0.58f)));
                c.drawText(e.label, x, y + txt.getTextSize() * 0.35f, txt);
            }
            if (sel) {
                line.setColor(0xFFFFFFFF);
                line.setStrokeWidth(3 * dp);
                c.drawRoundRect(new RectF(x - r - 6 * dp, y - r - 6 * dp, x + r + 6 * dp, y + r + 6 * dp), 14 * dp, 14 * dp, line);
            }
        }
        if (edit) {
            txt.setColor(0xCCFFFFFF);
            txt.setTextSize(13 * dp);
            c.drawText("Drag to move. Tap a control to select it, then resize or delete.", getWidth() / 2f, getHeight() - 10 * dp, txt);
        }
    }
}
