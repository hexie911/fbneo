package com.fbneo.android;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Looks at a Lua script before it is started and can download the well known training script package. */
final class LuaTools {
    private LuaTools() {}

    static final String TRAINING_URL = "https://github.com/Grouflon/3rd_training_lua/archive/HEAD.zip";
    static final String TRAINING_FOLDER = "3rd_training_lua";
    static final String TRAINING_SCRIPT = "3rd_training.lua";

    /** Crystal Cube 99's 3rd Strike combo trials. The picture/sound package is a big zip on Google Drive;
     *  the script itself is part of the app. */
    static final String TRIAL_URL = "https://drive.usercontent.google.com/download?id=1qiyleCPH6L8bUzP7j5oFZMRwKHD1kbRk&export=download&confirm=t";
    static final String TRIAL_FOLDER = "crystal_cube99_trial";
    static final String TRIAL_SCRIPT = "sf3_3rd_trial_20220613.lua";

    static final class Report {
        /** Files or folders the script needs that are not next to it. */
        final List<String> missing = new ArrayList<>();
        /** Friendly hints that are not blocking. */
        final List<String> notes = new ArrayList<>();
        /** ROM sets the script ships data for (data/<set>/ folders); empty = no restriction known. */
        final List<String> sets = new ArrayList<>();

        boolean ok() { return missing.isEmpty(); }
    }

    private static final Pattern REQUIRE = Pattern.compile("\\brequire\\s*\\(?\\s*[\"']([^\"']+)[\"']");
    private static final Pattern DOFILE = Pattern.compile("\\b(?:dofile|loadfile)\\s*\\(?\\s*[\"']([^\"']+)[\"']");
    private static final Pattern DIRREF = Pattern.compile("[\"']((?:images|data|assets|resources)/)[^\"']*[\"']");
    private static final List<String> BUILTIN = Arrays.asList("string", "table", "math", "io", "os", "debug", "package",
            "coroutine", "bit", "gd", "lfs", "socket", "winapi", "lpeg", "ffi", "jit", "emu", "gui", "memory", "joypad");

    static String readText(File f, int max) {
        try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && bo.size() < max) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } catch (IOException e) {
            return "";
        }
    }

    static Report check(File script, String rom) {
        Report r = new Report();
        File dir = script.getParentFile();
        if (dir == null) return r;
        String src = readText(script, 600 * 1024);

        Matcher m = REQUIRE.matcher(src);
        while (m.find()) {
            String name = m.group(1);
            if (BUILTIN.contains(name)) continue;
            String asPath = name.replace('.', '/');
            boolean found = false;
            for (String cand : new String[]{name + ".lua", asPath + ".lua", name + "/init.lua", asPath + "/init.lua"}) {
                if (new File(dir, cand).isFile()) { found = true; break; }
            }
            if (!found) {
                String shown = name.contains("/") ? name : asPath;
                if (!r.missing.contains(shown + ".lua")) r.missing.add(shown + ".lua");
            }
        }
        m = DOFILE.matcher(src);
        while (m.find()) {
            String p = m.group(1);
            if (p.startsWith("/")) continue;
            if (!new File(dir, p).isFile() && !r.missing.contains(p)) r.missing.add(p);
        }
        m = DIRREF.matcher(src);
        while (m.find()) {
            String d = m.group(1);
            if (!new File(dir, d).isDirectory() && !r.missing.contains(d)) r.missing.add(d);
        }

        // data/<rom set>/ folders: scripts that ship per game data only work with those sets
        File data = new File(dir, "data");
        File[] sub = data.listFiles();
        if (sub != null && rom != null) {
            List<String> sets = new ArrayList<>();
            boolean match = false;
            for (File f : sub) {
                if (!f.isDirectory()) continue;
                sets.add(f.getName());
                if (f.getName().equals(rom)) match = true;
            }
            r.sets.addAll(sets);
            if (!sets.isEmpty() && !match) {
                java.util.Collections.sort(sets);
                StringBuilder sb = new StringBuilder();
                for (String s : sets) { if (sb.length() > 0) sb.append(", "); sb.append(s); }
                r.notes.add("This script is made for: " + sb + ". " + rom + " may run with limited features.");
            }
        }
        return r;
    }

    /** The script needs somewhere to save recordings and settings. */
    static void prepareFolders(File script) {
        File dir = script.getParentFile();
        if (dir == null) return;
        String src = readText(script, 600 * 1024);
        if (src.contains("saved/")) {
            new File(dir, "saved/recordings").mkdirs();
        }
    }

    static String describeMissing(Report r) {
        StringBuilder sb = new StringBuilder("Missing next to the script: ");
        for (int i = 0; i < r.missing.size() && i < 3; i++) {
            if (i > 0) sb.append(", ");
            sb.append(r.missing.get(i));
        }
        if (r.missing.size() > 3) sb.append(" …");
        return sb.toString();
    }

    // ---- download ----------------------------------------------------------------------

    interface Progress { void onProgress(String what); }

    /** Downloads the package into <luaDir>/3rd_training_lua and returns the script file. Blocking. */
    static File installTraining(String luaDir, Progress progress) throws IOException {
        File dest = new File(luaDir, TRAINING_FOLDER);
        if (!dest.isDirectory() && !dest.mkdirs()) throw new IOException("Cannot create " + dest);
        if (progress != null) progress.onProgress("Downloading…");
        HttpURLConnection con = (HttpURLConnection) new URL(TRAINING_URL).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(60000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "FBNeo-Android");
        int code = con.getResponseCode();
        if (code != 200) throw new IOException("Download failed (HTTP " + code + ")");
        try (InputStream in = con.getInputStream()) {
            extractZip(in, dest, progress);
        } finally {
            con.disconnect();
        }
        File script = new File(dest, TRAINING_SCRIPT);
        if (!script.isFile()) throw new IOException("The download did not contain " + TRAINING_SCRIPT);
        new File(dest, "saved/recordings").mkdirs();
        return script;
    }


    // ---- Crystal Cube 99 trials ---------------------------------------------------------

    private static final Pattern FORM_ACTION = Pattern.compile("<form[^>]*action=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
    private static final Pattern HIDDEN = Pattern.compile("<input[^>]*type=\"hidden\"[^>]*name=\"([^\"]+)\"[^>]*value=\"([^\"]*)\"", Pattern.CASE_INSENSITIVE);

    private static String decodeHtml(String v) {
        return v.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'");
    }

    private static HttpURLConnection open(String url) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(20000);
        con.setReadTimeout(60000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) FBNeo-Android");
        return con;
    }

    /** Downloads the zip to a file. Google Drive may answer big files with a "can't scan for viruses" page first. */
    private static void downloadTo(String url, File out, Progress progress) throws IOException {
        java.net.CookieHandler old = java.net.CookieHandler.getDefault();
        java.net.CookieHandler.setDefault(new java.net.CookieManager());
        try {
            String cur = url;
            for (int attempt = 0; attempt < 3; attempt++) {
                HttpURLConnection con = open(cur);
                int code = con.getResponseCode();
                if (code != 200) { con.disconnect(); throw new IOException("Download failed (HTTP " + code + ")"); }
                String type = con.getContentType() == null ? "" : con.getContentType().toLowerCase(java.util.Locale.ROOT);
                if (type.startsWith("text/html")) {
                    String html = "";
                    try (InputStream in = con.getInputStream()) {
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        byte[] b = new byte[8192];
                        int n;
                        while ((n = in.read(b)) > 0 && bo.size() < 400000) bo.write(b, 0, n);
                        html = bo.toString("UTF-8");
                    } finally {
                        con.disconnect();
                    }
                    Matcher fm = FORM_ACTION.matcher(html);
                    if (!fm.find()) throw new IOException("Google Drive did not give the file (is the link still shared?)");
                    StringBuilder q = new StringBuilder(decodeHtml(fm.group(1)));
                    q.append(q.indexOf("?") >= 0 ? "&" : "?");
                    Matcher hm = HIDDEN.matcher(html);
                    boolean first = true;
                    while (hm.find()) {
                        if (!first) q.append('&');
                        first = false;
                        q.append(java.net.URLEncoder.encode(decodeHtml(hm.group(1)), "UTF-8")).append('=')
                                .append(java.net.URLEncoder.encode(decodeHtml(hm.group(2)), "UTF-8"));
                    }
                    cur = q.toString();
                    continue;
                }
                long total = con.getContentLengthLong();
                try (InputStream in = new BufferedInputStream(con.getInputStream(), 65536);
                     OutputStream os = new FileOutputStream(out)) {
                    byte[] buf = new byte[65536];
                    long done = 0, lastReport = 0;
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        os.write(buf, 0, n);
                        done += n;
                        if (progress != null && done - lastReport >= (2L << 20)) {
                            lastReport = done;
                            progress.onProgress("Downloading… " + (done >> 20) + (total > 0 ? " of " + (total >> 20) : "") + " MB");
                        }
                    }
                } finally {
                    con.disconnect();
                }
                return;
            }
            throw new IOException("Google Drive kept asking for confirmation");
        } finally {
            java.net.CookieHandler.setDefault(old);
        }
    }

    /** Unzips into dest. A single top level folder is dropped; the user's own save files are kept. */
    private static void unzipFile(File zip, File dest, Progress progress) throws IOException {
        String destPath = dest.getCanonicalPath() + File.separator;
        String top = null;
        boolean single = true;
        try (java.util.zip.ZipFile zf = new java.util.zip.ZipFile(zip)) {
            java.util.Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName().replace('\\', '/');
                int sl = n.indexOf('/');
                if (sl < 0) { single = false; break; }
                String t = n.substring(0, sl);
                if (top == null) top = t; else if (!top.equals(t)) { single = false; break; }
            }
        }
        int count = 0;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new FileInputStream(zip), 65536))) {
            ZipEntry e;
            byte[] buf = new byte[65536];
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                String rel = single && top != null ? name.substring(Math.min(name.length(), top.length() + 1)) : name;
                if (rel.length() == 0) continue;
                File out = new File(dest, rel);
                if (!out.getCanonicalPath().startsWith(destPath)) continue;   // zip slip
                if (e.isDirectory()) { out.mkdirs(); continue; }
                String lower = out.getName().toLowerCase(java.util.Locale.ROOT);
                if (out.exists() && (lower.contains("savedata") || lower.startsWith("loadlog"))) continue;   // keep the user's progress
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
                count++;
                if (progress != null && count % 40 == 0) progress.onProgress("Unpacking… " + count + " files");
            }
        }
        if (count == 0) throw new IOException("The archive was empty");
    }

    /** The folder that holds the "resources" folder (where the script has to sit); dest itself if there is none. */
    private static File findResourcesParent(File dir, int depth) {
        if (new File(dir, "resources").isDirectory()) return dir;
        File[] l = dir.listFiles();
        if (l == null || depth >= 3) return null;
        for (File f : l) {
            if (!f.isDirectory()) continue;
            File r = findResourcesParent(f, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    /** Downloads the trial package, unpacks it under <luaDir>/crystal_cube99_trial and puts the script next to its resources. */
    static File installTrial(android.content.Context ctx, String luaDir, Progress progress) throws IOException {
        File dest = new File(luaDir, TRIAL_FOLDER);
        if (!dest.isDirectory() && !dest.mkdirs()) throw new IOException("Cannot create " + dest);
        File zip = new File(dest, "download.tmp");
        try {
            if (progress != null) progress.onProgress("Downloading…");
            downloadTo(TRIAL_URL, zip, progress);
            if (zip.length() < 1024 * 1024) throw new IOException("The download is too small to be the trial package");
            unzipFile(zip, dest, progress);
        } finally {
            //noinspection ResultOfMethodCallIgnored
            zip.delete();
        }
        File home = findResourcesParent(dest, 0);
        if (home == null) home = dest;
        File script = new File(home, TRIAL_SCRIPT);
        try (InputStream in = ctx.getAssets().open(TRIAL_SCRIPT); OutputStream os = new FileOutputStream(script)) {
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
        }
        return script;
    }

    /** Unzips a GitHub style archive (one top level folder that is dropped). Existing files in saved/ are kept. */
    static void extractZip(InputStream raw, File dest, Progress progress) throws IOException {
        String destPath = dest.getCanonicalPath() + File.separator;
        int count = 0;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw))) {
            ZipEntry e;
            byte[] buf = new byte[16384];
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                int slash = name.indexOf('/');
                if (slash < 0) continue;                  // top level files outside the folder
                String rel = name.substring(slash + 1);
                if (rel.length() == 0) continue;
                File out = new File(dest, rel);
                if (!out.getCanonicalPath().startsWith(destPath)) continue;   // zip slip
                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                if (rel.startsWith("saved/") && out.exists()) continue;       // keep the user's own saves
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
                count++;
                if (progress != null && count % 25 == 0) progress.onProgress("Unpacking… " + count + " files");
            }
        }
        if (count == 0) throw new IOException("The archive was empty");
    }

    /** character_select.fs shipped with the 3rd Strike training script (looked up two folders deep). */
    static String findCharacterSelectState(String luaDir, String rom) {
        File root = new File(luaDir);
        File[] l1 = root.listFiles();
        if (l1 == null) return "";
        for (File a : l1) {
            File f = new File(a, "data/" + rom + "/savestates/character_select.fs");
            if (f.isFile()) return f.getAbsolutePath();
            File[] l2 = a.isDirectory() ? a.listFiles() : null;
            if (l2 == null) continue;
            for (File b : l2) {
                f = new File(b, "data/" + rom + "/savestates/character_select.fs");
                if (f.isFile()) return f.getAbsolutePath();
            }
        }
        return "";
    }
}
