package com.fbneo.android;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Looks at a Lua script before it is started and can download the well known training script package. */
final class LuaTools {
    private LuaTools() {}

    static final String TRAINING_URL = "https://github.com/Grouflon/3rd_training_lua/archive/HEAD.zip";
    static final String TRAINING_FOLDER = "3rd_training_lua";
    static final String TRIAL_URL = "https://github.com/hexie911/sf3_3rd_trial_lua_20220613/releases/download/3s/sf3_3rd_trial_lua_20220613.zip";
    static final String TRIAL_FOLDER = "sf3_3rd_trial_lua";
    static final String TRIAL_SCRIPT = "sf3_3rd_trial_20220613.lua";
    static final String TRAINING_SCRIPT = "3rd_training.lua";


    static final class Report {
        /** Files or folders the script needs that are not next to it. */
        final List<String> missing = new ArrayList<>();
        /** Friendly hints that are not blocking. */
        final List<String> notes = new ArrayList<>();
        /** ROM sets the script ships data for (data/<set>/ folders); empty = no restriction known. */
        final List<String> sets = new ArrayList<>();

        boolean ok() { return missing.isEmpty(); }
    }

    private static final Pattern REQUIRE = Pattern.compile("\\brequire\\s*\\(?\\s*[\"']([^\"']+)[\"']");
    private static final Pattern DOFILE = Pattern.compile("\\b(?:dofile|loadfile)\\s*\\(?\\s*[\"']([^\"']+)[\"']");
    private static final Pattern DIRREF = Pattern.compile("[\"']((?:images|data|assets|resources)/)[^\"']*[\"']");
    private static final List<String> BUILTIN = Arrays.asList("string", "table", "math", "io", "os", "debug", "package",
            "coroutine", "bit", "gd", "lfs", "socket", "winapi", "lpeg", "ffi", "jit", "emu", "gui", "memory", "joypad");

    static String readText(File f, int max) {
        try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && bo.size() < max) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } catch (IOException e) {
            return "";
        }
    }

    static Report check(File script, String rom) {
        Report r = new Report();
        File dir = script.getParentFile();
        if (dir == null) return r;
        String src = readText(script, 600 * 1024);

        Matcher m = REQUIRE.matcher(src);
        while (m.find()) {
            String name = m.group(1);
            if (BUILTIN.contains(name)) continue;
            String asPath = name.replace('.', '/');
            boolean found = false;
            for (String cand : new String[]{name + ".lua", asPath + ".lua", name + "/init.lua", asPath + "/init.lua"}) {
                if (new File(dir, cand).isFile()) { found = true; break; }
            }
            if (!found) {
                String shown = name.contains("/") ? name : asPath;
                if (!r.missing.contains(shown + ".lua")) r.missing.add(shown + ".lua");
            }
        }
        m = DOFILE.matcher(src);
        while (m.find()) {
            String p = m.group(1);
            if (p.startsWith("/")) continue;
            if (!new File(dir, p).isFile() && !r.missing.contains(p)) r.missing.add(p);
        }
        m = DIRREF.matcher(src);
        while (m.find()) {
            String d = m.group(1);
            if (!new File(dir, d).isDirectory() && !r.missing.contains(d)) r.missing.add(d);
        }

        // data/<rom set>/ folders: scripts that ship per game data only work with those sets
        File data = new File(dir, "data");
        File[] sub = data.listFiles();
        if (sub != null && rom != null) {
            List<String> sets = new ArrayList<>();
            boolean match = false;
            for (File f : sub) {
                if (!f.isDirectory()) continue;
                sets.add(f.getName());
                if (f.getName().equals(rom)) match = true;
            }
            r.sets.addAll(sets);
            if (!sets.isEmpty() && !match) {
                java.util.Collections.sort(sets);
                StringBuilder sb = new StringBuilder();
                for (String s : sets) { if (sb.length() > 0) sb.append(", "); sb.append(s); }
                r.notes.add(Lang.t("This script is made for: ") + sb + ". " + rom + Lang.t(" may run with limited features."));
            }
        }
        return r;
    }

    /** The script needs somewhere to save recordings and settings. */
    static void prepareFolders(File script) {
        File dir = script.getParentFile();
        if (dir == null) return;
        String src = readText(script, 600 * 1024);
        if (src.contains("saved/")) {
            new File(dir, "saved/recordings").mkdirs();
        }
    }

    static String describeMissing(Report r) {
        StringBuilder sb = new StringBuilder(Lang.t("Missing next to the script: "));
        for (int i = 0; i < r.missing.size() && i < 3; i++) {
            if (i > 0) sb.append(", ");
            sb.append(r.missing.get(i));
        }
        if (r.missing.size() > 3) sb.append(" …");
        return sb.toString();
    }

    // ---- download ----------------------------------------------------------------------

    interface Progress { void onProgress(String what); }

    /** Downloads the package into <luaDir>/3rd_training_lua and returns the script file. Blocking. */
    static File installTraining(String luaDir, Progress progress) throws IOException {
        File dest = new File(luaDir, TRAINING_FOLDER);
        if (!dest.isDirectory() && !dest.mkdirs()) throw new IOException(Lang.t("Cannot create ") + dest);
        if (progress != null) progress.onProgress(Lang.t("Downloading…"));
        HttpURLConnection con = (HttpURLConnection) new URL(TRAINING_URL).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(60000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "FBNeo-Android");
        int code = con.getResponseCode();
        if (code != 200) throw new IOException(Lang.t("Download failed (HTTP ") + code + ")");
        try (InputStream in = con.getInputStream()) {
            extractZip(in, dest, progress);
        } finally {
            con.disconnect();
        }
        File script = new File(dest, TRAINING_SCRIPT);
        if (!script.isFile()) throw new IOException(Lang.t("The download did not contain ") + TRAINING_SCRIPT);
        new File(dest, "saved/recordings").mkdirs();
        return script;
    }


    // ---- Crystal Cube 99 3rd Strike trials (about 140 MB: the script, its pictures and the start states) -----

    static boolean isTrialScript(String path) {
        return path != null && new File(path).getName().equals(TRIAL_SCRIPT);
    }

    /** Downloads the trial pack into <luaDir>/sf3_3rd_trial_lua and returns the script file. Blocking. */
    static File installTrial(String luaDir, Progress progress) throws IOException {
        File dest = new File(luaDir, TRIAL_FOLDER);
        if (!dest.isDirectory() && !dest.mkdirs()) throw new IOException(Lang.t("Cannot create ") + dest);
        if (progress != null) progress.onProgress(Lang.t("Downloading…"));
        HttpURLConnection con = open(TRIAL_URL);
        try {
            int code = con.getResponseCode();
            if (code != 200) throw new IOException(Lang.t("Download failed (HTTP ") + code + ")");
            try (InputStream in = con.getInputStream()) {
                extractZip(in, dest, progress, java.nio.charset.Charset.forName("windows-31j"), true);
            }
        } finally {
            con.disconnect();
        }
        File script = new File(dest, TRIAL_SCRIPT);
        if (!script.isFile()) throw new IOException(Lang.t("The download did not contain ") + TRIAL_SCRIPT);
        convertTrialStates(script, progress);
        return script;
    }

    // The trial states were recorded with a 2022 Fightcade core. Its CPS3 driver saved its variables in a slightly
    // different layout than the current core expects, so each state is rewritten once into the current layout.
    private static final int TRIAL_OLD_RAW = 10295594;
    private static final String TRIAL_MARK = ".states_v2";

    static boolean trialStatesPending(File script) {
        File dir = script.getParentFile();
        return dir != null && !new File(dir, TRIAL_MARK).exists();
    }

    /** Converts every numbered state file next to the script. Blocking; safe to run again. */
    static void convertTrialStates(File script, Progress progress) throws IOException {
        File dir = script.getParentFile();
        File[] fs = dir == null ? null : dir.listFiles((d, n) -> n.matches("\\d+"));
        if (fs == null) return;
        int done = 0;
        for (File f : fs) {
            if (progress != null) progress.onProgress(Lang.t("Preparing trial states…") + " " + (++done) + "/" + fs.length);
            convertTrialState(f);
        }
        new File(dir, TRIAL_MARK).createNewFile();
    }

    private static byte[] readAll(File f) throws IOException {
        byte[] b = new byte[(int) f.length()];
        try (java.io.DataInputStream in = new java.io.DataInputStream(new java.io.FileInputStream(f))) { in.readFully(b); }
        return b;
    }

    private static int le32(byte[] b, int o) {
        return (b[o] & 255) | (b[o + 1] & 255) << 8 | (b[o + 2] & 255) << 16 | (b[o + 3] & 255) << 24;
    }

    private static void put32(byte[] b, int o, int v) {
        b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
    }

    private static int nameHash(String str) {
        int h = 0xc0ffee;
        for (int i = 0; i < str.length(); i++) h = (h ^ str.charAt(i)) + ((h << 0x1a) + (h >>> 6));
        return h;
    }

    private static void block(java.io.ByteArrayOutputStream o, String name, byte[] src, int off, int len) {
        byte[] hd = new byte[12];
        put32(hd, 0, 0xa55a0001);
        put32(hd, 4, len);
        put32(hd, 8, nameHash(name));
        o.write(hd, 0, 12);
        o.write(src, off, len);
    }

    private static void block(java.io.ByteArrayOutputStream o, String name, byte[] v) {
        block(o, name, v, 0, v.length);
    }

    private static byte[] zeros(int n) { return new byte[n]; }

    private static byte[] le(int v, int n) {
        byte[] b = new byte[n];
        for (int i = 0; i < n; i++) b[i] = (byte) (v >> (8 * i));
        return b;
    }

    private static void convertTrialState(File f) throws IOException {
        if (f.length() < 100 || f.length() > 64L * 1024 * 1024) return;
        byte[] d = readAll(f);
        if (d.length < 80 || !"FB1 FS1 ".equals(new String(d, 0, 8, "ISO-8859-1"))) return;
        if (le32(d, 76) == 0xa55a0000) return;              // already in the current layout
        int dl = le32(d, 24);
        if (dl <= 0 || 76L + dl > d.length) return;
        final int OLD = TRIAL_OLD_RAW, MID = 10295374;      // original pack / the v1.74 intermediate form
        byte[] raw = new byte[OLD + 1];
        int n = 0;
        try {
            java.util.zip.Inflater inf = new java.util.zip.Inflater();
            inf.setInput(d, 76, dl);
            while (!inf.finished() && n < raw.length) {
                int r = inf.inflate(raw, n, raw.length - n);
                if (r == 0 && (inf.needsInput() || inf.needsDictionary())) break;
                n += r;
            }
            inf.end();
        } catch (java.util.zip.DataFormatException e) { return; }
        if (n != OLD && n != MID) return;                   // not a CPS3 trial state

        final int RAM4 = 0x80000 * 3 + 0x10000;
        int o = 0;
        byte[] eep = new byte[0x200];
        System.arraycopy(raw, 0, eep, 0, 0x200);
        o += n == OLD ? 0x400 : 0x200;
        int ramOff = o; o += RAM4;
        int vregOff = o; o += 0x100;
        if (n == MID) o += 0x100;                           // buffered copy, rebuilt below
        int c000Off = o; o += 0x800;
        int palOff = o; o += 0x40000;
        int cramOff = o; o += 0x800000;
        int sh2Off = o; o += 2412;
        int susOff = o; o += 4;
        int voiceOff = o; o += 640;
        int keyOff = o; o += 2;
        if (n == OLD) o += 8;                               // old input words
        int varsOff = o; o += 44;
        if (n == MID) o += 2 + 2 + 4 + 12 + 4 + 4;
        int int10Off = o;

        // the SH-2 state gained an irq_line_hold[17] array (and padding) after irq_line_state
        byte[] sh2 = new byte[2428];
        System.arraycopy(raw, sh2Off, sh2, 0, 277);
        System.arraycopy(raw, sh2Off + 280, sh2, 296, 2412 - 280);

        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream(MID + 4096);
        byte[] hd = new byte[8];
        put32(hd, 0, 0xa55a0000);
        out.write(hd, 0, 8);
        block(out, "EEPROM RAM", eep);
        block(out, "Main RAM", raw, ramOff, 0x80000);
        block(out, "Sprite RAM", raw, ramOff + 0x80000, 0x80000);
        block(out, "Sprite List", raw, ramOff + 0x100000, 0x80000);
        block(out, "Char ROM", raw, ramOff + 0x180000, 0x10000);
        block(out, "Video REG", raw, vregOff, 0x100);
        block(out, "Video REG_BUF", raw, vregOff, 0x100);
        block(out, "RAM C000", raw, c000Off, 0x800);
        block(out, "Palette", raw, palOff, 0x40000);
        block(out, "Sprite ROM", raw, cramOff, 0x800000);
        block(out, "SH2 #0", sh2);
        block(out, "Sh2Ext[i].suspend", raw, susOff, 4);
        block(out, "chip->voice", raw, voiceOff, 640);
        block(out, "chip->key", raw, keyOff, 2);
        int v = varsOff;
        block(out, "ss_bank_base", raw, v, 4); v += 4;
        block(out, "ss_pal_base", raw, v, 4); v += 4;
        block(out, "cram_bank", raw, v, 4); v += 4;
        block(out, "cps3_current_eeprom_read", raw, v, 2); v += 2;
        block(out, "gfxflash_bank", raw, v, 4); v += 4;
        block(out, "paldma_source", raw, v, 4); v += 4;
        block(out, "paldma_dest", raw, v, 4); v += 4;
        block(out, "paldma_fade", raw, v, 4); v += 4;
        block(out, "paldma_length", raw, v, 4); v += 4;
        block(out, "chardma_source", raw, v, 4); v += 4;
        block(out, "chardma_table_address", raw, v, 4); v += 4;
        block(out, "spritelist_dma", raw, v, 2);
        block(out, "spritelist_dma_prev", raw, v, 2);
        block(out, "dma_status", zeros(2));
        block(out, "dma_timer", le(-1, 4));
        byte[] flash = new byte[12];
        put32(flash, 0, 0x80);                              // status 0x80, normal mode, unlocked
        block(out, "main_flash", flash);
        block(out, "last_normal_byte", zeros(4));
        block(out, "lastb", zeros(2));
        block(out, "lastb2", zeros(2));
        block(out, "cps_int10_cnt", raw, int10Off, 4);
        block(out, "nExtraCycles", zeros(4));
        block(out, "prev", zeros(4));
        block(out, "prev_ud", zeros(4));
        block(out, "prev_lr", zeros(4));
        byte[] nw = out.toByteArray();

        int pad = (4 - (nw.length & 3)) & 3;
        byte[] h = java.util.Arrays.copyOf(d, 76);
        put32(h, 8, le32(d, 8) - dl + nw.length + pad);
        put32(h, 24, nw.length);
        File tmp = new File(f.getPath() + ".tmp");
        try (OutputStream os = new FileOutputStream(tmp)) {
            os.write(h);
            os.write(nw);
            os.write(new byte[pad]);
            os.write(d, 76 + dl, d.length - 76 - dl);
        }
        if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) throw new IOException("cannot replace " + f); }
    }

    // ---- JoJo's Bizarre Adventure training mode (maximusmaxy) ---------------------------------

    static final String JOJO_FOLDER = "jojoban_training";
    private static final String JOJO_API = "https://api.github.com/repos/maximusmaxy/JoJoban-Training-Mode-Menu-FBNeo/releases/tags/0.8.0";

    static boolean isJojo(String rom) {
        return rom != null && rom.toLowerCase(java.util.Locale.ROOT).startsWith("jojo");
    }

    static boolean isJojoScript(String path) {
        return path != null && path.toLowerCase(java.util.Locale.ROOT).contains(JOJO_FOLDER);
    }

    private static String httpText(String url) throws IOException {
        HttpURLConnection con = open(url);
        con.setRequestProperty("Accept", "application/vnd.github+json");
        try {
            int code = con.getResponseCode();
            if (code != 200) throw new IOException(Lang.t("Download failed (HTTP ") + code + ")");
            try (InputStream in = con.getInputStream()) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) > 0 && bo.size() < 2000000) bo.write(b, 0, n);
                return bo.toString("UTF-8");
            }
        } finally {
            con.disconnect();
        }
    }

    /** Looks up the release's files, downloads the zip and unpacks it into <lua folder>/jojoban_training. */
    static File installJojo(String luaDir, Progress progress) throws IOException {
        File dest = new File(luaDir, JOJO_FOLDER);
        if (!dest.isDirectory() && !dest.mkdirs()) throw new IOException(Lang.t("Cannot create ") + dest);
        if (progress != null) progress.onProgress(Lang.t("Looking up the release…"));
        String json = httpText(JOJO_API);
        String url = null;
        Matcher m = Pattern.compile("\"browser_download_url\"\\s*:\\s*\"([^\"]+)\"").matcher(json);
        while (m.find()) {
            String u = m.group(1);
            if (u.toLowerCase(java.util.Locale.ROOT).endsWith(".zip")) { url = u; break; }
        }
        if (url == null) {
            Matcher z = Pattern.compile("\"zipball_url\"\\s*:\\s*\"([^\"]+)\"").matcher(json);
            if (z.find()) url = z.group(1);
        }
        if (url == null) throw new IOException(Lang.t("The release has no zip file"));
        if (progress != null) progress.onProgress(Lang.t("Downloading…"));
        File tmp = new File(dest, "download.zip.tmp");
        HttpURLConnection con = open(url);
        try {
            if (con.getResponseCode() != 200) throw new IOException(Lang.t("Download failed (HTTP ") + con.getResponseCode() + ")");
            try (InputStream in = con.getInputStream(); OutputStream os = new FileOutputStream(tmp)) {
                byte[] b = new byte[16384];
                int n;
                while ((n = in.read(b)) > 0) os.write(b, 0, n);
            }
        } finally {
            con.disconnect();
        }
        try {
            extractAnyZip(tmp, dest, progress);
        } finally {
            tmp.delete();
        }
        File script = findJojoScript(dest);
        if (script == null) throw new IOException(Lang.t("The download did not contain a Lua script"));
        new File(script.getParentFile(), "saved").mkdirs();
        return script;
    }

    /** Unzips; when every entry sits inside one top-level folder that folder is dropped, otherwise files keep their paths. */
    static void extractAnyZip(File zip, File dest, Progress progress) throws IOException {
        String top = null;
        boolean single = true;
        try (java.util.zip.ZipFile zf = new java.util.zip.ZipFile(zip)) {
            java.util.Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                String name = en.nextElement().getName().replace('\\', '/');
                int slash = name.indexOf('/');
                if (slash < 0) { single = false; break; }
                String t = name.substring(0, slash);
                if (top == null) top = t; else if (!top.equals(t)) { single = false; break; }
            }
        }
        String destPath = dest.getCanonicalPath() + File.separator;
        int count = 0;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new FileInputStream(zip)))) {
            ZipEntry e;
            byte[] buf = new byte[16384];
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                String rel = single ? name.substring(name.indexOf('/') + 1) : name;
                if (rel.length() == 0) continue;
                File out = new File(dest, rel);
                if (!out.getCanonicalPath().startsWith(destPath)) continue;   // zip slip
                if (e.isDirectory()) { out.mkdirs(); continue; }
                if (rel.contains("saved/") && out.exists()) continue;         // keep the user's own saves
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
                count++;
                if (progress != null && count % 25 == 0) progress.onProgress(Lang.t("Unpacking… ") + count + Lang.t(" files"));
            }
        }
        if (count == 0) throw new IOException(Lang.t("The archive was empty"));
    }

    /** The main script: a .lua file near the top that is named like the training mode, else any top level one. */
    static File findJojoScript(File dir) {
        File best = null;
        int bestScore = -1;
        java.util.ArrayDeque<File> q = new java.util.ArrayDeque<>();
        java.util.ArrayDeque<Integer> depth = new java.util.ArrayDeque<>();
        q.add(dir);
        depth.add(0);
        while (!q.isEmpty()) {
            File d = q.poll();
            int dep = depth.poll();
            File[] l = d.listFiles();
            if (l == null) continue;
            for (File f : l) {
                String n = f.getName().toLowerCase(java.util.Locale.ROOT);
                if (f.isDirectory()) {
                    if (dep < 2) { q.add(f); depth.add(dep + 1); }
                } else if (n.endsWith(".lua")) {
                    int score = 10 - dep * 3;
                    if (n.contains("jojo")) score += 6;
                    if (n.contains("training")) score += 4;
                    if (n.contains("menu")) score += 1;
                    if (score > bestScore) { best = f; bestScore = score; }
                }
            }
        }
        return best;
    }

    // ---- Crystal Cube 99 trials ---------------------------------------------------------

    private static final Pattern FORM_ACTION = Pattern.compile("<form[^>]*action=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
    private static final Pattern INPUT = Pattern.compile("<input\\b[^>]*>", Pattern.CASE_INSENSITIVE);
    private static final Pattern ATTR_NAME = Pattern.compile("\\bname=\"([^\"]*)\"", Pattern.CASE_INSENSITIVE);
    private static final Pattern ATTR_VALUE = Pattern.compile("\\bvalue=\"([^\"]*)\"", Pattern.CASE_INSENSITIVE);

    private static String decodeHtml(String v) {
        return v.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'");
    }

    private static HttpURLConnection open(String url) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(20000);
        con.setReadTimeout(60000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) FBNeo-Android");
        return con;
    }

    /** Downloads the zip to a file. Google Drive may answer big files with a "can't scan for viruses" page first. */
    private static void downloadTo(String url, File out, Progress progress) throws IOException {
        java.net.CookieHandler old = java.net.CookieHandler.getDefault();
        java.net.CookieHandler.setDefault(new java.net.CookieManager());
        try {
            String cur = url;
            for (int attempt = 0; attempt < 3; attempt++) {
                HttpURLConnection con = open(cur);
                int code = con.getResponseCode();
                if (code != 200) { con.disconnect(); throw new IOException(Lang.t("Download failed (HTTP ") + code + ")"); }
                String type = con.getContentType() == null ? "" : con.getContentType().toLowerCase(java.util.Locale.ROOT);
                if (type.startsWith("text/html")) {
                    String html = "";
                    try (InputStream in = con.getInputStream()) {
                        ByteArrayOutputStream bo = new ByteArrayOutputStream();
                        byte[] b = new byte[8192];
                        int n;
                        while ((n = in.read(b)) > 0 && bo.size() < 400000) bo.write(b, 0, n);
                        html = bo.toString("UTF-8");
                    } finally {
                        con.disconnect();
                    }
                    Matcher fm = FORM_ACTION.matcher(html);
                    if (!fm.find()) {
                        // no confirmation form: Drive refused. Show what it says.
                        String text = html.replaceAll("(?is)<(script|style).*?</\\1>", " ").replaceAll("<[^>]+>", " ").replaceAll("\\s+", " ").trim();
                        if (text.length() > 160) text = text.substring(0, 160);
                        throw new IOException(Lang.t("Google Drive refused the download: ") + text);
                    }
                    StringBuilder q = new StringBuilder(decodeHtml(fm.group(1)));
                    q.append(q.indexOf("?") >= 0 ? "&" : "?");
                    Matcher im = INPUT.matcher(html);
                    boolean first = true;
                    while (im.find()) {
                        Matcher nm = ATTR_NAME.matcher(im.group());
                        Matcher vm = ATTR_VALUE.matcher(im.group());
                        if (!nm.find()) continue;
                        String val = vm.find() ? vm.group(1) : "";
                        if (!first) q.append('&');
                        first = false;
                        q.append(java.net.URLEncoder.encode(decodeHtml(nm.group(1)), "UTF-8")).append('=')
                                .append(java.net.URLEncoder.encode(decodeHtml(val), "UTF-8"));
                    }
                    cur = q.toString();
                    continue;
                }
                long total = con.getContentLengthLong();
                try (InputStream in = new BufferedInputStream(con.getInputStream(), 65536);
                     OutputStream os = new FileOutputStream(out)) {
                    byte[] buf = new byte[65536];
                    long done = 0, lastReport = 0;
                    int n;
                    while ((n = in.read(buf)) > 0) {
                        os.write(buf, 0, n);
                        done += n;
                        if (progress != null && done - lastReport >= (2L << 20)) {
                            lastReport = done;
                            progress.onProgress(Lang.t("Downloading… ") + (done >> 20) + (total > 0 ? Lang.t(" of ") + (total >> 20) : "") + Lang.t(" MB"));
                        }
                    }
                } finally {
                    con.disconnect();
                }
                return;
            }
            throw new IOException(Lang.t("Google Drive kept asking for confirmation"));
        } finally {
            java.net.CookieHandler.setDefault(old);
        }
    }

    /** Unzips into dest. A single top level folder is dropped; the user's own save files are kept. */
    private static void unzipFile(File zip, File dest, Progress progress) throws IOException {
        try {
            unzipFile(zip, dest, progress, java.nio.charset.StandardCharsets.UTF_8);
        } catch (IllegalArgumentException e) {
            // file names that are not UTF-8 (old Japanese zip tools): read them as plain bytes
            unzipFile(zip, dest, progress, java.nio.charset.StandardCharsets.ISO_8859_1);
        }
    }

    private static void unzipFile(File zip, File dest, Progress progress, java.nio.charset.Charset cs) throws IOException {
        String destPath = dest.getCanonicalPath() + File.separator;
        String top = null;
        boolean single = true;
        try (java.util.zip.ZipFile zf = new java.util.zip.ZipFile(zip, cs)) {
            java.util.Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                String n = en.nextElement().getName().replace('\\', '/');
                int sl = n.indexOf('/');
                if (sl < 0) { single = false; break; }
                String t = n.substring(0, sl);
                if (top == null) top = t; else if (!top.equals(t)) { single = false; break; }
            }
        }
        int count = 0;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new FileInputStream(zip), 65536), cs)) {
            ZipEntry e;
            byte[] buf = new byte[65536];
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                String rel = single && top != null ? name.substring(Math.min(name.length(), top.length() + 1)) : name;
                if (rel.length() == 0) continue;
                File out = new File(dest, rel);
                if (!out.getCanonicalPath().startsWith(destPath)) continue;   // zip slip
                if (e.isDirectory()) { out.mkdirs(); continue; }
                String lower = out.getName().toLowerCase(java.util.Locale.ROOT);
                if (out.exists() && (lower.contains("savedata") || lower.startsWith("loadlog"))) continue;   // keep the user's progress
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
                count++;
                if (progress != null && count % 40 == 0) progress.onProgress(Lang.t("Unpacking… ") + count + Lang.t(" files"));
            }
        }
        if (count == 0) throw new IOException(Lang.t("The archive was empty"));
    }

    /** The folder that holds the "resources" folder (where the script has to sit); dest itself if there is none. */
    private static File findResourcesParent(File dir, int depth) {
        if (new File(dir, "resources").isDirectory()) return dir;
        File[] l = dir.listFiles();
        if (l == null || depth >= 3) return null;
        for (File f : l) {
            if (!f.isDirectory()) continue;
            File r = findResourcesParent(f, depth + 1);
            if (r != null) return r;
        }
        return null;
    }

    /** Unzips a GitHub style archive (one top level folder that is dropped). Existing files in saved/ are kept. */
    static void extractZip(InputStream raw, File dest, Progress progress) throws IOException {
        extractZip(raw, dest, progress, java.nio.charset.StandardCharsets.UTF_8, false);
    }

    /** trial: keeps the player's own progress file and skips the unused Japanese-named picture folders. */
    static void extractZip(InputStream raw, File dest, Progress progress, java.nio.charset.Charset cs, boolean trial) throws IOException {
        String destPath = dest.getCanonicalPath() + File.separator;
        int count = 0;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw), cs)) {
            ZipEntry e;
            byte[] buf = new byte[16384];
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                int slash = name.indexOf('/');
                if (slash < 0) continue;                  // top level files outside the folder
                String rel = name.substring(slash + 1);
                if (rel.length() == 0) continue;
                File out = new File(dest, rel);
                if (!out.getCanonicalPath().startsWith(destPath)) continue;   // zip slip
                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                if (rel.startsWith("saved/") && out.exists()) continue;       // keep the user's own saves
                if (trial && rel.startsWith("resources/command/syoryu")) continue;
                if (trial && rel.equals("3rdtrial_savedata.txt") && out.exists()) continue;
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
                count++;
                if (progress != null && count % 25 == 0) progress.onProgress(Lang.t("Unpacking… ") + count + Lang.t(" files"));
            }
        }
        if (count == 0) throw new IOException(Lang.t("The archive was empty"));
    }

    /** character_select.fs shipped with the 3rd Strike training script (looked up two folders deep). */
    static String findCharacterSelectState(String luaDir, String rom) {
        File root = new File(luaDir);
        File[] l1 = root.listFiles();
        if (l1 == null) return "";
        for (File a : l1) {
            File f = new File(a, "data/" + rom + "/savestates/character_select.fs");
            if (f.isFile()) return f.getAbsolutePath();
            File[] l2 = a.isDirectory() ? a.listFiles() : null;
            if (l2 == null) continue;
            for (File b : l2) {
                f = new File(b, "data/" + rom + "/savestates/character_select.fs");
                if (f.isFile()) return f.getAbsolutePath();
            }
        }
        return "";
    }
}
