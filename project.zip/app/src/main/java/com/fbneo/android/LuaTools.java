package com.fbneo.android;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Looks at a Lua script before it is started and can download the well known training script package. */
final class LuaTools {
    private LuaTools() {}

    static final String TRAINING_URL = "https://github.com/Grouflon/3rd_training_lua/archive/HEAD.zip";
    static final String TRAINING_FOLDER = "3rd_training_lua";
    static final String TRAINING_SCRIPT = "3rd_training.lua";

    static final class Report {
        /** Files or folders the script needs that are not next to it. */
        final List<String> missing = new ArrayList<>();
        /** Friendly hints that are not blocking. */
        final List<String> notes = new ArrayList<>();
        /** ROM sets the script ships data for (data/<set>/ folders); empty = no restriction known. */
        final List<String> sets = new ArrayList<>();

        boolean ok() { return missing.isEmpty(); }
    }

    private static final Pattern REQUIRE = Pattern.compile("\\brequire\\s*\\(?\\s*[\"']([^\"']+)[\"']");
    private static final Pattern DOFILE = Pattern.compile("\\b(?:dofile|loadfile)\\s*\\(?\\s*[\"']([^\"']+)[\"']");
    private static final Pattern DIRREF = Pattern.compile("[\"']((?:images|data|assets|resources)/)[^\"']*[\"']");
    private static final List<String> BUILTIN = Arrays.asList("string", "table", "math", "io", "os", "debug", "package",
            "coroutine", "bit", "gd", "lfs", "socket", "winapi", "lpeg", "ffi", "jit", "emu", "gui", "memory", "joypad");

    static String readText(File f, int max) {
        try (InputStream in = new BufferedInputStream(new FileInputStream(f))) {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0 && bo.size() < max) bo.write(buf, 0, n);
            return bo.toString("UTF-8");
        } catch (IOException e) {
            return "";
        }
    }

    static Report check(File script, String rom) {
        Report r = new Report();
        File dir = script.getParentFile();
        if (dir == null) return r;
        String src = readText(script, 600 * 1024);

        Matcher m = REQUIRE.matcher(src);
        while (m.find()) {
            String name = m.group(1);
            if (BUILTIN.contains(name)) continue;
            String asPath = name.replace('.', '/');
            boolean found = false;
            for (String cand : new String[]{name + ".lua", asPath + ".lua", name + "/init.lua", asPath + "/init.lua"}) {
                if (new File(dir, cand).isFile()) { found = true; break; }
            }
            if (!found) {
                String shown = name.contains("/") ? name : asPath;
                if (!r.missing.contains(shown + ".lua")) r.missing.add(shown + ".lua");
            }
        }
        m = DOFILE.matcher(src);
        while (m.find()) {
            String p = m.group(1);
            if (p.startsWith("/")) continue;
            if (!new File(dir, p).isFile() && !r.missing.contains(p)) r.missing.add(p);
        }
        m = DIRREF.matcher(src);
        while (m.find()) {
            String d = m.group(1);
            if (!new File(dir, d).isDirectory() && !r.missing.contains(d)) r.missing.add(d);
        }

        // data/<rom set>/ folders: scripts that ship per game data only work with those sets
        File data = new File(dir, "data");
        File[] sub = data.listFiles();
        if (sub != null && rom != null) {
            List<String> sets = new ArrayList<>();
            boolean match = false;
            for (File f : sub) {
                if (!f.isDirectory()) continue;
                sets.add(f.getName());
                if (f.getName().equals(rom)) match = true;
            }
            r.sets.addAll(sets);
            if (!sets.isEmpty() && !match) {
                java.util.Collections.sort(sets);
                StringBuilder sb = new StringBuilder();
                for (String s : sets) { if (sb.length() > 0) sb.append(", "); sb.append(s); }
                r.notes.add("This script is made for: " + sb + ". " + rom + " may run with limited features.");
            }
        }
        return r;
    }

    /** The script needs somewhere to save recordings and settings. */
    static void prepareFolders(File script) {
        File dir = script.getParentFile();
        if (dir == null) return;
        String src = readText(script, 600 * 1024);
        if (src.contains("saved/")) {
            new File(dir, "saved/recordings").mkdirs();
        }
    }

    static String describeMissing(Report r) {
        StringBuilder sb = new StringBuilder("Missing next to the script: ");
        for (int i = 0; i < r.missing.size() && i < 3; i++) {
            if (i > 0) sb.append(", ");
            sb.append(r.missing.get(i));
        }
        if (r.missing.size() > 3) sb.append(" …");
        return sb.toString();
    }

    // ---- download ----------------------------------------------------------------------

    interface Progress { void onProgress(String what); }

    /** Downloads the package into <luaDir>/3rd_training_lua and returns the script file. Blocking. */
    static File installTraining(String luaDir, Progress progress) throws IOException {
        File dest = new File(luaDir, TRAINING_FOLDER);
        if (!dest.isDirectory() && !dest.mkdirs()) throw new IOException("Cannot create " + dest);
        if (progress != null) progress.onProgress("Downloading…");
        HttpURLConnection con = (HttpURLConnection) new URL(TRAINING_URL).openConnection();
        con.setConnectTimeout(15000);
        con.setReadTimeout(60000);
        con.setInstanceFollowRedirects(true);
        con.setRequestProperty("User-Agent", "FBNeo-Android");
        int code = con.getResponseCode();
        if (code != 200) throw new IOException("Download failed (HTTP " + code + ")");
        try (InputStream in = con.getInputStream()) {
            extractZip(in, dest, progress);
        } finally {
            con.disconnect();
        }
        File script = new File(dest, TRAINING_SCRIPT);
        if (!script.isFile()) throw new IOException("The download did not contain " + TRAINING_SCRIPT);
        new File(dest, "saved/recordings").mkdirs();
        return script;
    }

    /** Unzips a GitHub style archive (one top level folder that is dropped). Existing files in saved/ are kept. */
    static void extractZip(InputStream raw, File dest, Progress progress) throws IOException {
        String destPath = dest.getCanonicalPath() + File.separator;
        int count = 0;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(raw))) {
            ZipEntry e;
            byte[] buf = new byte[16384];
            while ((e = zin.getNextEntry()) != null) {
                String name = e.getName().replace('\\', '/');
                int slash = name.indexOf('/');
                if (slash < 0) continue;                  // top level files outside the folder
                String rel = name.substring(slash + 1);
                if (rel.length() == 0) continue;
                File out = new File(dest, rel);
                if (!out.getCanonicalPath().startsWith(destPath)) continue;   // zip slip
                if (e.isDirectory()) {
                    out.mkdirs();
                    continue;
                }
                if (rel.startsWith("saved/") && out.exists()) continue;       // keep the user's own saves
                File parent = out.getParentFile();
                if (parent != null) parent.mkdirs();
                try (OutputStream os = new FileOutputStream(out)) {
                    int n;
                    while ((n = zin.read(buf)) > 0) os.write(buf, 0, n);
                }
                count++;
                if (progress != null && count % 25 == 0) progress.onProgress("Unpacking… " + count + " files");
            }
        }
        if (count == 0) throw new IOException("The archive was empty");
    }

    /** character_select.fs shipped with the 3rd Strike training script (looked up two folders deep). */
    static String findCharacterSelectState(String luaDir, String rom) {
        File root = new File(luaDir);
        File[] l1 = root.listFiles();
        if (l1 == null) return "";
        for (File a : l1) {
            File f = new File(a, "data/" + rom + "/savestates/character_select.fs");
            if (f.isFile()) return f.getAbsolutePath();
            File[] l2 = a.isDirectory() ? a.listFiles() : null;
            if (l2 == null) continue;
            for (File b : l2) {
                f = new File(b, "data/" + rom + "/savestates/character_select.fs");
                if (f.isFile()) return f.getAbsolutePath();
            }
        }
        return "";
    }
}
