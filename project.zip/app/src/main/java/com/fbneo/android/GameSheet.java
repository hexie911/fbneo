package com.fbneo.android;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.HorizontalScrollView;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Bottom sheet shown when a game is tapped: choose a Lua script, then play. */
final class GameSheet extends Dialog {
    private final LauncherActivity host;
    private final LauncherActivity.Rom rom;
    private final List<String> paths = new ArrayList<>();
    private final Map<String, LuaTools.Report> reports = new HashMap<>();
    private String selected = "";
    private boolean remember = true;
    private boolean installing;
    private String installStatus = "";
    private String installError = "";

    private LinearLayout sheet, list, diag;
    private TextView playButton;
    private ScrollView outerScroll;
    private boolean land;
    private ImageView coverThumb;
    private TextView coverStatus, coverDl, coverRemove;
    private boolean coverBusy;

    GameSheet(LauncherActivity host, LauncherActivity.Rom rom) {
        super(host);
        this.host = host;
        this.rom = rom;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        final LauncherActivity a = host;

        // which script is selected at start
        String remembered = Prefs.romScript(a, rom.name);
        String wanted = remembered != null ? remembered : Prefs.defaultLua(a);
        scanScripts();
        if (wanted.length() > 0 && new File(wanted).isFile()) {
            if (!paths.contains(wanted)) { paths.add(0, wanted); reports.put(wanted, LuaTools.check(new File(wanted), rom.name)); }
            selected = wanted;
        }

        sheet = Ui.vertical(a);
        float r = Ui.dp(a, 28);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Ui.SURFACE);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        sheet.setBackground(bg);
        sheet.setPadding(Ui.dp(a, 20), Ui.dp(a, 10), Ui.dp(a, 20), Ui.dp(a, 16));

        FrameLayout handle = new FrameLayout(a);       // tall touch area around the little bar
        View bar = new View(a);
        bar.setBackground(Ui.rounded(a, Ui.OUTLINE, 3));
        handle.addView(bar, new FrameLayout.LayoutParams(Ui.dp(a, 40), Ui.dp(a, 5), Gravity.CENTER));
        sheet.addView(handle, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, 30)));

        land = Dialogs.screenWidth(a) > Dialogs.screenHeight(a);
        coverThumb = new ImageView(a);
        coverThumb.setScaleType(ImageView.ScaleType.CENTER_CROP);
        coverThumb.setBackground(Ui.rounded(a, Ui.SURFACE2, 12));
        coverThumb.setClipToOutline(true);
        coverThumb.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View vw, android.graphics.Outline o) { o.setRoundRect(0, 0, vw.getWidth(), vw.getHeight(), Ui.dp(host, 12)); }
        });
        LinearLayout textCol = Ui.vertical(a);
        TextView title = Ui.text(a, rom.main, 19, Ui.TEXT, true);
        title.setLineSpacing(0, 1.05f);
        textCol.addView(title);
        if (rom.detail.length() > 0) {
            TextView d = Ui.text(a, rom.detail, 13, Ui.SUB, false);
            d.setPadding(0, Ui.dp(a, 4), 0, 0);
            textCol.addView(d);
        }
        LinearLayout chips = Ui.horizontal(a);
        chips.addView(Ui.chip(a, rom.name + ".zip", Ui.TEXT, Ui.SURFACE2));
        if (rom.year.length() > 0) chips.addView(Ui.chip(a, rom.year, Ui.TEXT, Ui.SURFACE2), Ui.wrapMargins(a, 8, 0, 0, 0));
        if (rom.maker.length() > 0) {
            TextView m = Ui.chip(a, rom.maker, Ui.TEXT, Ui.SURFACE2);
            m.setSingleLine(true);
            m.setEllipsize(android.text.TextUtils.TruncateAt.END);
            chips.addView(m, Ui.wrapMargins(a, 8, 0, 0, 0));
        }
        HorizontalScrollView chipScroll = new HorizontalScrollView(a);
        chipScroll.setHorizontalScrollBarEnabled(false);
        chipScroll.addView(chips);
        textCol.addView(chipScroll, Ui.fillMargins(a, 0, 10, 0, 0));
        LinearLayout headRow = land ? Ui.vertical(a) : Ui.horizontal(a);
        if (land) {
            headRow.addView(coverThumb, new LinearLayout.LayoutParams(Ui.dp(a, 110), Ui.dp(a, 110)));
            headRow.addView(textCol, Ui.fillMargins(a, 0, 10, 0, 0));
        } else {
            headRow.setGravity(Gravity.CENTER_VERTICAL);
            headRow.addView(coverThumb, new LinearLayout.LayoutParams(Ui.dp(a, 96), Ui.dp(a, 96)));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            tp.leftMargin = Ui.dp(a, 14);
            headRow.addView(textCol, tp);
        }
        sheet.addView(headRow);
        if (!land) attachDrag(handle, headRow);

        LinearLayout inner = Ui.vertical(a);
        TextView sec = Ui.text(a, Lang.t("LUA SCRIPT"), 11, Ui.ACCENT, true);
        sec.setLetterSpacing(0.1f);
        sec.setPadding(0, Ui.dp(a, 20), 0, Ui.dp(a, 8));
        inner.addView(sec);
        list = Ui.vertical(a);
        if (Dialogs.screenWidth(a) > Dialogs.screenHeight(a)) {
            inner.addView(list);
        } else {
            // portrait: the script list scrolls on its own so the sheet never grows past the screen
            ScrollView ls = new Dialogs.MaxHeightScroll(a, (int) (Dialogs.screenHeight(a) * 0.30f));
            ls.addView(list);
            inner.addView(ls);
        }
        diag = Ui.vertical(a);
        inner.addView(diag, Ui.fillMargins(a, 0, 8, 0, 0));

        TextView csec = Ui.text(a, Lang.t("GAME COVER"), 11, Ui.ACCENT, true);
        csec.setLetterSpacing(0.1f);
        csec.setPadding(0, Ui.dp(a, 16), 0, Ui.dp(a, 8));
        inner.addView(csec);
        coverStatus = Ui.text(a, "", 12, Ui.SUB, false);
        inner.addView(coverStatus);
        LinearLayout brow = Ui.horizontal(a);
        coverDl = Ui.button(a, Lang.t("Download"), Ui.TONAL, v -> downloadCover());
        brow.addView(coverDl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        pp.leftMargin = Ui.dp(a, 8);
        brow.addView(Ui.button(a, Lang.t("From phone"), Ui.TONAL, v -> { dismiss(); host.pickCover(rom); }), pp);
        coverRemove = Ui.button(a, Lang.t("Remove"), Ui.TONAL, v -> { CoverStore.remove(a, rom.name); refreshCover(); host.refreshList(); });
        coverRemove.setTextColor(Ui.DANGER);
        LinearLayout.LayoutParams rp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        rp2.leftMargin = Ui.dp(a, 8);
        brow.addView(coverRemove, rp2);
        inner.addView(brow, Ui.fillMargins(a, 0, 6, 0, 0));
        refreshCover();
        sheet.addView(inner);

        if (rom.neo && !rom.bios) {
            View q = Ui.switchRow(a, Lang.t("Home console mode (AES)"),
                    Lang.t("Starts as a Neo Geo home console, with its practice and options menus. Needs the AES BIOS in neogeo.zip"),
                    Prefs.aes(a, rom.name), (v, on) -> Prefs.setAes(host, rom.name, on));
            sheet.addView(q, Ui.fillMargins(a, 0, 12, 0, 0));
        }
        sheet.addView(Ui.switchRow(a, Lang.t("Remember for this game"), null, true, (v, on) -> remember = on),
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ((LinearLayout.LayoutParams) sheet.getChildAt(sheet.getChildCount() - 1).getLayoutParams()).setMargins(0, Ui.dp(a, 12), 0, 0);

        playButton = Ui.button(a, Lang.t("Play"), Ui.FILLED, v -> {
            dismiss();
            host.play(rom, selected, remember);
        });
        playButton.setTextSize(17);
        playButton.setMinHeight(Ui.dp(a, 54));
        playButton.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
        sheet.addView(playButton, Ui.fillMargins(a, 0, 12, 0, 0));

        View content = sheet;
        if (land) {
            // two panes: game info + Play on the left, the scripts on the right
            sheet.removeViewAt(0);                       // drag handle
            LinearLayout leftCol = Ui.vertical(a);
            java.util.ArrayList<View> keep = new java.util.ArrayList<>();
            for (int i = 0; i < sheet.getChildCount(); i++) if (sheet.getChildAt(i) != inner) keep.add(sheet.getChildAt(i));
            sheet.removeAllViews();
            for (View v : keep) leftCol.addView(v);
            LinearLayout rightCol = Ui.vertical(a);
            rightCol.addView(inner);
            int maxH = (int) (Dialogs.screenHeight(a) * 0.90f) - Ui.dp(a, 36);
            ScrollView rs = new Dialogs.MaxHeightScroll(a, maxH);
            rs.addView(rightCol);
            LinearLayout both = Ui.horizontal(a);
            both.addView(leftCol, new LinearLayout.LayoutParams(Ui.dp(a, 250), ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            rp.leftMargin = Ui.dp(a, 18);
            both.addView(rs, rp);
            sheet.setOrientation(LinearLayout.HORIZONTAL);
            sheet.addView(both, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            sheet.setBackground(Ui.rounded(a, Ui.SURFACE, 22));
            sheet.setPadding(Ui.dp(a, 18), Ui.dp(a, 14), Ui.dp(a, 18), Ui.dp(a, 14));
        }
        outerScroll = new Dialogs.MaxHeightScroll(a, (int) (Dialogs.screenHeight(a) * 0.96f));
        outerScroll.addView(sheet);
        setContentView(outerScroll);
        Window w = getWindow();
        w.setBackgroundDrawable(new ColorDrawable(0));
        w.setDimAmount(0.62f);
        w.setGravity(land ? Gravity.CENTER : Gravity.BOTTOM);
        w.setLayout(land ? Math.min(Dialogs.screenWidth(a) - Ui.dp(a, 40), Ui.dp(a, 820)) : Math.min(Dialogs.screenWidth(a), Ui.dp(a, 560)), ViewGroup.LayoutParams.WRAP_CONTENT);
        w.getAttributes().windowAnimations = 0;

        rebuild();
        playButton.setForeground(Ui.focusRing(a, 23));
        playButton.requestFocus();
    }

    @Override
    public boolean dispatchKeyEvent(android.view.KeyEvent e) {
        android.view.KeyEvent m = Ui.padKey(e);
        return super.dispatchKeyEvent(m != null ? m : e);
    }

    @Override
    protected void onStart() {
        super.onStart();
        outerScroll.setTranslationY(Ui.dp(host, 420));
        outerScroll.animate().translationY(0).setDuration(260).setInterpolator(new DecelerateInterpolator(1.6f)).start();
    }

    // ---- drag the sheet down to close it ----------------------------------------------------

    private void attachDrag(View... grips) {
        View.OnTouchListener l = new View.OnTouchListener() {
            private float startY;
            private boolean dragging;
            private android.view.VelocityTracker vt;

            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                switch (e.getActionMasked()) {
                    case android.view.MotionEvent.ACTION_DOWN:
                        startY = e.getRawY();
                        dragging = false;
                        // the sheet itself scrolls: without this it steals the gesture after a few pixels
                        if (v.getParent() != null) v.getParent().requestDisallowInterceptTouchEvent(true);
                        vt = android.view.VelocityTracker.obtain();
                        vt.addMovement(e);
                        return true;
                    case android.view.MotionEvent.ACTION_MOVE: {
                        if (vt == null) return false;
                        vt.addMovement(e);
                        float dy = e.getRawY() - startY;
                        if (!dragging && Math.abs(dy) > Ui.dp(host, 6)) dragging = true;
                        if (dragging) {
                            outerScroll.animate().cancel();
                            outerScroll.setTranslationY(Math.max(0, dy));
                            float f = Math.min(1f, Math.max(0f, dy / Math.max(1, outerScroll.getHeight())));
                            getWindow().setDimAmount(0.62f * (1f - f));
                        }
                        return true;
                    }
                    case android.view.MotionEvent.ACTION_UP:
                    case android.view.MotionEvent.ACTION_CANCEL: {
                        if (vt == null) return false;
                        vt.addMovement(e);
                        vt.computeCurrentVelocity(1000);
                        float vy = vt.getYVelocity();
                        vt.recycle();
                        vt = null;
                        float dy = outerScroll.getTranslationY();
                        boolean close = e.getActionMasked() == android.view.MotionEvent.ACTION_UP
                                && (dy > outerScroll.getHeight() * 0.28f || vy > 1400);
                        if (close) {
                            outerScroll.animate().translationY(outerScroll.getHeight()).setDuration(160)
                                    .setInterpolator(new DecelerateInterpolator()).withEndAction(() -> dismiss()).start();
                        } else {
                            outerScroll.animate().translationY(0).setDuration(180).setInterpolator(new DecelerateInterpolator(1.5f)).start();
                            getWindow().setDimAmount(0.62f);
                        }
                        return true;
                    }
                }
                return true;
            }
        };
        for (View g : grips) g.setOnTouchListener(l);
    }

    // ---- cover -------------------------------------------------------------------------

    private void refreshCover() {
        android.graphics.Bitmap b = CoverStore.peek(host, rom.name, this::refreshCover);
        boolean has = CoverStore.has(host, rom.name);
        coverThumb.setImageBitmap(b);
        coverStatus.setText(coverBusy ? Lang.t("Downloading…") : has ? Lang.t("Cover saved") : Lang.t("No cover yet"));
        coverRemove.setVisibility(has && !coverBusy ? View.VISIBLE : View.GONE);
        coverDl.setEnabled(!coverBusy);
        coverDl.setAlpha(coverBusy ? 0.5f : 1f);
    }

    private void downloadCover() {
        if (coverBusy) return;
        coverBusy = true;
        refreshCover();
        final android.content.Context app = host.getApplicationContext();
        new Thread(() -> {
            final boolean ok = CoverStore.download(app, rom.name, rom.title, rom.main);
            host.runOnUiThread(() -> {
                coverBusy = false;
                if (isShowing()) {
                    refreshCover();
                    if (!ok) coverStatus.setText(Lang.t("No cover found online for this game. Try From phone."));
                }
                host.refreshList();
            });
        }).start();
    }

    // ---- data --------------------------------------------------------------------------

    private void scanScripts() {
        paths.clear();
        reports.clear();
        List<String> found = new ArrayList<>();
        findScripts(new File(Prefs.luaDir(host)), 0, found, new int[]{0});
        for (String p : found) {
            if (paths.size() >= 14) break;
            paths.add(p);
            reports.put(p, LuaTools.check(new File(p), rom.name));
        }
    }

    private static final String[] SKIP_DIRS = {"src", "lib", "libs", "data", "tools", "docs", "images", "img", "assets", "resources", "saved"};

    private static void findScripts(File dir, int depth, List<String> out, int[] visited) {
        File[] l = dir.listFiles();
        if (l == null || depth > 2) return;
        java.util.Arrays.sort(l, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        for (File f : l) {
            if (visited[0]++ > 3000) return;
            String n = f.getName();
            if (n.startsWith(".")) continue;
            if (f.isDirectory()) {
                boolean skip = false;
                for (String s : SKIP_DIRS) if (n.equalsIgnoreCase(s)) skip = true;
                if (!skip) findScripts(f, depth + 1, out, visited);
            } else if (n.toLowerCase(Locale.ROOT).endsWith(".lua")) {
                out.add(f.getAbsolutePath());
            }
        }
    }

    private String label(String p) {
        String base = Prefs.luaDir(host);
        if (p.startsWith(base)) return p.substring(base.length());
        File f = new File(p);
        File par = f.getParentFile();
        return par != null ? par.getName() + "/" + f.getName() : f.getName();
    }

    // ---- views -------------------------------------------------------------------------

    private void rebuild() {
        rebuildList();
        rebuildDiag();
        LuaTools.Report r = selected.length() > 0 ? reports.get(selected) : null;
        playButton.setText(r != null && !r.ok() ? Lang.t("Play anyway") : Lang.t("Play"));
    }

    private View optionRow(boolean sel, int iconKind, String title, String sub, int subColor, View.OnClickListener click) {
        LauncherActivity a = host;
        LinearLayout r = Ui.horizontal(a);
        GradientDrawable base = sel ? Ui.outlined(a, Ui.ACCENT_DIM, Ui.ACCENT, 14) : Ui.rounded(a, Ui.SURFACE2, 14);
        r.setBackground(Ui.ripple(a, base, 14));
        r.setPadding(Ui.dp(a, 12), Ui.dp(a, 9), Ui.dp(a, 12), Ui.dp(a, 9));
        r.setForeground(Ui.focusRing(a, 14));
        ImageView lead;
        if (sel) {
            lead = Ui.icon(a, Icons.CHECK, Ui.ACCENT, 20);
        } else {
            lead = Ui.icon(a, iconKind, Ui.SUB, 20);
        }
        LinearLayout.LayoutParams lpp = new LinearLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20));
        lpp.rightMargin = Ui.dp(a, 12);
        lead.setLayoutParams(lpp);
        r.addView(lead);
        LinearLayout col = Ui.vertical(a);
        TextView t = Ui.text(a, title, 14, Ui.TEXT, sel);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        col.addView(t);
        if (sub != null && sub.length() > 0) {
            TextView s = Ui.text(a, sub, 12, subColor, false);
            s.setPadding(0, Ui.dp(a, 3), 0, 0);
            s.setLineSpacing(0, 1.1f);
            col.addView(s);
        }
        r.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.setClickable(true);
        r.setFocusable(true);
        r.setOnClickListener(click);
        r.setLayoutParams(Ui.fillMargins(a, 0, 0, 0, 5));
        return r;
    }

    private void rebuildList() {
        list.removeAllViews();
        list.addView(optionRow(selected.length() == 0, Icons.PLAY, Lang.t("No script"), Lang.t("Play the game normally"), Ui.SUB, v -> {
            selected = "";
            rebuild();
        }));
        boolean haveTraining = false;
        for (final String p : paths) {
            LuaTools.Report rep = reports.get(p);
            String name = new File(p).getName();
            if (name.equals(LuaTools.TRAINING_SCRIPT) && rep != null && rep.ok()) haveTraining = true;
            String sub = null;
            int col = Ui.SUB;
            if (rep != null && !rep.ok()) { sub = LuaTools.describeMissing(rep); col = Ui.WARN; }
            else if (rep != null && !rep.notes.isEmpty()) { sub = rep.notes.get(0); col = Ui.SUB; }
            list.addView(optionRow(p.equals(selected), Icons.SCRIPT, label(p), sub, col, v -> {
                selected = p;
                rebuild();
            }));
        }
        if (rom.name.toLowerCase(Locale.ROOT).startsWith("sfiii") && !haveTraining) {
            String sub = installing ? installStatus : Lang.t("Downloads the complete script folder from GitHub (about 1 MB)");
            list.addView(optionRow(false, Icons.DOWNLOAD, Lang.t("Download 3rd Strike training mode"), sub, Ui.SUB, v -> install()));
        }
        if (LuaTools.isJojo(rom.name)) {
            boolean haveJojo = false;
            for (String q : paths) { LuaTools.Report rr = reports.get(q); if (LuaTools.isJojoScript(q) && rr != null && rr.ok()) haveJojo = true; }
            if (!haveJojo) {
                String sub = installing ? installStatus : Lang.t("Downloads the JoJoban training mode from GitHub and sets it up");
                list.addView(optionRow(false, Icons.DOWNLOAD, Lang.t("Download JoJo training mode"), sub, Ui.SUB, v -> install()));
            }
        }
        list.addView(optionRow(false, Icons.FOLDER, Lang.t("Browse for a script…"), null, Ui.SUB, v -> {
            dismiss();
            host.browseForScript(rom);
        }));
    }

    private void rebuildDiag() {
        diag.removeAllViews();
        LauncherActivity a = host;
        if (installError.length() > 0) {
            diag.addView(infoCard(Icons.WARN, Ui.WARN, Ui.WARN_DIM, installError, null, null));
        }
        if (selected.length() == 0) return;
        LuaTools.Report rep = reports.get(selected);
        if (rep == null) return;
        if (!rep.ok()) {
            String msg = LuaTools.describeMissing(rep)
                    + Lang.t("\n\nLua scripts like this come as a folder: copy the whole folder, not just the .lua file, ")
                    + Lang.t("or let FBNeo download it.");
            String sn = new File(selected).getName();
            boolean training = sn.equals(LuaTools.TRAINING_SCRIPT) || LuaTools.isJojoScript(selected);
            diag.addView(infoCard(Icons.WARN, Ui.WARN, Ui.WARN_DIM, msg,
                    training ? Lang.t("Download full package") : null,
                    v -> install()));
        }
        for (String n : rep.notes) {
            diag.addView(infoCard(Icons.INFO, Ui.ACCENT, Ui.SURFACE2, n, null, null));
        }
    }

    private View infoCard(int icon, int iconColor, int bg, String text, String action, View.OnClickListener click) {
        LauncherActivity a = host;
        LinearLayout c = Ui.vertical(a);
        c.setBackground(Ui.rounded(a, bg, 14));
        c.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
        LinearLayout top = new LinearLayout(a);
        top.setOrientation(LinearLayout.HORIZONTAL);
        ImageView ic = Ui.icon(a, icon, iconColor, 20);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20));
        ip.rightMargin = Ui.dp(a, 12);
        ip.topMargin = Ui.dp(a, 1);
        ic.setLayoutParams(ip);
        top.addView(ic);
        TextView t = Ui.text(a, text, 13, Ui.TEXT, false);
        t.setLineSpacing(0, 1.15f);
        top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        c.addView(top);
        if (action != null) {
            TextView b = Ui.button(a, action, Ui.TONAL, click);
            c.addView(b, Ui.wrapMargins(a, 32, 10, 0, 0));
        }
        c.setLayoutParams(Ui.fillMargins(a, 0, 0, 0, 8));
        return c;
    }

    // ---- download ----------------------------------------------------------------------

    private void install() {
        if (installing) return;
        installing = true;
        installError = "";
        installStatus = Lang.t("Downloading…");
        rebuild();
        final String luaDir = Prefs.luaDir(host);
        new Thread(() -> {
            try {
                LuaTools.Progress pr = what -> host.runOnUiThread(() -> {
                    installStatus = what;
                    if (isShowing()) rebuildList();
                });
                final File script = LuaTools.isJojo(rom.name) ? LuaTools.installJojo(luaDir, pr) : LuaTools.installTraining(luaDir, pr);
                host.runOnUiThread(() -> {
                    installing = false;
                    scanScripts();
                    selected = script.getAbsolutePath();
                    if (!paths.contains(selected)) {
                        paths.add(0, selected);
                        reports.put(selected, LuaTools.check(script, rom.name));
                    }
                    if (isShowing()) rebuild();
                });
            } catch (final Exception e) {
                host.runOnUiThread(() -> {
                    installing = false;
                    installError = Lang.t("Download failed: ") + e.getMessage()
                            + Lang.t("\nCheck your internet connection, or copy the script folder to ") + luaDir + Lang.t(" yourself.");
                    if (isShowing()) rebuild();
                });
            }
        }).start();
    }
}
