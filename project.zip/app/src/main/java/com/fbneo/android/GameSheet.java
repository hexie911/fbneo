package com.fbneo.android;

import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Bottom sheet shown when a game is tapped: choose a Lua script, then play. */
final class GameSheet extends Dialog {
    private final LauncherActivity host;
    private final LauncherActivity.Rom rom;
    private final List<String> paths = new ArrayList<>();
    private final Map<String, LuaTools.Report> reports = new HashMap<>();
    private String selected = "";
    private boolean remember = true;
    private boolean installing;
    private String installStatus = "";
    private String installError = "";

    private LinearLayout sheet, list, diag;
    private TextView playButton;
    private ScrollView outerScroll;

    GameSheet(LauncherActivity host, LauncherActivity.Rom rom) {
        super(host);
        this.host = host;
        this.rom = rom;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        final LauncherActivity a = host;

        // which script is selected at start
        String remembered = Prefs.romScript(a, rom.name);
        String wanted = remembered != null ? remembered : Prefs.defaultLua(a);
        scanScripts();
        if (wanted.length() > 0 && new File(wanted).isFile()) {
            if (!paths.contains(wanted)) { paths.add(0, wanted); reports.put(wanted, LuaTools.check(new File(wanted), rom.name)); }
            selected = wanted;
        }

        sheet = Ui.vertical(a);
        float r = Ui.dp(a, 28);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Ui.SURFACE);
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        sheet.setBackground(bg);
        sheet.setPadding(Ui.dp(a, 20), Ui.dp(a, 10), Ui.dp(a, 20), Ui.dp(a, 16));

        View handle = new View(a);
        handle.setBackground(Ui.rounded(a, Ui.OUTLINE, 3));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(Ui.dp(a, 36), Ui.dp(a, 4));
        hp.gravity = Gravity.CENTER_HORIZONTAL;
        hp.bottomMargin = Ui.dp(a, 14);
        sheet.addView(handle, hp);

        TextView title = Ui.text(a, rom.main, 21, Ui.TEXT, true);
        title.setLineSpacing(0, 1.05f);
        sheet.addView(title);
        if (rom.detail.length() > 0) {
            TextView d = Ui.text(a, rom.detail, 13, Ui.SUB, false);
            d.setPadding(0, Ui.dp(a, 4), 0, 0);
            sheet.addView(d);
        }
        LinearLayout chips = Ui.horizontal(a);
        chips.addView(Ui.chip(a, rom.name + ".zip", Ui.TEXT, Ui.SURFACE2));
        if (rom.year.length() > 0) chips.addView(Ui.chip(a, rom.year, Ui.TEXT, Ui.SURFACE2), Ui.wrapMargins(a, 8, 0, 0, 0));
        if (rom.maker.length() > 0) {
            TextView m = Ui.chip(a, rom.maker, Ui.TEXT, Ui.SURFACE2);
            m.setSingleLine(true);
            m.setEllipsize(android.text.TextUtils.TruncateAt.END);
            chips.addView(m, Ui.wrapMargins(a, 8, 0, 0, 0));
        }
        sheet.addView(chips, Ui.fillMargins(a, 0, 12, 0, 0));

        LinearLayout inner = Ui.vertical(a);
        TextView sec = Ui.text(a, "LUA SCRIPT", 11, Ui.ACCENT, true);
        sec.setLetterSpacing(0.1f);
        sec.setPadding(0, Ui.dp(a, 20), 0, Ui.dp(a, 8));
        inner.addView(sec);
        list = Ui.vertical(a);
        inner.addView(list);
        diag = Ui.vertical(a);
        inner.addView(diag, Ui.fillMargins(a, 0, 8, 0, 0));
        sheet.addView(inner);

        if (rom.neo && !rom.bios) {
            View q = Ui.switchRow(a, "Home console mode (AES)",
                    "Starts as a Neo Geo home console, with its practice and options menus. Needs the AES BIOS in neogeo.zip",
                    Prefs.aes(a, rom.name), (v, on) -> Prefs.setAes(host, rom.name, on));
            sheet.addView(q, Ui.fillMargins(a, 0, 12, 0, 0));
        }
        sheet.addView(Ui.switchRow(a, "Remember for this game", null, true, (v, on) -> remember = on),
                new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ((LinearLayout.LayoutParams) sheet.getChildAt(sheet.getChildCount() - 1).getLayoutParams()).setMargins(0, Ui.dp(a, 12), 0, 0);

        playButton = Ui.button(a, "Play", Ui.FILLED, v -> {
            dismiss();
            host.play(rom, selected, remember);
        });
        playButton.setTextSize(17);
        playButton.setMinHeight(Ui.dp(a, 54));
        playButton.setCompoundDrawablesWithIntrinsicBounds(null, null, null, null);
        sheet.addView(playButton, Ui.fillMargins(a, 0, 12, 0, 0));

        outerScroll = new Dialogs.MaxHeightScroll(a, (int) (Dialogs.screenHeight(a) * 0.96f));
        outerScroll.addView(sheet);
        setContentView(outerScroll);
        Window w = getWindow();
        w.setBackgroundDrawable(new ColorDrawable(0));
        w.setDimAmount(0.62f);
        w.setGravity(Gravity.BOTTOM);
        w.setLayout(Math.min(Dialogs.screenWidth(a), Ui.dp(a, 560)), ViewGroup.LayoutParams.WRAP_CONTENT);
        w.getAttributes().windowAnimations = 0;

        rebuild();
    }

    @Override
    protected void onStart() {
        super.onStart();
        outerScroll.setTranslationY(Ui.dp(host, 420));
        outerScroll.animate().translationY(0).setDuration(260).setInterpolator(new DecelerateInterpolator(1.6f)).start();
    }

    // ---- data --------------------------------------------------------------------------

    private void scanScripts() {
        paths.clear();
        reports.clear();
        List<String> found = new ArrayList<>();
        findScripts(new File(Prefs.luaDir(host)), 0, found, new int[]{0});
        for (String p : found) {
            if (paths.size() >= 14) break;
            paths.add(p);
            reports.put(p, LuaTools.check(new File(p), rom.name));
        }
    }

    private static final String[] SKIP_DIRS = {"src", "lib", "libs", "data", "tools", "docs", "images", "img", "assets", "resources", "saved"};

    private static void findScripts(File dir, int depth, List<String> out, int[] visited) {
        File[] l = dir.listFiles();
        if (l == null || depth > 2) return;
        java.util.Arrays.sort(l, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        for (File f : l) {
            if (visited[0]++ > 3000) return;
            String n = f.getName();
            if (n.startsWith(".")) continue;
            if (f.isDirectory()) {
                boolean skip = false;
                for (String s : SKIP_DIRS) if (n.equalsIgnoreCase(s)) skip = true;
                if (!skip) findScripts(f, depth + 1, out, visited);
            } else if (n.toLowerCase(Locale.ROOT).endsWith(".lua")) {
                out.add(f.getAbsolutePath());
            }
        }
    }

    private String label(String p) {
        String base = Prefs.luaDir(host);
        if (p.startsWith(base)) return p.substring(base.length());
        File f = new File(p);
        File par = f.getParentFile();
        return par != null ? par.getName() + "/" + f.getName() : f.getName();
    }

    // ---- views -------------------------------------------------------------------------

    private void rebuild() {
        rebuildList();
        rebuildDiag();
        LuaTools.Report r = selected.length() > 0 ? reports.get(selected) : null;
        playButton.setText(r != null && !r.ok() ? "Play anyway" : "Play");
    }

    private View optionRow(boolean sel, int iconKind, String title, String sub, int subColor, View.OnClickListener click) {
        LauncherActivity a = host;
        LinearLayout r = Ui.horizontal(a);
        GradientDrawable base = sel ? Ui.outlined(a, Ui.ACCENT_DIM, Ui.ACCENT, 14) : Ui.rounded(a, Ui.SURFACE2, 14);
        r.setBackground(Ui.ripple(a, base, 14));
        r.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
        ImageView lead;
        if (sel) {
            lead = Ui.icon(a, Icons.CHECK, Ui.ACCENT, 20);
        } else {
            lead = Ui.icon(a, iconKind, Ui.SUB, 20);
        }
        LinearLayout.LayoutParams lpp = new LinearLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20));
        lpp.rightMargin = Ui.dp(a, 12);
        lead.setLayoutParams(lpp);
        r.addView(lead);
        LinearLayout col = Ui.vertical(a);
        TextView t = Ui.text(a, title, 15, sel ? Ui.TEXT : Ui.TEXT, sel);
        t.setSingleLine(true);
        t.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        col.addView(t);
        if (sub != null && sub.length() > 0) {
            TextView s = Ui.text(a, sub, 12, subColor, false);
            s.setPadding(0, Ui.dp(a, 3), 0, 0);
            s.setLineSpacing(0, 1.1f);
            col.addView(s);
        }
        r.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        r.setClickable(true);
        r.setFocusable(true);
        r.setOnClickListener(click);
        r.setLayoutParams(Ui.fillMargins(a, 0, 0, 0, 8));
        return r;
    }

    private void rebuildList() {
        list.removeAllViews();
        list.addView(optionRow(selected.length() == 0, Icons.PLAY, "No script", "Play the game normally", Ui.SUB, v -> {
            selected = "";
            rebuild();
        }));
        boolean haveTraining = false, haveTrial = false;
        for (final String p : paths) {
            LuaTools.Report rep = reports.get(p);
            String name = new File(p).getName();
            if (name.equals(LuaTools.TRAINING_SCRIPT) && rep != null && rep.ok()) haveTraining = true;
            if (name.equals(LuaTools.TRIAL_SCRIPT) && rep != null && rep.ok()) haveTrial = true;
            String sub = null;
            int col = Ui.SUB;
            if (rep != null && !rep.ok()) { sub = LuaTools.describeMissing(rep); col = Ui.WARN; }
            else if (rep != null && !rep.notes.isEmpty()) { sub = rep.notes.get(0); col = Ui.SUB; }
            list.addView(optionRow(p.equals(selected), Icons.SCRIPT, label(p), sub, col, v -> {
                selected = p;
                rebuild();
            }));
        }
        if (rom.name.toLowerCase(Locale.ROOT).startsWith("sfiii") && !haveTraining) {
            String sub = installing ? installStatus : "Downloads the complete script folder from GitHub (about 1 MB)";
            list.addView(optionRow(false, Icons.DOWNLOAD, "Download 3rd Strike training mode", sub, Ui.SUB, v -> install(false)));
        }
        if (rom.name.toLowerCase(Locale.ROOT).startsWith("sfiii3") && !haveTrial) {
            String sub = installing ? installStatus : "Combo trials by Crystal Cube 99. Big download (about 140 MB): use Wi-Fi";
            list.addView(optionRow(false, Icons.DOWNLOAD, "Download 3rd Strike combo trials", sub, Ui.SUB, v -> install(true)));
        }
        list.addView(optionRow(false, Icons.FOLDER, "Browse for a script…", null, Ui.SUB, v -> {
            dismiss();
            host.browseForScript(rom);
        }));
    }

    private void rebuildDiag() {
        diag.removeAllViews();
        LauncherActivity a = host;
        if (installError.length() > 0) {
            diag.addView(infoCard(Icons.WARN, Ui.WARN, Ui.WARN_DIM, installError, null, null));
        }
        if (selected.length() == 0) return;
        LuaTools.Report rep = reports.get(selected);
        if (rep == null) return;
        if (!rep.ok()) {
            String msg = LuaTools.describeMissing(rep)
                    + "\n\nLua scripts like this come as a folder: copy the whole folder, not just the .lua file, "
                    + "or let FBNeo download it.";
            String sn = new File(selected).getName();
            boolean training = sn.equals(LuaTools.TRAINING_SCRIPT);
            boolean trial = sn.equals(LuaTools.TRIAL_SCRIPT);
            diag.addView(infoCard(Icons.WARN, Ui.WARN, Ui.WARN_DIM, msg,
                    training ? "Download full package" : trial ? "Download the trial package (about 140 MB)" : null,
                    v -> install(trial)));
        }
        for (String n : rep.notes) {
            diag.addView(infoCard(Icons.INFO, Ui.ACCENT, Ui.SURFACE2, n, null, null));
        }
    }

    private View infoCard(int icon, int iconColor, int bg, String text, String action, View.OnClickListener click) {
        LauncherActivity a = host;
        LinearLayout c = Ui.vertical(a);
        c.setBackground(Ui.rounded(a, bg, 14));
        c.setPadding(Ui.dp(a, 14), Ui.dp(a, 12), Ui.dp(a, 14), Ui.dp(a, 12));
        LinearLayout top = new LinearLayout(a);
        top.setOrientation(LinearLayout.HORIZONTAL);
        ImageView ic = Ui.icon(a, icon, iconColor, 20);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20));
        ip.rightMargin = Ui.dp(a, 12);
        ip.topMargin = Ui.dp(a, 1);
        ic.setLayoutParams(ip);
        top.addView(ic);
        TextView t = Ui.text(a, text, 13, Ui.TEXT, false);
        t.setLineSpacing(0, 1.15f);
        top.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        c.addView(top);
        if (action != null) {
            TextView b = Ui.button(a, action, Ui.TONAL, click);
            c.addView(b, Ui.wrapMargins(a, 32, 10, 0, 0));
        }
        c.setLayoutParams(Ui.fillMargins(a, 0, 0, 0, 8));
        return c;
    }

    // ---- download ----------------------------------------------------------------------

    private void install(final boolean trial) {
        if (installing) return;
        installing = true;
        installError = "";
        installStatus = "Downloading…";
        rebuild();
        final String luaDir = Prefs.luaDir(host);
        new Thread(() -> {
            try {
                LuaTools.Progress pr = what -> host.runOnUiThread(() -> {
                    installStatus = what;
                    if (isShowing()) rebuildList();
                });
                final File script = trial ? LuaTools.installTrial(host, luaDir, pr) : LuaTools.installTraining(luaDir, pr);
                host.runOnUiThread(() -> {
                    installing = false;
                    scanScripts();
                    selected = script.getAbsolutePath();
                    if (!paths.contains(selected)) {
                        paths.add(0, selected);
                        reports.put(selected, LuaTools.check(script, rom.name));
                    }
                    if (isShowing()) rebuild();
                });
            } catch (final Exception e) {
                host.runOnUiThread(() -> {
                    installing = false;
                    installError = "Download failed: " + e.getMessage()
                            + "\nCheck your internet connection, or copy the script folder to " + luaDir + " yourself.";
                    if (isShowing()) rebuild();
                });
            }
        }).start();
    }
}
