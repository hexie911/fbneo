package com.fbneo.android;

import android.app.Activity;
import android.app.Application;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.Window;

/** Loads the chosen colour theme before any screen is built and paints the system bars with it. */
public class App extends Application {
    @Override public void onCreate() {
        super.onCreate();
        try { Ui.loadTheme(this); } catch (RuntimeException e) { /* keep the default theme */ }
        registerActivityLifecycleCallbacks(new ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(Activity a, Bundle b) {
                if (a instanceof GameActivity || a instanceof MameActivity) return;
                try {
                    Window w = a.getWindow();
                    w.setBackgroundDrawable(new ColorDrawable(Ui.BG));
                    w.setStatusBarColor(Ui.BG);
                    w.setNavigationBarColor(Ui.BG);
                    View d = w.getDecorView();
                    int f = d.getSystemUiVisibility();
                    int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    d.setSystemUiVisibility(Ui.DARK ? (f & ~light) : (f | light));
                } catch (RuntimeException e) { /* cosmetic only */ }
            }
            @Override public void onActivityStarted(Activity a) { }
            @Override public void onActivityResumed(Activity a) { }
            @Override public void onActivityPaused(Activity a) { }
            @Override public void onActivityStopped(Activity a) { }
            @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
            @Override public void onActivityDestroyed(Activity a) { }
        });
    }
}
