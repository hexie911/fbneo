package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;

/** The side menu behind the three dot button: switches between the FBNeo, MAME and Flycast sections. */
final class SideMenu {
    private SideMenu() {}

    static final int FBNEO = 0, MAME = 1, FLYCAST = 2;

    static void show(final Activity a, final int current) {
        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout col = Ui.vertical(a);
        col.setBackgroundColor(Ui.SURFACE);
        col.setPadding(Ui.dp(a, 12), Ui.dp(a, 28), Ui.dp(a, 12), Ui.dp(a, 12));
        col.addView(Ui.text(a, "Emulators", 22, Ui.TEXT, true), Ui.fillMargins(a, 8, 0, 8, 14));
        String[] names = {"FBNeo", "MAME", "Flycast"};
        String[] subs = {"Arcade (CPS, Neo Geo...)", "Arcade through a libretro core", "Dreamcast, Naomi, Atomiswave"};
        for (int i = 0; i < 3; i++) {
            final int which = i;
            LinearLayout r = Ui.vertical(a);
            r.setPadding(Ui.dp(a, 16), Ui.dp(a, 12), Ui.dp(a, 16), Ui.dp(a, 12));
            r.setBackground(Ui.rounded(a, i == current ? Ui.SURFACE2 : Ui.SURFACE, 16));
            r.addView(Ui.text(a, names[i], 17, i == current ? Ui.ACCENT : Ui.TEXT, true));
            r.addView(Ui.text(a, subs[i], 12, Ui.SUB, false));
            r.setClickable(true);
            r.setOnClickListener(v -> {
                d.dismiss();
                if (which != current) go(a, current, which);
            });
            col.addView(r, Ui.fillMargins(a, 0, 4, 0, 4));
        }
        d.setContentView(col);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setGravity(Gravity.END | Gravity.TOP);
            w.setLayout(Ui.dp(a, 290), ViewGroup.LayoutParams.MATCH_PARENT);
            w.setWindowAnimations(android.R.style.Animation_InputMethod);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        d.show();
    }

    private static void go(Activity a, int from, int to) {
        Intent i;
        if (to == FBNEO) {
            i = new Intent(a, LauncherActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            a.startActivity(i);
            if (from != FBNEO) a.finish();
            return;
        }
        i = new Intent(a, to == MAME ? MameLauncherActivity.class : FlycastLauncherActivity.class);
        a.startActivity(i);
        if (from != FBNEO) a.finish();
    }
}
