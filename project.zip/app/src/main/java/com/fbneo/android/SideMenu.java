package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

/** The side menu behind the three dot button: switches between the FBNeo, MAME section. */
final class SideMenu {
    private SideMenu() {}

    static final int FBNEO = 0, MAME = 1;

    static void show(final Activity a, final int current) { show(a, current, null, null, null); }

    /** With options: a first block of actions for the section the person is in. */
    static void show(final Activity a, final int current, String[] labels, final Runnable[] actions, String info) {
        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout col = Ui.vertical(a);
        col.setBackgroundColor(Ui.SURFACE);
        col.setPadding(Ui.dp(a, 12), Ui.dp(a, 16), Ui.dp(a, 12), Ui.dp(a, 12));
        android.widget.ScrollView sv = new android.widget.ScrollView(a);
        sv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        sv.setBackgroundColor(Ui.SURFACE);
        sv.addView(col);
        if (labels != null) {
            col.addView(Ui.text(a, current == MAME ? "MAME" : "FBNeo", 20, Ui.TEXT, true), Ui.fillMargins(a, 8, 0, 8, 2));
            if (info != null && info.length() > 0) {
                TextView it = Ui.text(a, info, 12, Ui.SUB, false);
                it.setSingleLine(false);
                col.addView(it, Ui.fillMargins(a, 8, 0, 8, 8));
            }
            for (int i = 0; i < labels.length; i++) {
                final int idx = i;
                TextView b = Ui.button(a, labels[i], Ui.TONAL, v -> { d.dismiss(); actions[idx].run(); });
                b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
                col.addView(b, Ui.fillMargins(a, 0, 3, 0, 3));
            }
            col.addView(Ui.text(a, Lang.t("Emulators"), 14, Ui.SUB, true), Ui.fillMargins(a, 8, 14, 8, 4));
        } else {
            col.addView(Ui.text(a, Lang.t("Emulators"), 22, Ui.TEXT, true), Ui.fillMargins(a, 8, 0, 8, 14));
        }
        String[] names = {"FBNeo", "MAME"};
        String[] subs = {Lang.t("Arcade (CPS, Neo Geo...)"), Lang.t("Arcade through a libretro core")};
        for (int i = 0; i < 2; i++) {
            final int which = i;
            LinearLayout r = Ui.vertical(a);
            r.setPadding(Ui.dp(a, 14), Ui.dp(a, 8), Ui.dp(a, 14), Ui.dp(a, 8));
            r.setFocusable(true);
            r.setBackground(Ui.rounded(a, i == current ? Ui.SURFACE2 : Ui.SURFACE, 16));
            r.addView(Ui.text(a, names[i], 17, i == current ? Ui.ACCENT : Ui.TEXT, true));
            r.addView(Ui.text(a, subs[i], 12, Ui.SUB, false));
            r.setClickable(true);
            r.setOnClickListener(v -> {
                d.dismiss();
                if (which != current) go(a, current, which);
            });
            col.addView(r, Ui.fillMargins(a, 0, 4, 0, 4));
        }
        d.setContentView(sv);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setGravity(Gravity.END | Gravity.TOP);
            w.setLayout(Ui.dp(a, 290), ViewGroup.LayoutParams.MATCH_PARENT);
            w.setWindowAnimations(android.R.style.Animation_InputMethod);
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
        d.show();
    }

    private static void go(Activity a, int from, int to) {
        Intent i;
        if (to == FBNEO) {
            i = new Intent(a, LauncherActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            a.startActivity(i);
            if (from != FBNEO) a.finish();
            return;
        }
        i = new Intent(a, MameLauncherActivity.class);
        a.startActivity(i);
        if (from != FBNEO) a.finish();
    }
}
