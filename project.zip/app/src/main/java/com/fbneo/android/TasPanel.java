package com.fbneo.android;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

/**
 * The TAS tools panel: a bar on top of the game with frame advance, slow motion, save slots (with undo / redo),
 * movie recording and playback, turbo / hold buttons, and the memory tools. The game keeps running
 * underneath, the panel is a plain view (not a dialog) so it never takes the window focus.
 */
final class TasPanel {
    private final Activity a;
    private final String game;
    private final Handler h = new Handler(Looper.getMainLooper());
    private LinearLayout root;
    private TextView hud, note;
    private TextView bPause, bSpeed, bSlot, bRec, bRo, bTake, bUndo, bRedo;
    private boolean shown;
    private int slot;
    private int lastSeq = -1;
    private long lastWatch;
    private String watchText = "";
    private String[] st = new String[16];

    TasPanel(Activity a, String game) {
        this.a = a;
        this.game = game;
    }

    boolean isShowing() { return shown; }

    void show() {
        if (shown) return;
        if (root == null) build();
        root.setVisibility(View.VISIBLE);
        shown = true;
        h.post(tick);
    }

    void hide() {
        shown = false;
        h.removeCallbacks(tick);
        if (root != null) root.setVisibility(View.GONE);
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!shown) return;
            refresh();
            h.postDelayed(this, 120);
        }
    };

    // ---- layout ---------------------------------------------------------------------------

    private TextView btn(String label, Runnable r) {
        TextView t = Ui.button(a, label, Ui.TONAL, v -> r.run());
        t.setTextSize(13);
        return t;
    }

    private void add(LinearLayout row, View v) {
        row.addView(v, Ui.wrapMargins(a, 0, 0, 6, 0));
    }

    private HorizontalScrollView scroller(LinearLayout row) {
        HorizontalScrollView s = new HorizontalScrollView(a);
        s.setHorizontalScrollBarEnabled(false);
        s.addView(row);
        return s;
    }

    private void build() {
        root = Ui.vertical(a);
        root.setBackground(Ui.rounded(a, 0xE6171A21, 16));
        int p = Ui.dp(a, 8);
        root.setPadding(p, Ui.dp(a, 6), p, p);

        hud = Ui.text(a, "", 12, Ui.TEXT, false);
        hud.setTypeface(Typeface.MONOSPACE);
        root.addView(hud);
        note = Ui.text(a, "", 12, Ui.ACCENT, false);
        root.addView(note);

        LinearLayout r1 = Ui.horizontal(a);
        bPause = btn(Lang.t("Pause"), () -> {
            boolean paused = "1".equals(st[2]);
            if (!checkNet()) return;
            Native.tasCmd(Native.T_PAUSE, paused ? 0 : 1, null);
        });
        add(r1, bPause);
        TextView step = btn(Lang.t("Step 1 frame"), () -> { });
        step.setOnTouchListener(new View.OnTouchListener() {
            private final Runnable rep = new Runnable() {
                @Override public void run() {
                    Native.tasCmd(Native.T_STEP, 1, null);
                    h.postDelayed(this, 70);
                }
            };
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        if (!checkNet()) return true;
                        v.setPressed(true);
                        Native.tasCmd(Native.T_STEP, 1, null);
                        h.postDelayed(rep, 350);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.setPressed(false);
                        h.removeCallbacks(rep);
                        return true;
                }
                return true;
            }
        });
        add(r1, step);
        bSpeed = btn("100%", this::chooseSpeed);
        add(r1, bSpeed);
        bSlot = btn("", this::chooseSlot);
        add(r1, bSlot);
        add(r1, btn(Lang.t("Save"), () -> { if (checkNet()) Native.tasCmd(Native.T_SAVE, slot, null); }));
        add(r1, btn(Lang.t("Load"), () -> { if (checkNet()) Native.tasCmd(Native.T_LOAD, slot, null); }));
        bUndo = btn(Lang.t("Undo"), () -> { if (checkNet()) Native.tasCmd(Native.T_UNDO, 0, null); });
        add(r1, bUndo);
        bRedo = btn(Lang.t("Redo"), () -> { if (checkNet()) Native.tasCmd(Native.T_REDO, 0, null); });
        add(r1, bRedo);
        root.addView(scroller(r1), Ui.fillMargins(a, 0, 6, 0, 0));

        LinearLayout r2 = Ui.horizontal(a);
        bRec = btn("", () -> {
            if (!checkNet()) return;
            String m = st[1];
            if ("0".equals(m)) Native.tasCmd(Native.T_REC, 0, null);
            else Native.tasCmd(Native.T_STOP, 0, null);
        });
        add(r2, bRec);
        add(r2, btn(Lang.t("Movies"), this::chooseMovie));
        bRo = btn("", () -> {
            if (!checkNet()) return;
            Native.tasCmd(Native.T_READONLY, "1".equals(st[5]) ? 0 : 1, null);
        });
        add(r2, bRo);
        bTake = btn(Lang.t("Take over"), () -> Native.tasCmd(Native.T_TAKEOVER, 0, null));
        add(r2, bTake);
        add(r2, btn(Lang.t("Auto-fire"), () -> buttonsDialog(true, 0)));
        add(r2, btn(Lang.t("Auto-hold"), () -> buttonsDialog(false, 0)));
        add(r2, btn(Lang.t("Memory"), () -> MemoryDialog.show(a, game)));
        add(r2, btn(Lang.t("Close"), this::hide));
        root.addView(scroller(r2), Ui.fillMargins(a, 0, 6, 0, 0));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = Ui.dp(a, 4);
        int max = a.getResources().getDisplayMetrics().widthPixels - Ui.dp(a, 24);
        root.setMinimumWidth(Math.min(max, Ui.dp(a, 420)));
        a.addContentView(root, lp);
    }

    private boolean checkNet() {
        if ("1".equals(st[14])) {
            Ui.toast(a, Lang.t("TAS tools are off while playing together"));
            return false;
        }
        return true;
    }

    // ---- dialogs ----------------------------------------------------------------------------

    private void chooseSpeed() {
        final int[] v = {100, 75, 50, 25, 10};
        String[] names = new String[v.length];
        int sel = 0;
        int cur = parse(st[3], 100);
        for (int i = 0; i < v.length; i++) {
            names[i] = v[i] + "%" + (v[i] < 100 ? "  (" + Lang.t("no sound") + ")" : "");
            if (v[i] == cur) sel = i;
        }
        Dialogs.choose(a, Lang.t("Speed"), names, sel, i -> Native.tasSetSpeed(v[i]));
    }

    private void chooseSlot() {
        int mask = parse(st[11], 0);
        String[] names = new String[10];
        for (int i = 0; i < 10; i++) names[i] = Lang.t("Slot ") + (i + 1) + "  " + (((mask >> i) & 1) != 0 ? "•" : "-");
        Dialogs.choose(a, Lang.t("Save slot"), names, slot, i -> { slot = i; refresh(); });
    }

    private void chooseMovie() {
        if (!checkNet()) return;
        if (!"0".equals(st[1])) { Ui.toast(a, Lang.t("Stop the current movie first")); return; }
        String[] list;
        try { list = Native.tasMovies(); } catch (UnsatisfiedLinkError | RuntimeException e) { list = new String[0]; }
        if (list.length == 0) { Ui.toast(a, Lang.t("No movies recorded for this game yet")); return; }
        final String[] files = list;
        Dialogs.choose(a, Lang.t("Play a movie"), files, -1, i -> Native.tasCmd(Native.T_PLAY, 0, files[i]));
    }

    private static final String[] LABELS = {"Up", "Down", "Left", "Right", "Button 1  (LP)", "Button 2  (MP)", "Button 3  (HP)",
            "Button 4  (LK)", "Button 5  (MK)", "Button 6  (HK)", "Insert coin", "Start"};

    private void buttonsDialog(final boolean turbo, final int player) {
        final LinearLayout[] hh = new LinearLayout[1];
        final Dialog d = Dialogs.base(a, hh);
        LinearLayout card = hh[0];
        card.addView(Ui.text(a, turbo ? Lang.t("Auto-fire") : Lang.t("Auto-hold"), 22, Ui.TEXT, true));
        TextView info = Ui.text(a, turbo
                ? Lang.t("A held button is pressed and released every other frame. It is recorded into the movie.")
                : Lang.t("The button stays pressed without touching it. It is recorded into the movie."), 13, Ui.SUB, false);
        info.setPadding(0, Ui.dp(a, 4), 0, Ui.dp(a, 8));
        card.addView(info);
        LinearLayout tabs = Ui.horizontal(a);
        for (int pl = 0; pl < 2; pl++) {
            final int pp = pl;
            TextView t = Ui.button(a, Lang.t("Player ") + (pl + 1), pl == player ? Ui.FILLED : Ui.TONAL, v -> { d.dismiss(); buttonsDialog(turbo, pp); });
            tabs.addView(t, Ui.wrapMargins(a, 0, 0, 8, 0));
        }
        card.addView(tabs);
        final int[] mask = {Native.tasGetButtons(player, turbo)};
        LinearLayout list = Ui.vertical(a);
        for (int i = 0; i < LABELS.length; i++) {
            final int bit = i;
            list.addView(Ui.switchRow(a, Lang.t(LABELS[i]), "", ((mask[0] >> bit) & 1) != 0, (v, on) -> {
                if (on) mask[0] |= 1 << bit; else mask[0] &= ~(1 << bit);
                Native.tasSetButtons(player, turbo, mask[0]);
            }), Ui.fillMargins(a, 0, 4, 0, 0));
        }
        Dialogs.MaxHeightScroll sv = new Dialogs.MaxHeightScroll(a, (int) (Dialogs.screenHeight(a) * 0.55f));
        sv.addView(list);
        card.addView(sv, Ui.fillMargins(a, 0, 8, 0, 0));
        LinearLayout bar = Ui.horizontal(a);
        bar.setGravity(Gravity.END);
        bar.addView(Ui.button(a, Lang.t("Close"), Ui.TEXTONLY, v -> d.dismiss()));
        card.addView(bar, Ui.fillMargins(a, 0, 8, 0, 0));
        d.show();
    }

    // ---- live status -------------------------------------------------------------------------

    private static int parse(String s, int def) {
        try { return Integer.parseInt(s.trim()); } catch (RuntimeException e) { return def; }
    }

    private static String pad(int mask) {
        StringBuilder b = new StringBuilder();
        if ((mask & 1) != 0) b.append('↑');
        if ((mask & 2) != 0) b.append('↓');
        if ((mask & 4) != 0) b.append('←');
        if ((mask & 8) != 0) b.append('→');
        for (int i = 0; i < 6; i++) if ((mask & (16 << i)) != 0) b.append(i + 1);
        if ((mask & 1024) != 0) b.append('C');
        if ((mask & 2048) != 0) b.append('S');
        return b.length() == 0 ? "-" : b.toString();
    }

    private void refresh() {
        String s;
        try { s = Native.tasStatus(); } catch (UnsatisfiedLinkError | RuntimeException e) { return; }
        String[] p = s.split("\\|", 16);
        if (p.length < 16) return;
        st = p;
        int mode = parse(p[1], 0);
        boolean paused = "1".equals(p[2]);
        int speed = parse(p[3], 100);
        int frames = parse(p[0], 0);
        String m = mode == 1 ? Lang.t("REC") : mode == 2 ? Lang.t("PLAY") : "";
        StringBuilder b = new StringBuilder();
        b.append(Lang.t("Frame ")).append(frames);
        if (mode != 0) b.append('/').append(mode == 2 ? p[6] : "").append(mode == 2 ? "" : "");
        if (m.length() > 0) b.append("  ").append(m);
        if (paused) b.append("  ").append(Lang.t("PAUSED"));
        if (speed < 100) b.append("  ").append(speed).append('%');
        b.append("\n").append(Lang.t("Re-records ")).append(p[4]);
        b.append("   P1 ").append(pad(parse(p[7], 0))).append("   P2 ").append(pad(parse(p[8], 0)));
        long now = System.currentTimeMillis();
        if (now - lastWatch > 250 && !"1".equals(p[14])) {
            lastWatch = now;
            watchText = watches();
        }
        if (watchText.length() > 0) b.append("\n").append(watchText);
        hud.setText(b.toString());
        int seq = parse(p[13], 0);
        if (seq != lastSeq) { lastSeq = seq; note.setText(p[15]); }
        bPause.setText(paused ? Lang.t("Resume") : Lang.t("Pause"));
        bSpeed.setText(speed + "%");
        int mask = parse(p[11], 0);
        bSlot.setText(Lang.t("Slot ") + (slot + 1) + (((mask >> slot) & 1) != 0 ? " •" : ""));
        bRec.setText(mode == 0 ? Lang.t("Record") : Lang.t("Stop"));
        bRo.setText("1".equals(p[5]) ? Lang.t("Read-only") : Lang.t("Read / write"));
        bTake.setVisibility(mode == 2 ? View.VISIBLE : View.GONE);
        bUndo.setAlpha(parse(p[9], 0) != 0 ? 1f : 0.45f);
        bRedo.setAlpha(parse(p[10], 0) != 0 ? 1f : 0.45f);
    }

    private String watches() {
        List<MemoryDialog.Watch> w = MemoryDialog.loadWatches(a, game);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < w.size() && i < 5; i++) {
            MemoryDialog.Watch x = w.get(i);
            long v;
            try { v = Native.tasMemRead(x.addr, x.size); } catch (UnsatisfiedLinkError | RuntimeException e) { return ""; }
            if (b.length() > 0) b.append("  ");
            b.append(x.name).append(' ').append(MemoryDialog.format(v, x.size, x.signed));
        }
        return b.toString();
    }
}
