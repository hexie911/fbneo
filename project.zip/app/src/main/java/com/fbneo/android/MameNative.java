package com.fbneo.android;

import android.view.Surface;

/** JNI entry points of libmamehost.so (mamehost/): a small libretro frontend that runs the MAME core. */
final class MameNative {
    private MameNative() {}

    private static boolean sLoaded;
    static String loadError = "";

    static synchronized boolean loadLibraries() {
        if (sLoaded) return true;
        try {
            System.loadLibrary("mamehost");
            sLoaded = true;
        } catch (Throwable t) {
            loadError = String.valueOf(t.getMessage());
            sLoaded = false;
        }
        return sLoaded;
    }

    static native boolean load(String corePath, String systemDir, String saveDir);
    static native boolean loadGame(String romZipPath);
    static native void unload();
    static native boolean runFrame();
    /** width, height (after rotation), fps, audio rate, rotation (0-3), aspect ratio */
    static native double[] info();
    static native void setSurface(Surface s);
    static native boolean blit();
    /** Copies the audio the core produced (interleaved stereo shorts); returns how many shorts. */
    static native int audio(short[] out);
    /** audio callback calls: batch, single sample, total frames given by the core */
    static native long[] audioStats();
    static native void setButton(int port, int id, boolean down);
    static native void setOption(String key, String value);
    static native void reset();
    static native boolean saveState(String path);
    static native boolean loadState(String path);
    static native String log();
}
