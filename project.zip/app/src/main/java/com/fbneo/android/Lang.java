package com.fbneo.android;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.view.View;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Locale;

/** English / Português (Brasil) / Arabic. "auto" follows the phone's language when it is one of these, English otherwise. */
final class Lang {
    private Lang() {}

    private static boolean ar;               // right-to-left language
    private static String code = "en";      // language in use: en, pt or ar
    private static HashMap<String, String> map;

    /** Stored choice: "auto", "en", "pt" or "ar". */
    static String pref(Context c) {
        return Prefs.sp(c).getString("lang", "auto");
    }

    static void setPref(Context c, String v) {
        Prefs.sp(c).edit().putString("lang", v).commit();
    }

    /** The language to use: the stored choice, or for "auto" the phone's language when we have it. */
    static String resolve(Context c) {
        String p = pref(c);
        if ("ar".equals(p) || "pt".equals(p) || "en".equals(p)) return p;
        String l = Locale.getDefault().getLanguage();
        return "ar".equals(l) || "pt".equals(l) ? l : "en";
    }

    static boolean isArabic() { return ar; }

    static String code() { return code; }

    /** Name of a language in that language. */
    static String nameOf(String c) {
        return "ar".equals(c) ? "العربية" : "pt".equals(c) ? "Português (Brasil)" : "English";
    }

    /** Call from every Activity's attachBaseContext. */
    static Context wrap(Context base) {
        String want = resolve(base);
        if (!want.equals(code) || (!"en".equals(want) && map == null)) {
            code = want;
            map = null;
        }
        ar = "ar".equals(code);
        if (!"en".equals(code) && map == null) load(base);
        Locale loc = ar ? new Locale("ar") : "pt".equals(code) ? new Locale("pt", "BR") : Locale.ENGLISH;
        Locale.setDefault(loc);
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(loc);
        cfg.setLayoutDirection(loc);
        return base.createConfigurationContext(cfg);
    }

    private static void load(Context c) {
        HashMap<String, String> m = new HashMap<>();
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getAssets().open("lang_" + code + ".tsv"), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                int t = line.indexOf('\t');
                if (t > 0) m.put(unesc(line.substring(0, t)), unesc(line.substring(t + 1)));
            }
            r.close();
        } catch (Exception e) {
        }
        map = m;
    }

    private static String unesc(String s) {
        if (s.indexOf('\\') < 0) return s;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                b.append(n == 'n' ? '\n' : n == 't' ? '\t' : n);
            } else b.append(ch);
        }
        return b.toString();
    }

    /** Translate a known interface text. Unknown text is returned unchanged. */
    static String t(String s) {
        if (map == null || s == null) return s;
        String v = map.get(s);
        return v != null ? v : s;
    }

    /** Status text coming from the native code: translate it, or its known beginning. */
    static String status(String s) {
        if (map == null || s == null) return s;
        String v = map.get(s);
        if (v != null) return v;
        String best = null;
        for (String k : map.keySet()) {
            if (k.length() > 6 && s.startsWith(k) && (best == null || k.length() > best.length())) best = k;
        }
        return best == null ? s : map.get(best) + s.substring(best.length());
    }

    /** Keep a view (and its children) laid out left to right, e.g. the game screen. */
    static void forceLtr(View v) {
        v.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
    }
}
