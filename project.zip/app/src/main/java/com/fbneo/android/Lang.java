package com.fbneo.android;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.view.View;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Locale;

/** English / Arabic. "auto" follows the phone: Arabic if the phone is Arabic, English otherwise. */
final class Lang {
    private Lang() {}

    private static boolean ar;
    private static HashMap<String, String> map;

    /** Stored choice: "auto", "en" or "ar". */
    static String pref(Context c) {
        return Prefs.sp(c).getString("lang", "auto");
    }

    static void setPref(Context c, String v) {
        Prefs.sp(c).edit().putString("lang", v).commit();
    }

    static boolean resolveArabic(Context c) {
        String p = pref(c);
        if ("ar".equals(p)) return true;
        if ("en".equals(p)) return false;
        return "ar".equals(Locale.getDefault().getLanguage());
    }

    static boolean isArabic() { return ar; }

    /** Call from every Activity's attachBaseContext. */
    static Context wrap(Context base) {
        ar = resolveArabic(base);
        if (ar && map == null) load(base);
        Locale loc = ar ? new Locale("ar") : Locale.ENGLISH;
        Locale.setDefault(loc);
        Configuration cfg = new Configuration(base.getResources().getConfiguration());
        cfg.setLocale(loc);
        cfg.setLayoutDirection(loc);
        return base.createConfigurationContext(cfg);
    }

    private static void load(Context c) {
        HashMap<String, String> m = new HashMap<>();
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getAssets().open("lang_ar.tsv"), "UTF-8"));
            String line;
            while ((line = r.readLine()) != null) {
                int t = line.indexOf('\t');
                if (t > 0) m.put(unesc(line.substring(0, t)), unesc(line.substring(t + 1)));
            }
            r.close();
        } catch (Exception e) {
        }
        map = m;
    }

    private static String unesc(String s) {
        if (s.indexOf('\\') < 0) return s;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                b.append(n == 'n' ? '\n' : n == 't' ? '\t' : n);
            } else b.append(ch);
        }
        return b.toString();
    }

    /** Translate a known interface text. Unknown text is returned unchanged. */
    static String t(String s) {
        if (!ar || map == null || s == null) return s;
        String v = map.get(s);
        return v != null ? v : s;
    }

    /** Status text coming from the native code: translate it, or its known beginning. */
    static String status(String s) {
        if (!ar || map == null || s == null) return s;
        String v = map.get(s);
        if (v != null) return v;
        String best = null;
        for (String k : map.keySet()) {
            if (k.length() > 6 && s.startsWith(k) && (best == null || k.length() > best.length())) best = k;
        }
        return best == null ? s : map.get(best) + s.substring(best.length());
    }

    /** Keep a view (and its children) laid out left to right, e.g. the game screen. */
    static void forceLtr(View v) {
        v.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
    }
}
