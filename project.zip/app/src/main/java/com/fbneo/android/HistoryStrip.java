package com.fbneo.android;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.LruCache;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.OverScroller;
import android.widget.TextView;

import java.nio.ShortBuffer;

/**
 * The rewind history on screen: a strip of small pictures, oldest on the left, newest on the right. Tapping one
 * puts the game back in exactly that frame. It is a plain view on top of the game (not a dialog), so the game
 * keeps its window focus and can carry out the request.
 */
final class HistoryStrip {
    private final Activity a;
    private LinearLayout root;
    private TextView title;
    private StripView strip;
    private boolean shown;
    private long lastInfo;

    HistoryStrip(Activity a) { this.a = a; }

    boolean isShowing() { return shown; }

    private float alpha = 1f;

    void setAlpha(float v) {
        alpha = v;
        if (root != null) root.setAlpha(v);
    }

    void show() {
        if (root == null) build();
        root.setVisibility(View.VISIBLE);
        shown = true;
        update(true);
    }

    void hide() {
        shown = false;
        if (root != null) root.setVisibility(View.GONE);
    }

    private void build() {
        root = Ui.vertical(a);
        root.setBackground(Ui.rounded(a, 0xEE171A21, 14));
        int p = Ui.dp(a, 6);
        root.setPadding(p, p, p, p);
        LinearLayout head = Ui.horizontal(a);
        head.setGravity(Gravity.CENTER_VERTICAL);
        title = Ui.text(a, "", 12, Ui.TEXT, false);
        head.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        title.setOnTouchListener(new View.OnTouchListener() {
            private float y0, t0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: y0 = e.getRawY(); t0 = root.getTranslationY(); return true;
                    case MotionEvent.ACTION_MOVE: {
                        float lim = a.getResources().getDisplayMetrics().heightPixels - root.getHeight() - Ui.dp(a, 16);
                        root.setTranslationY(Math.max(-Math.max(0f, lim), Math.min(0f, t0 + (e.getRawY() - y0))));
                        return true;
                    }
                }
                return true;
            }
        });
        TextView end = Ui.button(a, Lang.t("Newest"), Ui.TONAL, v -> strip.toEnd());
        end.setTextSize(12);
        head.addView(end, Ui.wrapMargins(a, 0, 0, 6, 0));
        TextView close = Ui.button(a, Lang.t("Close"), Ui.TONAL, v -> hide());
        close.setTextSize(12);
        head.addView(close);
        root.addView(head);
        strip = new StripView();
        root.addView(strip, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, 92)));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        lp.leftMargin = lp.rightMargin = Ui.dp(a, 8);
        lp.bottomMargin = Ui.dp(a, 8);
        root.setAlpha(alpha);
        a.addContentView(root, lp);
    }

    /** called often by the panel; looks at the history a few times a second */
    void update(boolean force) {
        if (!shown) return;
        long now = System.currentTimeMillis();
        if (!force && now - lastInfo < 200) return;
        lastInfo = now;
        String s;
        try { s = Native.tasHistInfo(); } catch (UnsatisfiedLinkError | RuntimeException e) { return; }
        String[] p = s.split("\\|");
        if (p.length < 9) return;
        boolean on = "1".equals(p[0]);
        int count = i(p[2]), base = i(p[3]), tw = i(p[4]), th = i(p[5]), kb = i(p[6]), us = i(p[7]);
        strip.setInfo(on ? count : 0, base, tw, th);
        if (!on) title.setText(Lang.t("History is off"));
        else title.setText(Lang.t("History: ") + count + Lang.t(" states") + "  " + (kb >= 1024 ? (kb / 1024) + " MB" : kb + " KB")
                + "  " + String.format(java.util.Locale.US, "%.1f", us / 1000f) + " ms/" + Lang.t("capture"));
    }

    private static int i(String s) {
        try { return Integer.parseInt(s.trim()); } catch (RuntimeException e) { return 0; }
    }

    private final class StripView extends View {
        private int count, base, tw, th;
        private float scrollX;
        private boolean follow = true;
        private int selected = Integer.MIN_VALUE;
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint frame = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final LruCache<Integer, Bitmap> bitmaps = new LruCache<>(90);
        private final LruCache<Integer, Integer> frames = new LruCache<>(600);
        private final OverScroller scroller;
        private final GestureDetector gd;
        private final float gap, labelH;

        StripView() {
            super(a);
            gap = Ui.dp(a, 4);
            labelH = Ui.dp(a, 14);
            text.setColor(Ui.SUB);
            text.setTextSize(Ui.dp(a, 10));
            text.setTextAlign(Paint.Align.CENTER);
            frame.setStyle(Paint.Style.STROKE);
            frame.setStrokeWidth(Ui.dp(a, 2));
            frame.setColor(Ui.ACCENT);
            scroller = new OverScroller(a);
            gd = new GestureDetector(a, new GestureDetector.SimpleOnGestureListener() {
                @Override public boolean onDown(MotionEvent e) { scroller.forceFinished(true); return true; }
                @Override public boolean onScroll(MotionEvent e1, MotionEvent e2, float dx, float dy) {
                    follow = false;
                    scrollX = clamp(scrollX + dx);
                    checkFollow();
                    invalidate();
                    return true;
                }
                @Override public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                    follow = false;
                    scroller.fling((int) scrollX, 0, (int) -vx, 0, 0, (int) maxScroll(), 0, 0);
                    postInvalidateOnAnimation();
                    return true;
                }
                @Override public boolean onSingleTapUp(MotionEvent e) {
                    int idx = (int) ((scrollX + e.getX()) / step());
                    if (idx >= 0 && idx < count) {
                        selected = base + idx;
                        Native.tasCmd(Native.T_HIST_LOAD, base + idx, null);
                        invalidate();
                    }
                    return true;
                }
            });
        }

        private float cellW() { return th > 0 ? (getHeight() - labelH - Ui.dp(a, 2)) * tw / (float) th : Ui.dp(a, 80); }
        private float step() { return cellW() + gap; }
        private float maxScroll() { return Math.max(0f, count * step() - gap - getWidth()); }
        private float clamp(float v) { return Math.max(0f, Math.min(maxScroll(), v)); }
        private void checkFollow() { if (scrollX >= maxScroll() - step() * 0.5f) follow = true; }

        void toEnd() { follow = true; scrollX = maxScroll(); invalidate(); }

        void setInfo(int newCount, int newBase, int newTw, int newTh) {
            if (newBase != base && newCount > 0) {
                int d = newBase - base;
                if (d > 0 && d < 500) scrollX -= d * step();			// the oldest ones dropped off: keep what is on screen where it is
                else { follow = true; selected = Integer.MIN_VALUE; bitmaps.evictAll(); frames.evictAll(); }
            }
            if (newTw != tw || newTh != th) { bitmaps.evictAll(); frames.evictAll(); }
            count = newCount; base = newBase; tw = newTw; th = newTh;
            if (count == 0) { selected = Integer.MIN_VALUE; bitmaps.evictAll(); frames.evictAll(); }
            scrollX = follow ? maxScroll() : clamp(scrollX);
            invalidate();
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            getParent().requestDisallowInterceptTouchEvent(true);
            return gd.onTouchEvent(e);
        }

        @Override public void computeScroll() {
            if (scroller.computeScrollOffset()) {
                scrollX = clamp(scroller.getCurrX());
                checkFollow();
                postInvalidateOnAnimation();
            }
        }

        private Bitmap bitmap(int seq) {
            Bitmap b = bitmaps.get(seq);
            if (b != null) return b;
            short[] px;
            try { px = Native.tasHistThumb(seq); } catch (UnsatisfiedLinkError | RuntimeException e) { return null; }
            if (px == null || tw <= 0 || px.length != tw * th) return null;
            b = Bitmap.createBitmap(tw, th, Bitmap.Config.RGB_565);
            b.copyPixelsFromBuffer(ShortBuffer.wrap(px));
            bitmaps.put(seq, b);
            return b;
        }

        @Override protected void onDraw(Canvas c) {
            if (count == 0 || tw <= 0) {
                text.setTextSize(Ui.dp(a, 12));
                c.drawText(Lang.t("Nothing recorded yet"), getWidth() / 2f, getHeight() / 2f, text);
                text.setTextSize(Ui.dp(a, 10));
                return;
            }
            float st = step(), cw = cellW(), ch = getHeight() - labelH - Ui.dp(a, 2);
            int first = Math.max(0, (int) (scrollX / st));
            int last = Math.min(count - 1, (int) ((scrollX + getWidth()) / st));
            // frame numbers of what is on screen, fetched in one go
            int[] fr = null;
            boolean need = false;
            for (int i = first; i <= last && !need; i++) if (frames.get(base + i) == null) need = true;
            if (need) {
                try { fr = Native.tasHistFrames(base + first, last - first + 1); } catch (UnsatisfiedLinkError | RuntimeException e) { fr = null; }
                if (fr != null) for (int k = 0; k < fr.length; k++) if (fr[k] >= 0) frames.put(base + first + k, fr[k]);
            }
            for (int i = first; i <= last; i++) {
                float x = i * st - scrollX;
                Bitmap b = bitmap(base + i);
                rect.set(x, 0, x + cw, ch);
                if (b != null) c.drawBitmap(b, null, rect, paint);
                if (base + i == selected) c.drawRect(rect, frame);
                Integer f = frames.get(base + i);
                if (f != null) c.drawText(String.valueOf(f), x + cw / 2f, ch + labelH - Ui.dp(a, 3), text);
            }
        }
    }
}
