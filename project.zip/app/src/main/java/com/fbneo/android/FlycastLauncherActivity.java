package com.fbneo.android;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** The Flycast (Dojo) section: lists the games in <main folder>/flycast/roms and starts the Flycast engine. */
public class FlycastLauncherActivity extends Activity {
    private static final String ENGINE = "com.reicast.emulator.NativeGLActivity";
    private final List<File> games = new ArrayList<>();
    private LinearLayout list;
    private TextView info;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Prefs.migrateLayout(this);
        LinearLayout root = Ui.vertical(this);
        root.setBackgroundColor(Ui.BG);
        LinearLayout top = Ui.horizontal(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 6));
        top.addView(Ui.iconButton(this, Icons.BACK, "Back", v -> finish()));
        LinearLayout titles = Ui.vertical(this);
        titles.setPadding(Ui.dp(this, 14), 0, 0, 0);
        titles.addView(Ui.text(this, "Flycast", 28, Ui.TEXT, true));
        titles.addView(Ui.text(this, "Dreamcast, Naomi and Atomiswave (Flycast Dojo)", 12, Ui.SUB, false));
        top.addView(titles, new LinearLayout.LayoutParams(0, -2, 1f));
        top.addView(Ui.iconButton(this, Icons.MORE, "Menu", v -> SideMenu.show(this, SideMenu.FLYCAST)));
        root.addView(top);

        LinearLayout card = Ui.card(this, Ui.SURFACE, 22);
        card.setPadding(Ui.dp(this, 18), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        info = Ui.text(this, "", 12, Ui.SUB, false);
        card.addView(info);
        LinearLayout acts = Ui.horizontal(this);
        acts.setPadding(0, Ui.dp(this, 10), 0, 0);
        acts.addView(Ui.button(this, "Open Flycast", Ui.FILLED, v -> launch(null)));
        card.addView(acts);
        root.addView(card, Ui.fillMargins(this, 16, 6, 16, 8));

        android.widget.ScrollView sv = new android.widget.ScrollView(this);
        list = Ui.vertical(this);
        list.setPadding(Ui.dp(this, 16), 0, Ui.dp(this, 16), Ui.dp(this, 16));
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        setContentView(root);
    }

    @Override protected void onResume() {
        super.onResume();
        Prefs.migrateLayout(this);
        scan();
    }

    private boolean engineThere() {
        try { Class.forName(ENGINE); return true; } catch (Throwable t) { return false; }
    }

    private void scan() {
        String dir = Prefs.flycastDir(this) + "roms/";
        new File(dir).mkdirs();
        games.clear();
        collect(new File(dir), 0);
        Collections.sort(games, (x, y) -> x.getName().compareToIgnoreCase(y.getName()));
        boolean ok = engineThere();
        info.setText((ok ? "" : "This build does not include the Flycast engine (it could not be compiled when the app was built).\n\n")
                + "Games folder: " + dir + "\nBIOS (dc_boot.bin, dc_flash.bin, naomi bios) goes in " + Prefs.flycastDir(this) + "data/");
        list.removeAllViews();
        if (games.isEmpty()) {
            list.addView(Ui.text(this, "No games found. Put .gdi / .chd / .cdi / .cue / .zip / .7z files in the games folder.", 14, Ui.SUB, false),
                    Ui.fillMargins(this, 4, 16, 4, 0));
            return;
        }
        for (final File f : games) {
            LinearLayout r = Ui.vertical(this);
            r.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
            r.setBackground(Ui.rounded(this, Ui.SURFACE, 16));
            String n = f.getName();
            int dot = n.lastIndexOf('.');
            r.addView(Ui.text(this, dot > 0 ? n.substring(0, dot) : n, 15, Ui.TEXT, true));
            r.addView(Ui.text(this, n.substring(dot + 1).toUpperCase(Locale.ROOT), 11, Ui.SUB, false));
            r.setClickable(true);
            r.setOnClickListener(v -> launch(f));
            list.addView(r, Ui.fillMargins(this, 0, 4, 0, 4));
        }
    }

    private void collect(File d, int depth) {
        File[] fs = d.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.isDirectory()) { if (depth < 2) collect(f, depth + 1); continue; }
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (n.endsWith(".gdi") || n.endsWith(".chd") || n.endsWith(".cdi") || n.endsWith(".cue")
                    || n.endsWith(".zip") || n.endsWith(".7z") || n.endsWith(".lst") || n.endsWith(".dat")) games.add(f);
        }
    }

    private void launch(File game) {
        if (!engineThere()) { Ui.toast(this, "This build has no Flycast engine"); return; }
        if (!Prefs.hasAccess(this)) { Prefs.requestAccess(this); return; }
        try {
            SharedPreferences dp = android.preference.PreferenceManager.getDefaultSharedPreferences(this);
            dp.edit().putString("home_directory", Prefs.flycastDir(this)).apply();
            Intent i = new Intent();
            i.setComponent(new ComponentName(this, ENGINE));
            if (game != null) {
                i.setAction(Intent.ACTION_VIEW);
                i.setData(Uri.parse(game.getAbsolutePath()));
            }
            startActivity(i);
        } catch (Throwable t) {
            Ui.toast(this, "Could not start Flycast: " + t.getMessage());
        }
    }
}
