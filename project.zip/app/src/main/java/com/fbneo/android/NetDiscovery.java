package com.fbneo.android;

import android.content.Context;
import android.net.DhcpInfo;
import android.net.wifi.WifiManager;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Finds friends on the same network: the host shouts "I'm here" over UDP, guests listen. */
final class NetDiscovery {
    static final int PORT = 7246;

    static final class Host {
        String ip, game;
        long seen;
    }

    private final Context ctx;
    private volatile boolean running;
    private Thread sender, listener;
    private WifiManager.MulticastLock lock;
    private final Map<String, Host> hosts = new LinkedHashMap<>();

    NetDiscovery(Context c) { ctx = c.getApplicationContext(); }

    /** This phone's own IPv4 addresses (Wi-Fi, hotspot) as "interface: address". */
    static List<String> localAddresses() {
        List<String> out = new ArrayList<>();
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    if (ia.getAddress() instanceof Inet4Address) out.add(ni.getName() + ": " + ia.getAddress().getHostAddress());
                }
            }
        } catch (Exception e) {
            // none
        }
        return out;
    }

    static boolean isOwn(String ip) {
        for (String s : localAddresses()) if (s.endsWith(": " + ip)) return true;
        return false;
    }

    /** Address of the Wi-Fi router / the phone sharing its hotspot (a good guess for the host). */
    static String gateway(Context c) {
        try {
            WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            DhcpInfo d = wm.getDhcpInfo();
            int g = d.gateway;
            if (g == 0) return "";
            return (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff);
        } catch (Exception e) {
            return "";
        }
    }

    private void acquireLock() {
        try {
            WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
            lock = wm.createMulticastLock("fbneo-net");
            lock.setReferenceCounted(false);
            lock.acquire();
        } catch (Exception e) {
            lock = null;
        }
    }

    void startHosting(final String game) {
        stop();
        running = true;
        acquireLock();
        sender = new Thread(() -> {
            try (DatagramSocket s = new DatagramSocket()) {
                s.setBroadcast(true);
                byte[] msg = ("FBNEO1|" + game + "|7245").getBytes("UTF-8");
                while (running) {
                    List<InetAddress> targets = new ArrayList<>();
                    try {
                        targets.add(InetAddress.getByName("255.255.255.255"));
                        for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                            if (!ni.isUp() || ni.isLoopback()) continue;
                            for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                                if (ia.getBroadcast() != null) targets.add(ia.getBroadcast());
                            }
                        }
                    } catch (Exception e) {
                        // keep going
                    }
                    for (InetAddress t : targets) {
                        try { s.send(new DatagramPacket(msg, msg.length, t, PORT)); } catch (Exception e) { /* next */ }
                    }
                    Thread.sleep(1000);
                }
            } catch (Exception e) {
                // stopped
            }
        }, "net-announce");
        sender.setDaemon(true);
        sender.start();
    }

    void startListening() {
        stop();
        running = true;
        acquireLock();
        listener = new Thread(() -> {
            try (DatagramSocket s = new DatagramSocket(null)) {
                s.setReuseAddress(true);
                s.bind(new java.net.InetSocketAddress(PORT));
                s.setSoTimeout(500);
                byte[] buf = new byte[256];
                while (running) {
                    try {
                        DatagramPacket p = new DatagramPacket(buf, buf.length);
                        s.receive(p);
                        String m = new String(p.getData(), 0, p.getLength(), "UTF-8");
                        if (!m.startsWith("FBNEO1|")) continue;
                        String ip = p.getAddress().getHostAddress();
                        if (isOwn(ip)) continue;
                        String[] parts = m.split("\\|");
                        Host h = new Host();
                        h.ip = ip;
                        h.game = parts.length > 1 ? parts[1] : "";
                        h.seen = System.currentTimeMillis();
                        synchronized (hosts) { hosts.put(ip, h); }
                    } catch (java.net.SocketTimeoutException e) {
                        // loop
                    }
                }
            } catch (Exception e) {
                // stopped
            }
        }, "net-listen");
        listener.setDaemon(true);
        listener.start();
    }

    List<Host> found() {
        List<Host> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        synchronized (hosts) {
            for (Host h : hosts.values()) if (now - h.seen < 4000) out.add(h);
        }
        return out;
    }

    void stop() {
        running = false;
        synchronized (hosts) { hosts.clear(); }
        if (lock != null) {
            try { lock.release(); } catch (Exception e) { /* ignore */ }
            lock = null;
        }
    }
}
