#include <jni.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <string>
#include "mamehost.h"

static ANativeWindow* g_win = nullptr;
static int g_lastW = -1, g_lastH = -1;

static std::string str(JNIEnv* env, jstring s) {
    if (!s) return "";
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r = c ? c : "";
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

extern "C" {

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_load(JNIEnv* env, jclass, jstring core, jstring sys, jstring save) {
    return mh::loadCore(str(env, core).c_str(), str(env, sys).c_str(), str(env, save).c_str());
}

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_loadGame(JNIEnv* env, jclass, jstring path) {
    return mh::loadGame(str(env, path).c_str());
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_unload(JNIEnv*, jclass) {
    mh::unload();
    if (g_win) { ANativeWindow_release(g_win); g_win = nullptr; }
}

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_runFrame(JNIEnv*, jclass) {
    return mh::runFrame();
}

JNIEXPORT jdoubleArray JNICALL Java_com_fbneo_android_MameNative_info(JNIEnv* env, jclass) {
    int w, h, rot;
    double fps, rate, aspect;
    mh::info(&w, &h, &fps, &rate, &rot, &aspect);
    jdouble v[6] = { (double)w, (double)h, fps, rate, (double)rot, aspect };
    jdoubleArray a = env->NewDoubleArray(6);
    env->SetDoubleArrayRegion(a, 0, 6, v);
    return a;
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_setSurface(JNIEnv* env, jclass, jobject surface) {
    if (g_win) { ANativeWindow_release(g_win); g_win = nullptr; }
    g_lastW = g_lastH = -1;
    if (surface) g_win = ANativeWindow_fromSurface(env, surface);
}

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_blit(JNIEnv*, jclass) {
    if (!g_win) return JNI_FALSE;
    int w, h, rot;
    double fps, rate, aspect;
    mh::info(&w, &h, &fps, &rate, &rot, &aspect);
    if (w <= 0 || h <= 0) return JNI_FALSE;
    if (w != g_lastW || h != g_lastH) {
        ANativeWindow_setBuffersGeometry(g_win, w, h, WINDOW_FORMAT_RGBA_8888);
        g_lastW = w; g_lastH = h;
    }
    ANativeWindow_Buffer buf;
    if (ANativeWindow_lock(g_win, &buf, nullptr) != 0) return JNI_FALSE;
    int ok = 0;
    if (buf.format == WINDOW_FORMAT_RGBA_8888 || buf.format == WINDOW_FORMAT_RGBX_8888)
        ok = mh::copyFrame((uint32_t*)buf.bits, buf.stride, buf.width, buf.height);
    ANativeWindow_unlockAndPost(g_win);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL Java_com_fbneo_android_MameNative_audio(JNIEnv* env, jclass, jshortArray out) {
    jsize cap = env->GetArrayLength(out);
    jshort* p = env->GetShortArrayElements(out, nullptr);
    int n = mh::takeAudio((int16_t*)p, cap);
    env->ReleaseShortArrayElements(out, p, 0);
    return n;
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_setButton(JNIEnv*, jclass, jint port, jint id, jboolean down) {
    mh::setButton(port, id, down);
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_setOption(JNIEnv* env, jclass, jstring k, jstring v) {
    mh::setOption(str(env, k).c_str(), str(env, v).c_str());
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_reset(JNIEnv*, jclass) { mh::reset(); }

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_saveState(JNIEnv* env, jclass, jstring path) {
    return mh::saveState(str(env, path).c_str());
}

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_loadState(JNIEnv* env, jclass, jstring path) {
    return mh::loadState(str(env, path).c_str());
}

JNIEXPORT jstring JNICALL Java_com_fbneo_android_MameNative_log(JNIEnv* env, jclass) {
    return env->NewStringUTF(mh::lastLog().c_str());
}

}
