#include <jni.h>
#include <android/native_window.h>
#include <android/native_window_jni.h>
#include <string>
#include "mamehost.h"
#include "vkpresent.h"

static ANativeWindow* g_win = nullptr;
static int g_lastW = -1, g_lastH = -1;
// optional Vulkan output (chosen in Settings). Falls back to the plain window path below when it is not running.
static vkp::Presenter g_vk;
static ANativeWindow* g_vkWin = nullptr;
static bool g_vkLinear = false;
static bool g_vkWanted = false;		// Vulkan was started: if it stops working the plain path must take the window back

static std::string str(JNIEnv* env, jstring s) {
    if (!s) return "";
    const char* c = env->GetStringUTFChars(s, nullptr);
    std::string r = c ? c : "";
    if (c) env->ReleaseStringUTFChars(s, c);
    return r;
}

extern "C" {

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_load(JNIEnv* env, jclass, jstring core, jstring sys, jstring save) {
    return mh::loadCore(str(env, core).c_str(), str(env, sys).c_str(), str(env, save).c_str());
}

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_loadGame(JNIEnv* env, jclass, jstring path) {
    return mh::loadGame(str(env, path).c_str());
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_unload(JNIEnv*, jclass) {
    mh::unload();
    g_vk.shutdown();
    if (g_vkWin) { ANativeWindow_release(g_vkWin); g_vkWin = nullptr; }
    if (g_win) { ANativeWindow_release(g_win); g_win = nullptr; }
}

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_runFrame(JNIEnv*, jclass) {
    return mh::runFrame();
}

JNIEXPORT jdoubleArray JNICALL Java_com_fbneo_android_MameNative_info(JNIEnv* env, jclass) {
    int w, h, rot;
    double fps, rate, aspect;
    mh::info(&w, &h, &fps, &rate, &rot, &aspect);
    jdouble v[6] = { (double)w, (double)h, fps, rate, (double)rot, aspect };
    jdoubleArray a = env->NewDoubleArray(6);
    env->SetDoubleArrayRegion(a, 0, 6, v);
    return a;
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_setSurface(JNIEnv* env, jclass, jobject surface) {
    if (g_win) { ANativeWindow_release(g_win); g_win = nullptr; }
    g_lastW = g_lastH = -1;
    if (surface) g_win = ANativeWindow_fromSurface(env, surface);
}

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_vkStart(JNIEnv* env, jclass, jobject surface, jboolean vsync, jboolean linear) {
    g_vk.shutdown();
    if (g_vkWin) { ANativeWindow_release(g_vkWin); g_vkWin = nullptr; }
    g_vkLinear = linear != JNI_FALSE;
    if (!surface) return JNI_FALSE;
    g_vkWin = ANativeWindow_fromSurface(env, surface);
    bool ok = g_vk.start(g_vkWin, vsync != JNI_FALSE);
    g_vkWanted = ok;
    if (!ok && g_vkWin) { ANativeWindow_release(g_vkWin); g_vkWin = nullptr; }
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_vkStop(JNIEnv*, jclass) {
    g_vkWanted = false;
    g_vk.shutdown();
    if (g_vkWin) { ANativeWindow_release(g_vkWin); g_vkWin = nullptr; }
}

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_vkReady(JNIEnv*, jclass) {
    return g_vk.ready() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_blit(JNIEnv*, jclass) {
    if (g_vkWanted && !g_vk.ready()) {
        // Vulkan stopped working (driver error): give the window back so the plain path can draw on it
        g_vkWanted = false;
        g_vk.shutdown();
        if (g_vkWin) { ANativeWindow_release(g_vkWin); g_vkWin = nullptr; }
    }
    if (g_vk.ready()) {
        int w, h, rot;
        double fps, rate, aspect;
        mh::info(&w, &h, &fps, &rate, &rot, &aspect);
        if (w <= 0 || h <= 0) return JNI_FALSE;
        uint32_t* px = nullptr;
        int st = 0;
        if (!g_vk.beginFrame(w, h, vkp::Presenter::RGBA, &px, &st)) return g_vk.ready() ? JNI_TRUE : JNI_FALSE;	// GPU busy: skip this picture
        int ok = mh::copyFrame(px, st, w, h);
        if (ok) g_vk.endFrame(0, 0, g_vkLinear, false); else g_vk.abortFrame();
        return ok ? JNI_TRUE : JNI_FALSE;
    }
    if (!g_win) return JNI_FALSE;
    int w, h, rot;
    double fps, rate, aspect;
    mh::info(&w, &h, &fps, &rate, &rot, &aspect);
    if (w <= 0 || h <= 0) return JNI_FALSE;
    if (w != g_lastW || h != g_lastH) {
        ANativeWindow_setBuffersGeometry(g_win, w, h, WINDOW_FORMAT_RGBA_8888);
        g_lastW = w; g_lastH = h;
    }
    ANativeWindow_Buffer buf;
    if (ANativeWindow_lock(g_win, &buf, nullptr) != 0) return JNI_FALSE;
    int ok = 0;
    if (buf.format == WINDOW_FORMAT_RGBA_8888 || buf.format == WINDOW_FORMAT_RGBX_8888)
        ok = mh::copyFrame((uint32_t*)buf.bits, buf.stride, buf.width, buf.height);
    ANativeWindow_unlockAndPost(g_win);
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL Java_com_fbneo_android_MameNative_audio(JNIEnv* env, jclass, jshortArray out) {
    jsize cap = env->GetArrayLength(out);
    jshort* p = env->GetShortArrayElements(out, nullptr);
    int n = mh::takeAudio((int16_t*)p, cap);
    env->ReleaseShortArrayElements(out, p, 0);
    return n;
}

JNIEXPORT jint JNICALL Java_com_fbneo_android_MameNative_frameHash(JNIEnv*, jclass) {
    return (jint)mh::frameHash();
}

JNIEXPORT jlongArray JNICALL Java_com_fbneo_android_MameNative_audioStats(JNIEnv* env, jclass) {
    long long b, s, f;
    mh::audioStats(&b, &s, &f);
    jlong v[3] = { (jlong)b, (jlong)s, (jlong)f };
    jlongArray a = env->NewLongArray(3);
    env->SetLongArrayRegion(a, 0, 3, v);
    return a;
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_setButton(JNIEnv*, jclass, jint port, jint id, jboolean down) {
    mh::setButton(port, id, down);
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_setOption(JNIEnv* env, jclass, jstring k, jstring v) {
    mh::setOption(str(env, k).c_str(), str(env, v).c_str());
}

JNIEXPORT void JNICALL Java_com_fbneo_android_MameNative_reset(JNIEnv*, jclass) { mh::reset(); }

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_saveState(JNIEnv* env, jclass, jstring path) {
    return mh::saveState(str(env, path).c_str());
}

JNIEXPORT jboolean JNICALL Java_com_fbneo_android_MameNative_loadState(JNIEnv* env, jclass, jstring path) {
    return mh::loadState(str(env, path).c_str());
}

JNIEXPORT jstring JNICALL Java_com_fbneo_android_MameNative_log(JNIEnv* env, jclass) {
    return env->NewStringUTF(mh::lastLog().c_str());
}

}
