// A small Vulkan presenter shared by the FBNeo and MAME sections.
//
// What it does: the emulator hands over a finished picture (CPU memory), the GPU scales it onto the screen with
// vkCmdBlitImage (nearest or linear, letterboxed, optional integer scaling) and presents it. There are no shaders,
// no pipelines and no render passes: nothing here can be wrong on one GPU and right on another.
//
// Design points:
//  * Vulkan is loaded with dlopen at run time: a phone without it (or with a broken driver) simply reports failure
//    and the caller keeps using its normal renderer.
//  * The emulation thread only memcpy's into a persistently mapped staging buffer; a presenter thread talks to the
//    GPU and waits for the screen refresh, so a slow vsync never stalls the emulation.
//  * Three frame slots. If the GPU is behind, the newest picture wins (older ones are dropped, never queued).
//  * The swapchain is created for the surface's real size and recreated when the surface changes.
#pragma once
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <dlfcn.h>
#include <atomic>
#include <chrono>
#include <condition_variable>
#include <mutex>
#include <thread>
#include <vector>

#ifndef VK_USE_PLATFORM_ANDROID_KHR
#define VK_USE_PLATFORM_ANDROID_KHR 1
#endif
#define VK_NO_PROTOTYPES 1
#include <vulkan/vulkan.h>
#include <vulkan/vulkan_android.h>

struct ANativeWindow;

namespace vkp {

#define VKP_GLOBAL(F) F(vkCreateInstance)
#define VKP_INSTANCE(F) \
	F(vkDestroyInstance) F(vkEnumeratePhysicalDevices) F(vkGetPhysicalDeviceQueueFamilyProperties) \
	F(vkGetPhysicalDeviceMemoryProperties) F(vkGetPhysicalDeviceFormatProperties) F(vkCreateDevice) \
	F(vkGetDeviceProcAddr) F(vkDestroySurfaceKHR) F(vkGetPhysicalDeviceSurfaceSupportKHR) \
	F(vkGetPhysicalDeviceSurfaceCapabilitiesKHR) F(vkGetPhysicalDeviceSurfaceFormatsKHR) \
	F(vkGetPhysicalDeviceSurfacePresentModesKHR) F(vkCreateAndroidSurfaceKHR) F(vkGetPhysicalDeviceProperties)
#define VKP_DEVICE(F) \
	F(vkDestroyDevice) F(vkGetDeviceQueue) F(vkCreateSwapchainKHR) F(vkDestroySwapchainKHR) \
	F(vkGetSwapchainImagesKHR) F(vkAcquireNextImageKHR) F(vkQueuePresentKHR) F(vkQueueSubmit) \
	F(vkDeviceWaitIdle) F(vkCreateCommandPool) F(vkDestroyCommandPool) F(vkAllocateCommandBuffers) \
	F(vkBeginCommandBuffer) F(vkEndCommandBuffer) F(vkResetCommandBuffer) F(vkCmdPipelineBarrier) \
	F(vkCmdCopyBufferToImage) F(vkCmdBlitImage) F(vkCmdClearColorImage) F(vkCreateFence) F(vkDestroyFence) \
	F(vkWaitForFences) F(vkResetFences) F(vkGetFenceStatus) F(vkCreateSemaphore) F(vkDestroySemaphore) \
	F(vkCreateBuffer) F(vkDestroyBuffer) F(vkGetBufferMemoryRequirements) F(vkAllocateMemory) F(vkFreeMemory) \
	F(vkBindBufferMemory) F(vkMapMemory) F(vkUnmapMemory) F(vkCreateImage) F(vkDestroyImage) \
	F(vkGetImageMemoryRequirements) F(vkBindImageMemory)

struct Fns {
#define VKP_DECL(n) PFN_##n n = nullptr;
	VKP_GLOBAL(VKP_DECL) VKP_INSTANCE(VKP_DECL) VKP_DEVICE(VKP_DECL)
#undef VKP_DECL
	PFN_vkGetInstanceProcAddr vkGetInstanceProcAddr = nullptr;
};

class Presenter {
public:
	enum { SLOTS = 3 };
	enum Format { BGRA = 0, RGBA = 1 };

	~Presenter() { shutdown(); }

	// true when pictures are being shown (surface, device and swapchain all work)
	bool ready() const { return ready_.load(); }
	const char* why() const { return why_; }

	// Bring Vulkan up on this window. Never throws; false = keep using the normal renderer.
	bool start(ANativeWindow* win, bool vsync)
	{
		shutdown();
		vsync_ = vsync;
		if (!win) { why_ = "no window"; return false; }
		if (!loadLib()) return false;
		if (!createInstance(win)) { teardown(); return false; }
		if (!createDevice()) { teardown(); return false; }
		if (!createSwapchain()) { teardown(); return false; }
		stop_ = false;
		for (int i = 0; i < SLOTS; i++) slot_[i].state = 0;
		pending_ = -1;
		thr_ = std::thread(&Presenter::loop, this);
		ready_ = true;
		printf("[vulkan] ready: %s, %ux%u, %d images, present mode %d\n", devName_, ext_.width, ext_.height, nImages_, (int)mode_);
		return true;
	}

	void shutdown()
	{
		ready_ = false;
		std::lock_guard<std::mutex> producer(prod_);		// waits for a picture being drawn by the emulation thread
		{ std::lock_guard<std::mutex> lk(m_); stop_ = true; }
		cv_.notify_all();
		if (thr_.joinable()) thr_.join();
		teardown();
	}

	// ---- emulation thread ----
	// Ask for a buffer to draw the next picture into (w*h pixels, 4 bytes each, rows 'stridePx' pixels apart).
	// false = no free slot right now (the GPU is behind): skip this picture.
	bool beginFrame(int w, int h, Format fmt, uint32_t** pixels, int* stridePx)
	{
		prod_.lock();			// held until endFrame / abortFrame (shutdown waits for it)
		if (!ready_ || w <= 0 || h <= 0) { prod_.unlock(); return false; }
		int s = -1;
		{
			std::lock_guard<std::mutex> lk(m_);
			for (int i = 0; i < SLOTS; i++) if (slot_[i].state == 0) { s = i; slot_[i].state = 1; break; }
		}
		if (s < 0) { prod_.unlock(); return false; }
		Slot& sl = slot_[s];
		VkDeviceSize need = (VkDeviceSize)w * h * 4;
		if (sl.bufSize < need && !makeStaging(sl, need)) { release(s); prod_.unlock(); return false; }
		sl.w = w; sl.h = h; sl.fmt = fmt;
		cur_ = s;
		*pixels = (uint32_t*)sl.map;
		*stridePx = w;
		return true;
	}

	// Hand the finished picture over. logicalW/H: the shape the picture should have on screen (0 = fill the screen).
	void endFrame(int logicalW, int logicalH, bool linear, bool integer)
	{
		int s = cur_;
		if (s < 0) return;
		cur_ = -1;
		Slot& sl = slot_[s];
		sl.lw = logicalW; sl.lh = logicalH; sl.linear = linear; sl.integer = integer;
		{
			std::lock_guard<std::mutex> lk(m_);
			if (pending_ >= 0 && slot_[pending_].state == 2) slot_[pending_].state = 0;	// an older picture nobody showed: drop it
			sl.state = 2;
			pending_ = s;
		}
		cv_.notify_one();
		prod_.unlock();
	}

	void abortFrame() { if (cur_ >= 0) { release(cur_); cur_ = -1; prod_.unlock(); } }

private:
	struct Slot {
		int state = 0;			// 0 free, 1 being written, 2 ready to show, 3 on the GPU
		VkBuffer buf = VK_NULL_HANDLE; VkDeviceMemory bufMem = VK_NULL_HANDLE; void* map = nullptr; VkDeviceSize bufSize = 0;
		VkImage img = VK_NULL_HANDLE; VkDeviceMemory imgMem = VK_NULL_HANDLE; int imgW = 0, imgH = 0, imgFmt = -1;
		VkCommandBuffer cmd = VK_NULL_HANDLE; VkFence fence = VK_NULL_HANDLE; VkSemaphore acquire = VK_NULL_HANDLE;
		bool fenceUsed = false;
		int w = 0, h = 0, fmt = 0, lw = 0, lh = 0; bool linear = false, integer = false;
	};

	Fns f_;
	void* lib_ = nullptr;
	VkInstance inst_ = VK_NULL_HANDLE;
	VkSurfaceKHR surf_ = VK_NULL_HANDLE;
	VkPhysicalDevice phys_ = VK_NULL_HANDLE;
	VkDevice dev_ = VK_NULL_HANDLE;
	VkQueue queue_ = VK_NULL_HANDLE;
	uint32_t qfam_ = 0;
	VkCommandPool pool_ = VK_NULL_HANDLE;
	VkPhysicalDeviceMemoryProperties memProps_;
	VkSwapchainKHR sc_ = VK_NULL_HANDLE;
	VkFormat scFormat_ = VK_FORMAT_UNDEFINED;
	VkExtent2D ext_ = { 0, 0 };
	VkPresentModeKHR mode_ = VK_PRESENT_MODE_FIFO_KHR;
	std::vector<VkImage> images_;
	std::vector<VkSemaphore> renderDone_;
	int nImages_ = 0;
	bool vsync_ = true, linearBlit_[2] = { false, false }, srcBlit_[2] = { false, false };
	char devName_[256] = "";
	const char* why_ = "";
	Slot slot_[SLOTS];
	int cur_ = -1, pending_ = -1;
	std::mutex m_;
	std::mutex prod_;
	std::condition_variable cv_;
	std::thread thr_;
	bool stop_ = false;
	std::atomic<bool> ready_{false};
	ANativeWindow* win_ = nullptr;

	void release(int s) { std::lock_guard<std::mutex> lk(m_); slot_[s].state = 0; }

	bool fail(const char* w) { why_ = w; printf("[vulkan] %s\n", w); return false; }

	bool loadLib()
	{
		if (lib_) return true;
		lib_ = dlopen("libvulkan.so", RTLD_NOW | RTLD_LOCAL);
		if (!lib_) return fail("libvulkan.so is not available");
		f_.vkGetInstanceProcAddr = (PFN_vkGetInstanceProcAddr)dlsym(lib_, "vkGetInstanceProcAddr");
		if (!f_.vkGetInstanceProcAddr) return fail("vkGetInstanceProcAddr missing");
		f_.vkCreateInstance = (PFN_vkCreateInstance)f_.vkGetInstanceProcAddr(nullptr, "vkCreateInstance");
		if (!f_.vkCreateInstance) return fail("vkCreateInstance missing");
		return true;
	}

	bool createInstance(ANativeWindow* win)
	{
		win_ = win;
		const char* exts[] = { "VK_KHR_surface", "VK_KHR_android_surface" };
		VkApplicationInfo ai = { VK_STRUCTURE_TYPE_APPLICATION_INFO };
		ai.pApplicationName = "FBNeo";
		ai.apiVersion = VK_API_VERSION_1_0;
		VkInstanceCreateInfo ci = { VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO };
		ci.pApplicationInfo = &ai;
		ci.enabledExtensionCount = 2;
		ci.ppEnabledExtensionNames = exts;
		if (f_.vkCreateInstance(&ci, nullptr, &inst_) != VK_SUCCESS) return fail("cannot create a Vulkan instance");
#define VKP_LOADI(n) f_.n = (PFN_##n)f_.vkGetInstanceProcAddr(inst_, #n);
		VKP_INSTANCE(VKP_LOADI)
#undef VKP_LOADI
		VkAndroidSurfaceCreateInfoKHR si = { VK_STRUCTURE_TYPE_ANDROID_SURFACE_CREATE_INFO_KHR };
		si.window = (struct ANativeWindow*)win;
		if (f_.vkCreateAndroidSurfaceKHR(inst_, &si, nullptr, &surf_) != VK_SUCCESS) return fail("cannot create the Vulkan surface");
		return true;
	}

	bool createDevice()
	{
		uint32_t n = 0;
		f_.vkEnumeratePhysicalDevices(inst_, &n, nullptr);
		if (!n) return fail("no Vulkan device");
		std::vector<VkPhysicalDevice> pd(n);
		f_.vkEnumeratePhysicalDevices(inst_, &n, pd.data());
		for (uint32_t i = 0; i < n && phys_ == VK_NULL_HANDLE; i++) {
			uint32_t qn = 0;
			f_.vkGetPhysicalDeviceQueueFamilyProperties(pd[i], &qn, nullptr);
			std::vector<VkQueueFamilyProperties> qp(qn);
			f_.vkGetPhysicalDeviceQueueFamilyProperties(pd[i], &qn, qp.data());
			for (uint32_t q = 0; q < qn; q++) {
				VkBool32 sup = VK_FALSE;
				f_.vkGetPhysicalDeviceSurfaceSupportKHR(pd[i], q, surf_, &sup);
				if ((qp[q].queueFlags & VK_QUEUE_GRAPHICS_BIT) && sup) { phys_ = pd[i]; qfam_ = q; break; }
			}
		}
		if (phys_ == VK_NULL_HANDLE) return fail("no Vulkan queue can show pictures");
		VkPhysicalDeviceProperties pp;
		f_.vkGetPhysicalDeviceProperties(phys_, &pp);
		snprintf(devName_, sizeof(devName_), "%s", pp.deviceName);
		f_.vkGetPhysicalDeviceMemoryProperties(phys_, &memProps_);
		// can the GPU scale with a linear filter when blitting these formats?
		VkFormat fm[2] = { VK_FORMAT_B8G8R8A8_UNORM, VK_FORMAT_R8G8B8A8_UNORM };
		for (int i = 0; i < 2; i++) {
			VkFormatProperties fp;
			f_.vkGetPhysicalDeviceFormatProperties(phys_, fm[i], &fp);
			linearBlit_[i] = (fp.optimalTilingFeatures & VK_FORMAT_FEATURE_SAMPLED_IMAGE_FILTER_LINEAR_BIT) != 0;
			// the picture is scaled with a blit: the GPU must be able to read these formats that way
			srcBlit_[i] = (fp.optimalTilingFeatures & VK_FORMAT_FEATURE_BLIT_SRC_BIT) != 0;
		}
		if (!srcBlit_[0] && !srcBlit_[1]) return fail("this GPU cannot scale pictures with a blit");
		float prio = 1.0f;
		VkDeviceQueueCreateInfo qi = { VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO };
		qi.queueFamilyIndex = qfam_;
		qi.queueCount = 1;
		qi.pQueuePriorities = &prio;
		const char* dext[] = { "VK_KHR_swapchain" };
		VkDeviceCreateInfo di = { VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO };
		di.queueCreateInfoCount = 1;
		di.pQueueCreateInfos = &qi;
		di.enabledExtensionCount = 1;
		di.ppEnabledExtensionNames = dext;
		if (f_.vkCreateDevice(phys_, &di, nullptr, &dev_) != VK_SUCCESS) return fail("cannot create the Vulkan device");
#define VKP_LOADD(n) f_.n = (PFN_##n)f_.vkGetDeviceProcAddr(dev_, #n);
		VKP_DEVICE(VKP_LOADD)
#undef VKP_LOADD
		f_.vkGetDeviceQueue(dev_, qfam_, 0, &queue_);
		VkCommandPoolCreateInfo pi = { VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO };
		pi.flags = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;
		pi.queueFamilyIndex = qfam_;
		if (f_.vkCreateCommandPool(dev_, &pi, nullptr, &pool_) != VK_SUCCESS) return fail("cannot create the command pool");
		for (int i = 0; i < SLOTS; i++) {
			Slot& s = slot_[i];
			VkCommandBufferAllocateInfo ca = { VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO };
			ca.commandPool = pool_;
			ca.level = VK_COMMAND_BUFFER_LEVEL_PRIMARY;
			ca.commandBufferCount = 1;
			VkFenceCreateInfo fi = { VK_STRUCTURE_TYPE_FENCE_CREATE_INFO };
			VkSemaphoreCreateInfo smi = { VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO };
			if (f_.vkAllocateCommandBuffers(dev_, &ca, &s.cmd) != VK_SUCCESS ||
			    f_.vkCreateFence(dev_, &fi, nullptr, &s.fence) != VK_SUCCESS ||
			    f_.vkCreateSemaphore(dev_, &smi, nullptr, &s.acquire) != VK_SUCCESS) return fail("cannot create frame objects");
			s.fenceUsed = false;
		}
		return true;
	}

	bool createSwapchain()
	{
		VkSurfaceCapabilitiesKHR caps;
		if (f_.vkGetPhysicalDeviceSurfaceCapabilitiesKHR(phys_, surf_, &caps) != VK_SUCCESS) return fail("cannot query the surface");
		if (!(caps.supportedUsageFlags & VK_IMAGE_USAGE_TRANSFER_DST_BIT)) return fail("the surface cannot be a copy target");
		uint32_t fn = 0;
		f_.vkGetPhysicalDeviceSurfaceFormatsKHR(phys_, surf_, &fn, nullptr);
		std::vector<VkSurfaceFormatKHR> fmts(fn);
		f_.vkGetPhysicalDeviceSurfaceFormatsKHR(phys_, surf_, &fn, fmts.data());
		VkSurfaceFormatKHR pick = { VK_FORMAT_UNDEFINED, VK_COLOR_SPACE_SRGB_NONLINEAR_KHR };
		// a plain UNORM format: an sRGB one would brighten the picture when blitting
		for (uint32_t i = 0; i < fn; i++) if (fmts[i].format == VK_FORMAT_R8G8B8A8_UNORM || fmts[i].format == VK_FORMAT_B8G8R8A8_UNORM) { pick = fmts[i]; break; }
		if (pick.format == VK_FORMAT_UNDEFINED) return fail("no usable screen format");
		{
			VkFormatProperties dp;
			f_.vkGetPhysicalDeviceFormatProperties(phys_, pick.format, &dp);
			if (!(dp.optimalTilingFeatures & VK_FORMAT_FEATURE_BLIT_DST_BIT)) return fail("the screen format cannot be a blit target");
		}
		uint32_t pn = 0;
		f_.vkGetPhysicalDeviceSurfacePresentModesKHR(phys_, surf_, &pn, nullptr);
		std::vector<VkPresentModeKHR> modes(pn);
		f_.vkGetPhysicalDeviceSurfacePresentModesKHR(phys_, surf_, &pn, modes.data());
		bool hasMailbox = false, hasImm = false;
		for (uint32_t i = 0; i < pn; i++) { if (modes[i] == VK_PRESENT_MODE_MAILBOX_KHR) hasMailbox = true; if (modes[i] == VK_PRESENT_MODE_IMMEDIATE_KHR) hasImm = true; }
		mode_ = VK_PRESENT_MODE_FIFO_KHR;
		if (!vsync_) mode_ = hasMailbox ? VK_PRESENT_MODE_MAILBOX_KHR : (hasImm ? VK_PRESENT_MODE_IMMEDIATE_KHR : VK_PRESENT_MODE_FIFO_KHR);
		VkExtent2D e = caps.currentExtent;
		if (e.width == 0xFFFFFFFFu) { e.width = 1280; e.height = 720; }
		if (e.width == 0 || e.height == 0) return fail("the surface has no size yet");
		uint32_t want = caps.minImageCount + 1;
		if (want < 3) want = 3;
		if (caps.maxImageCount && want > caps.maxImageCount) want = caps.maxImageCount;
		VkSwapchainKHR old = sc_;
		VkSwapchainCreateInfoKHR ci = { VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR };
		ci.surface = surf_;
		ci.minImageCount = want;
		ci.imageFormat = pick.format;
		ci.imageColorSpace = pick.colorSpace;
		ci.imageExtent = e;
		ci.imageArrayLayers = 1;
		ci.imageUsage = VK_IMAGE_USAGE_TRANSFER_DST_BIT;
		ci.imageSharingMode = VK_SHARING_MODE_EXCLUSIVE;
		ci.preTransform = VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR;
		ci.compositeAlpha = (caps.supportedCompositeAlpha & VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR) ? VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR : VK_COMPOSITE_ALPHA_INHERIT_BIT_KHR;
		ci.presentMode = mode_;
		ci.clipped = VK_TRUE;
		ci.oldSwapchain = old;
		VkSwapchainKHR nsc = VK_NULL_HANDLE;
		if (f_.vkCreateSwapchainKHR(dev_, &ci, nullptr, &nsc) != VK_SUCCESS) return fail("cannot create the swapchain");
		if (old) { f_.vkDeviceWaitIdle(dev_); f_.vkDestroySwapchainKHR(dev_, old, nullptr); }
		for (size_t i = 0; i < renderDone_.size(); i++) f_.vkDestroySemaphore(dev_, renderDone_[i], nullptr);
		renderDone_.clear();
		sc_ = nsc;
		scFormat_ = pick.format;
		ext_ = e;
		uint32_t in = 0;
		f_.vkGetSwapchainImagesKHR(dev_, sc_, &in, nullptr);
		images_.assign(in, VK_NULL_HANDLE);
		f_.vkGetSwapchainImagesKHR(dev_, sc_, &in, images_.data());
		nImages_ = (int)in;
		for (uint32_t i = 0; i < in; i++) {
			VkSemaphore sm;
			VkSemaphoreCreateInfo smi = { VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO };
			if (f_.vkCreateSemaphore(dev_, &smi, nullptr, &sm) != VK_SUCCESS) return fail("cannot create semaphores");
			renderDone_.push_back(sm);
		}
		return true;
	}

	uint32_t memType(uint32_t bits, VkMemoryPropertyFlags want)
	{
		for (uint32_t i = 0; i < memProps_.memoryTypeCount; i++)
			if ((bits & (1u << i)) && (memProps_.memoryTypes[i].propertyFlags & want) == want) return i;
		return 0xFFFFFFFFu;
	}

	bool makeStaging(Slot& s, VkDeviceSize need)
	{
		if (s.buf) {
			// (the slot is free, so the GPU is done with it; the queue is not touched from this thread)
			f_.vkUnmapMemory(dev_, s.bufMem);
			f_.vkDestroyBuffer(dev_, s.buf, nullptr);
			f_.vkFreeMemory(dev_, s.bufMem, nullptr);
			s.buf = VK_NULL_HANDLE; s.bufMem = VK_NULL_HANDLE; s.map = nullptr; s.bufSize = 0;
		}
		need = (need + 4095) & ~(VkDeviceSize)4095;
		VkBufferCreateInfo bi = { VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO };
		bi.size = need;
		bi.usage = VK_BUFFER_USAGE_TRANSFER_SRC_BIT;
		bi.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
		if (f_.vkCreateBuffer(dev_, &bi, nullptr, &s.buf) != VK_SUCCESS) return false;
		VkMemoryRequirements mr;
		f_.vkGetBufferMemoryRequirements(dev_, s.buf, &mr);
		uint32_t mt = memType(mr.memoryTypeBits, VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_HOST_COHERENT_BIT);
		if (mt == 0xFFFFFFFFu) { f_.vkDestroyBuffer(dev_, s.buf, nullptr); s.buf = VK_NULL_HANDLE; return false; }
		VkMemoryAllocateInfo ma = { VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO };
		ma.allocationSize = mr.size;
		ma.memoryTypeIndex = mt;
		if (f_.vkAllocateMemory(dev_, &ma, nullptr, &s.bufMem) != VK_SUCCESS) { f_.vkDestroyBuffer(dev_, s.buf, nullptr); s.buf = VK_NULL_HANDLE; return false; }
		if (f_.vkBindBufferMemory(dev_, s.buf, s.bufMem, 0) != VK_SUCCESS || f_.vkMapMemory(dev_, s.bufMem, 0, VK_WHOLE_SIZE, 0, &s.map) != VK_SUCCESS) {
			f_.vkFreeMemory(dev_, s.bufMem, nullptr); f_.vkDestroyBuffer(dev_, s.buf, nullptr);
			s.buf = VK_NULL_HANDLE; s.bufMem = VK_NULL_HANDLE; return false;
		}
		s.bufSize = need;
		return true;
	}

	bool makeImage(Slot& s)
	{
		if (s.img && s.imgW == s.w && s.imgH == s.h && s.imgFmt == s.fmt) return true;
		if (s.img) {
			f_.vkDestroyImage(dev_, s.img, nullptr);
			f_.vkFreeMemory(dev_, s.imgMem, nullptr);
			s.img = VK_NULL_HANDLE; s.imgMem = VK_NULL_HANDLE;
		}
		VkImageCreateInfo ii = { VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO };
		ii.imageType = VK_IMAGE_TYPE_2D;
		ii.format = s.fmt == RGBA ? VK_FORMAT_R8G8B8A8_UNORM : VK_FORMAT_B8G8R8A8_UNORM;
		ii.extent = { (uint32_t)s.w, (uint32_t)s.h, 1 };
		ii.mipLevels = 1;
		ii.arrayLayers = 1;
		ii.samples = VK_SAMPLE_COUNT_1_BIT;
		ii.tiling = VK_IMAGE_TILING_OPTIMAL;
		ii.usage = VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
		ii.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
		ii.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
		if (f_.vkCreateImage(dev_, &ii, nullptr, &s.img) != VK_SUCCESS) return false;
		VkMemoryRequirements mr;
		f_.vkGetImageMemoryRequirements(dev_, s.img, &mr);
		uint32_t mt = memType(mr.memoryTypeBits, VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT);
		if (mt == 0xFFFFFFFFu) mt = memType(mr.memoryTypeBits, 0);
		VkMemoryAllocateInfo ma = { VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO };
		ma.allocationSize = mr.size;
		ma.memoryTypeIndex = mt;
		if (mt == 0xFFFFFFFFu || f_.vkAllocateMemory(dev_, &ma, nullptr, &s.imgMem) != VK_SUCCESS) { f_.vkDestroyImage(dev_, s.img, nullptr); s.img = VK_NULL_HANDLE; return false; }
		if (f_.vkBindImageMemory(dev_, s.img, s.imgMem, 0) != VK_SUCCESS) { f_.vkFreeMemory(dev_, s.imgMem, nullptr); f_.vkDestroyImage(dev_, s.img, nullptr); s.img = VK_NULL_HANDLE; s.imgMem = VK_NULL_HANDLE; return false; }
		s.imgW = s.w; s.imgH = s.h; s.imgFmt = s.fmt;
		return true;
	}

	void barrier(VkCommandBuffer cb, VkImage img, VkImageLayout from, VkImageLayout to, VkAccessFlags srcA, VkAccessFlags dstA,
		VkPipelineStageFlags srcS, VkPipelineStageFlags dstS)
	{
		VkImageMemoryBarrier b = { VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER };
		b.srcAccessMask = srcA; b.dstAccessMask = dstA;
		b.oldLayout = from; b.newLayout = to;
		b.srcQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED; b.dstQueueFamilyIndex = VK_QUEUE_FAMILY_IGNORED;
		b.image = img;
		b.subresourceRange = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1 };
		f_.vkCmdPipelineBarrier(cb, srcS, dstS, 0, 0, nullptr, 0, nullptr, 1, &b);
	}

	// returns false when the swapchain is gone for good
	bool showSlot(int si)
	{
		Slot& s = slot_[si];
		if (!makeImage(s)) return false;
		uint32_t idx = 0;
		VkResult r = f_.vkAcquireNextImageKHR(dev_, sc_, 200000000ull, s.acquire, VK_NULL_HANDLE, &idx);
		if (r == VK_ERROR_OUT_OF_DATE_KHR) { return recreate(); }
		if (r == VK_TIMEOUT || r == VK_NOT_READY) return true;
		if (r != VK_SUCCESS && r != VK_SUBOPTIMAL_KHR) return false;

		VkCommandBuffer cb = s.cmd;
		f_.vkResetCommandBuffer(cb, 0);
		VkCommandBufferBeginInfo bi = { VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO };
		bi.flags = VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;
		f_.vkBeginCommandBuffer(cb, &bi);
		// upload the picture
		barrier(cb, s.img, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 0, VK_ACCESS_TRANSFER_WRITE_BIT,
			VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
		VkBufferImageCopy bc = {};
		bc.imageSubresource = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 };
		bc.imageExtent = { (uint32_t)s.w, (uint32_t)s.h, 1 };
		f_.vkCmdCopyBufferToImage(cb, s.buf, s.img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &bc);
		barrier(cb, s.img, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, VK_ACCESS_TRANSFER_WRITE_BIT,
			VK_ACCESS_TRANSFER_READ_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
		// the screen image: clear (black bars), then scale the picture into the right rectangle
		VkImage dst = images_[idx];
		barrier(cb, dst, VK_IMAGE_LAYOUT_UNDEFINED, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 0, VK_ACCESS_TRANSFER_WRITE_BIT,
			VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_TRANSFER_BIT);
		int dx, dy, dw, dh;
		fit(s, dx, dy, dw, dh);
		if (dw < (int)ext_.width || dh < (int)ext_.height) {
			VkClearColorValue black = {};
			VkImageSubresourceRange rg = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 1, 0, 1 };
			f_.vkCmdClearColorImage(cb, dst, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, &black, 1, &rg);
		}
		VkImageBlit bl = {};
		bl.srcSubresource = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 };
		bl.srcOffsets[1] = { s.w, s.h, 1 };
		bl.dstSubresource = { VK_IMAGE_ASPECT_COLOR_BIT, 0, 0, 1 };
		bl.dstOffsets[0] = { dx, dy, 0 };
		bl.dstOffsets[1] = { dx + dw, dy + dh, 1 };
		VkFilter flt = (s.linear && linearBlit_[s.fmt == RGBA ? 1 : 0]) ? VK_FILTER_LINEAR : VK_FILTER_NEAREST;
		f_.vkCmdBlitImage(cb, s.img, VK_IMAGE_LAYOUT_TRANSFER_SRC_OPTIMAL, dst, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, 1, &bl, flt);
		barrier(cb, dst, VK_IMAGE_LAYOUT_TRANSFER_DST_OPTIMAL, VK_IMAGE_LAYOUT_PRESENT_SRC_KHR, VK_ACCESS_TRANSFER_WRITE_BIT, 0,
			VK_PIPELINE_STAGE_TRANSFER_BIT, VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT);
		f_.vkEndCommandBuffer(cb);

		VkPipelineStageFlags ws = VK_PIPELINE_STAGE_TRANSFER_BIT;
		VkSubmitInfo sub = { VK_STRUCTURE_TYPE_SUBMIT_INFO };
		sub.waitSemaphoreCount = 1; sub.pWaitSemaphores = &s.acquire; sub.pWaitDstStageMask = &ws;
		sub.commandBufferCount = 1; sub.pCommandBuffers = &cb;
		sub.signalSemaphoreCount = 1; sub.pSignalSemaphores = &renderDone_[idx];
		f_.vkResetFences(dev_, 1, &s.fence);
		if (f_.vkQueueSubmit(queue_, 1, &sub, s.fence) != VK_SUCCESS) return false;
		s.fenceUsed = true;
		{ std::lock_guard<std::mutex> lk(m_); s.state = 3; }
		VkPresentInfoKHR pi = { VK_STRUCTURE_TYPE_PRESENT_INFO_KHR };
		pi.waitSemaphoreCount = 1; pi.pWaitSemaphores = &renderDone_[idx];
		pi.swapchainCount = 1; pi.pSwapchains = &sc_; pi.pImageIndices = &idx;
		r = f_.vkQueuePresentKHR(queue_, &pi);
		if (r == VK_ERROR_OUT_OF_DATE_KHR) return recreate();
		if (r == VK_SUBOPTIMAL_KHR) {
			// Android reports this when the screen was turned; rebuild only if the size really changed
			VkSurfaceCapabilitiesKHR caps;
			if (f_.vkGetPhysicalDeviceSurfaceCapabilitiesKHR(phys_, surf_, &caps) == VK_SUCCESS &&
			    caps.currentExtent.width != 0xFFFFFFFFu && (caps.currentExtent.width != ext_.width || caps.currentExtent.height != ext_.height))
				return recreate();
			return true;
		}
		return r == VK_SUCCESS;
	}

	bool recreate()
	{
		f_.vkDeviceWaitIdle(dev_);
		for (int i = 0; i < SLOTS; i++) if (slot_[i].state == 3) { std::lock_guard<std::mutex> lk(m_); slot_[i].state = 0; }
		return createSwapchain();
	}

	void fit(const Slot& s, int& x, int& y, int& w, int& h)
	{
		int ew = (int)ext_.width, eh = (int)ext_.height;
		double lw = s.lw > 0 ? s.lw : ew, lh = s.lh > 0 ? s.lh : eh;
		double sc = (double)ew / lw;
		if ((double)eh / lh < sc) sc = (double)eh / lh;
		if (s.integer && sc >= 1.0) sc = (double)(int)sc;
		w = (int)(lw * sc + 0.5); h = (int)(lh * sc + 0.5);
		if (w > ew) w = ew;
		if (h > eh) h = eh;
		if (w < 1) w = 1;
		if (h < 1) h = 1;
		x = (ew - w) / 2; y = (eh - h) / 2;
	}

	void reclaim()
	{
		for (int i = 0; i < SLOTS; i++) {
			Slot& s = slot_[i];
			bool inflight;
			{ std::lock_guard<std::mutex> lk(m_); inflight = s.state == 3; }
			if (inflight && f_.vkGetFenceStatus(dev_, s.fence) == VK_SUCCESS) { std::lock_guard<std::mutex> lk(m_); s.state = 0; }
		}
	}

	void loop()
	{
		for (;;) {
			int take = -1;
			{
				std::unique_lock<std::mutex> lk(m_);
				bool busy = false;
				for (int i = 0; i < SLOTS; i++) if (slot_[i].state == 3) busy = true;
				if (!stop_ && pending_ < 0) {
					if (busy) cv_.wait_for(lk, std::chrono::milliseconds(3)); else cv_.wait(lk);
				}
				if (stop_) break;
				if (pending_ >= 0 && slot_[pending_].state == 2) { take = pending_; pending_ = -1; }
			}
			reclaim();
			if (take < 0) continue;
			Slot& s = slot_[take];
			if (s.fenceUsed) f_.vkWaitForFences(dev_, 1, &s.fence, VK_TRUE, 1000000000ull);
			bool ok = showSlot(take);
			{
				std::lock_guard<std::mutex> lk(m_);
				if (s.state == 2) s.state = 0;		// not shown (screen busy or rebuilt): free it again
			}
			if (!ok) {
				printf("[vulkan] presenting failed, the screen is no longer drawn by Vulkan\n");
				ready_ = false;
				break;
			}
		}
	}

	void teardown()
	{
		if (dev_) {
			f_.vkDeviceWaitIdle(dev_);
			for (int i = 0; i < SLOTS; i++) {
				Slot& s = slot_[i];
				if (s.fence) f_.vkDestroyFence(dev_, s.fence, nullptr);
				if (s.acquire) f_.vkDestroySemaphore(dev_, s.acquire, nullptr);
				if (s.img) { f_.vkDestroyImage(dev_, s.img, nullptr); f_.vkFreeMemory(dev_, s.imgMem, nullptr); }
				if (s.buf) { f_.vkUnmapMemory(dev_, s.bufMem); f_.vkDestroyBuffer(dev_, s.buf, nullptr); f_.vkFreeMemory(dev_, s.bufMem, nullptr); }
				s = Slot();
			}
			for (size_t i = 0; i < renderDone_.size(); i++) f_.vkDestroySemaphore(dev_, renderDone_[i], nullptr);
			renderDone_.clear();
			if (sc_) f_.vkDestroySwapchainKHR(dev_, sc_, nullptr);
			if (pool_) f_.vkDestroyCommandPool(dev_, pool_, nullptr);
			f_.vkDestroyDevice(dev_, nullptr);
		}
		sc_ = VK_NULL_HANDLE; pool_ = VK_NULL_HANDLE; dev_ = VK_NULL_HANDLE; images_.clear(); nImages_ = 0;
		if (inst_) {
			if (surf_) f_.vkDestroySurfaceKHR(inst_, surf_, nullptr);
			f_.vkDestroyInstance(inst_, nullptr);
		}
		surf_ = VK_NULL_HANDLE; inst_ = VK_NULL_HANDLE; phys_ = VK_NULL_HANDLE;
		cur_ = -1; pending_ = -1;
	}
};

}	// namespace vkp
