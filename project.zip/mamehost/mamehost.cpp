#include "mamehost.h"
#include "libretro.h"
#include <dlfcn.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <map>
#include <mutex>
#include <atomic>
#ifdef __ANDROID__
#include <android/log.h>
#define HLOG(...) __android_log_print(ANDROID_LOG_INFO, "mamehost", __VA_ARGS__)
#else
#define HLOG(...) do { fprintf(stderr, "[mamehost] "); fprintf(stderr, __VA_ARGS__); fprintf(stderr, "\n"); } while (0)
#endif

namespace mh {

static void* g_lib = nullptr;
static std::string g_sys, g_save, g_corePath;
static retro_pixel_format g_fmt = RETRO_PIXEL_FORMAT_0RGB1555;
static std::vector<uint32_t> g_frame;        // RGBA bytes, unrotated
static int g_w = 0, g_h = 0;
static int g_rot = 0;
static double g_fps = 60.0, g_rate = 44100.0, g_aspect = 0.0;
static std::vector<int16_t> g_audio;
static std::mutex g_audioLock;
static long long g_cbBatch = 0, g_cbSample = 0, g_cbFrames = 0;
static std::atomic<uint8_t> g_btn[2][16];
static std::map<std::string, std::string> g_opts;
static bool g_optsDirty = false;
static bool g_shutdown = false;
static bool g_gameLoaded = false;
static std::string g_log;
static std::mutex g_logLock;

static void (*p_set_env)(retro_environment_t);
static void (*p_set_video)(retro_video_refresh_t);
static void (*p_set_audio)(retro_audio_sample_t);
static void (*p_set_audio_batch)(retro_audio_sample_batch_t);
static void (*p_set_input_poll)(retro_input_poll_t);
static void (*p_set_input_state)(retro_input_state_t);
static void (*p_init)(void);
static void (*p_deinit)(void);
static bool (*p_load_game)(const struct retro_game_info*);
static void (*p_unload_game)(void);
static void (*p_run)(void);
static void (*p_reset)(void);
static void (*p_get_av)(struct retro_system_av_info*);
static size_t (*p_ser_size)(void);
static bool (*p_ser)(void*, size_t);
static bool (*p_unser)(const void*, size_t);

static void addLog(const char* s) {
    std::lock_guard<std::mutex> l(g_logLock);
    g_log += s;
    if (g_log.size() > 8000) g_log.erase(0, g_log.size() - 6000);
}

static void RETRO_CALLCONV logCb(enum retro_log_level level, const char* fmt, ...) {
    char buf[1024];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    HLOG("core: %s", buf);
    addLog(buf);
}

static bool RETRO_CALLCONV envCb(unsigned cmd, void* data) {
    switch (cmd & 0xFFFF) {
    case RETRO_ENVIRONMENT_SET_ROTATION: g_rot = (int)(*(const unsigned*)data) & 3; return true;
    case RETRO_ENVIRONMENT_GET_OVERSCAN: *(bool*)data = false; return true;
    case RETRO_ENVIRONMENT_GET_CAN_DUPE: *(bool*)data = true; return true;
    case RETRO_ENVIRONMENT_SET_MESSAGE: {
        const retro_message* m = (const retro_message*)data;
        if (m && m->msg) { HLOG("message: %s", m->msg); addLog(m->msg); addLog("\n"); }
        return true;
    }
    case RETRO_ENVIRONMENT_SHUTDOWN: g_shutdown = true; return true;
    case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL: return true;
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY: *(const char**)data = g_sys.c_str(); return true;
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: *(const char**)data = g_save.c_str(); return true;
    case RETRO_ENVIRONMENT_GET_CORE_ASSETS_DIRECTORY: *(const char**)data = g_sys.c_str(); return true;
    case RETRO_ENVIRONMENT_GET_LIBRETRO_PATH: *(const char**)data = g_corePath.c_str(); return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
        g_fmt = *(const retro_pixel_format*)data;
        return g_fmt == RETRO_PIXEL_FORMAT_0RGB1555 || g_fmt == RETRO_PIXEL_FORMAT_XRGB8888 || g_fmt == RETRO_PIXEL_FORMAT_RGB565;
    }
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_KEYBOARD_CALLBACK:
    case RETRO_ENVIRONMENT_SET_DISK_CONTROL_INTERFACE:
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
    case RETRO_ENVIRONMENT_SET_VARIABLES:
    case RETRO_ENVIRONMENT_SET_SERIALIZATION_QUIRKS:
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_MEMORY_MAPS:
    case RETRO_ENVIRONMENT_SET_SUBSYSTEM_INFO:
        return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
        retro_variable* v = (retro_variable*)data;
        auto it = g_opts.find(v->key ? v->key : "");
        if (it == g_opts.end()) { v->value = nullptr; return false; }
        v->value = it->second.c_str();
        return true;
    }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
        *(bool*)data = g_optsDirty;
        g_optsDirty = false;
        return true;
    case RETRO_ENVIRONMENT_GET_LOG_INTERFACE:
        ((retro_log_callback*)data)->log = logCb;
        return true;
    case RETRO_ENVIRONMENT_GET_INPUT_BITMASKS: return true;
    case 47: *(int*)data = 3; return true;       // GET_AUDIO_VIDEO_ENABLE: video + audio on
    case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION: *(unsigned*)data = 0; return true;
    case RETRO_ENVIRONMENT_GET_LANGUAGE: *(unsigned*)data = RETRO_LANGUAGE_ENGLISH; return true;
    case RETRO_ENVIRONMENT_SET_GEOMETRY: {
        const retro_game_geometry* g = (const retro_game_geometry*)data;
        g_aspect = g->aspect_ratio;
        return true;
    }
    case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO: {
        const retro_system_av_info* a = (const retro_system_av_info*)data;
        g_fps = a->timing.fps; g_rate = a->timing.sample_rate; g_aspect = a->geometry.aspect_ratio;
        return true;
    }
    default:
        return false;
    }
}

static void RETRO_CALLCONV videoCb(const void* data, unsigned w, unsigned h, size_t pitch) {
    if (!data) return;                          // duplicate frame: keep the old picture
    if ((int)w != g_w || (int)h != g_h || g_frame.size() != (size_t)w * h) {
        g_w = (int)w; g_h = (int)h;
        g_frame.assign((size_t)w * h, 0xff000000u);
    }
    uint32_t* out = g_frame.data();
    for (unsigned y = 0; y < h; y++) {
        const uint8_t* row = (const uint8_t*)data + y * pitch;
        uint32_t* o = out + (size_t)y * w;
        if (g_fmt == RETRO_PIXEL_FORMAT_RGB565) {
            const uint16_t* s = (const uint16_t*)row;
            for (unsigned x = 0; x < w; x++) {
                uint16_t p = s[x];
                uint32_t r = (p >> 11) & 31, g = (p >> 5) & 63, b = p & 31;
                r = (r << 3) | (r >> 2); g = (g << 2) | (g >> 4); b = (b << 3) | (b >> 2);
                o[x] = 0xff000000u | (b << 16) | (g << 8) | r;      // bytes R,G,B,A in memory (little endian)
            }
        } else if (g_fmt == RETRO_PIXEL_FORMAT_0RGB1555) {
            const uint16_t* s = (const uint16_t*)row;
            for (unsigned x = 0; x < w; x++) {
                uint16_t p = s[x];
                uint32_t r = (p >> 10) & 31, g = (p >> 5) & 31, b = p & 31;
                r = (r << 3) | (r >> 2); g = (g << 3) | (g >> 2); b = (b << 3) | (b >> 2);
                o[x] = 0xff000000u | (b << 16) | (g << 8) | r;
            }
        } else {
            const uint32_t* s = (const uint32_t*)row;
            for (unsigned x = 0; x < w; x++) {
                uint32_t p = s[x];
                o[x] = 0xff000000u | ((p & 0xff) << 16) | (p & 0xff00) | ((p >> 16) & 0xff);
            }
        }
    }
}

static void RETRO_CALLCONV audioCb(int16_t l, int16_t r) {
    std::lock_guard<std::mutex> lk(g_audioLock);
    g_cbSample++;
    g_audio.push_back(l); g_audio.push_back(r);
}

static size_t RETRO_CALLCONV audioBatchCb(const int16_t* data, size_t frames) {
    std::lock_guard<std::mutex> lk(g_audioLock);
    g_cbBatch++; g_cbFrames += (long long)frames;
    if (g_audio.size() > 44100 * 2) g_audio.clear();         // nobody is listening
    g_audio.insert(g_audio.end(), data, data + frames * 2);
    return frames;
}

static void RETRO_CALLCONV pollCb(void) {}

static int16_t RETRO_CALLCONV stateCb(unsigned port, unsigned device, unsigned index, unsigned id) {
    if (port > 1 || (device & 0xff) != RETRO_DEVICE_JOYPAD || index != 0) return 0;
    if (id == RETRO_DEVICE_ID_JOYPAD_MASK) {
        int m = 0;
        for (int i = 0; i < 16; i++) if (g_btn[port][i].load()) m |= 1 << i;
        return (int16_t)m;
    }
    return id < 16 ? g_btn[port][id].load() : 0;
}

#define SYMREQ(var, name) do { *(void**)&var = dlsym(g_lib, name); if (!var) { HLOG("missing %s", name); return false; } } while (0)

bool loadCore(const char* corePath, const char* sysDir, const char* saveDir) {
    unload();
    g_corePath = corePath; g_sys = sysDir; g_save = saveDir;
    g_lib = dlopen(corePath, RTLD_NOW | RTLD_LOCAL);
    if (!g_lib) { HLOG("dlopen: %s", dlerror()); addLog(dlerror()); return false; }
    SYMREQ(p_set_env, "retro_set_environment");
    SYMREQ(p_set_video, "retro_set_video_refresh");
    SYMREQ(p_set_audio, "retro_set_audio_sample");
    SYMREQ(p_set_audio_batch, "retro_set_audio_sample_batch");
    SYMREQ(p_set_input_poll, "retro_set_input_poll");
    SYMREQ(p_set_input_state, "retro_set_input_state");
    SYMREQ(p_init, "retro_init");
    SYMREQ(p_deinit, "retro_deinit");
    SYMREQ(p_load_game, "retro_load_game");
    SYMREQ(p_unload_game, "retro_unload_game");
    SYMREQ(p_run, "retro_run");
    SYMREQ(p_reset, "retro_reset");
    SYMREQ(p_get_av, "retro_get_system_av_info");
    SYMREQ(p_ser_size, "retro_serialize_size");
    SYMREQ(p_ser, "retro_serialize");
    SYMREQ(p_unser, "retro_unserialize");
    for (auto& r : g_btn) for (auto& b : r) b = 0;
    g_shutdown = false; g_rot = 0; g_w = g_h = 0; g_frame.clear(); g_audio.clear();
    p_set_env(envCb);
    p_set_video(videoCb);
    p_set_audio(audioCb);
    p_set_audio_batch(audioBatchCb);
    p_set_input_poll(pollCb);
    p_set_input_state(stateCb);
    p_init();
    return true;
}

bool loadGame(const char* romPath) {
    if (!g_lib) return false;
    retro_game_info gi;
    memset(&gi, 0, sizeof(gi));
    gi.path = romPath;
    if (!p_load_game(&gi)) { HLOG("retro_load_game failed"); return false; }
    g_gameLoaded = true;
    retro_system_av_info av;
    memset(&av, 0, sizeof(av));
    p_get_av(&av);
    g_fps = av.timing.fps > 1 ? av.timing.fps : 60.0;
    g_rate = av.timing.sample_rate > 1000 ? av.timing.sample_rate : 44100.0;
    g_aspect = av.geometry.aspect_ratio;
    if (g_w == 0) { g_w = (int)av.geometry.base_width; g_h = (int)av.geometry.base_height; g_frame.assign((size_t)g_w * g_h, 0xff000000u); }
    return true;
}

void unload() {
    if (g_lib) {
        if (g_gameLoaded && p_unload_game) p_unload_game();
        g_gameLoaded = false;
        if (p_deinit) p_deinit();
        dlclose(g_lib);
        g_lib = nullptr;
    }
}

bool runFrame() {
    if (!g_lib || !g_gameLoaded || g_shutdown) return false;
    p_run();
    return !g_shutdown;
}

void info(int* w, int* h, double* fps, double* rate, int* rot, double* aspect) {
    bool turn = (g_rot & 1) != 0;
    *w = turn ? g_h : g_w;
    *h = turn ? g_w : g_h;
    *fps = g_fps; *rate = g_rate; *rot = g_rot;
    double a = g_aspect;
    if (a <= 0.01 && g_h > 0) a = (double)g_w / g_h;
    // the core's ratio is for the unrotated picture; a turned picture swaps it
    *aspect = turn ? (a > 0.01 ? 1.0 / a : 1.0) : a;
}

int copyFrame(uint32_t* dst, int stride, int maxW, int maxH) {
    if (g_w <= 0 || g_h <= 0 || g_frame.size() < (size_t)g_w * g_h) return 0;
    int W = g_w, H = g_h;
    bool turn = (g_rot & 1) != 0;
    int dw = turn ? H : W, dh = turn ? W : H;
    if (dw > maxW || dh > maxH) return 0;
    const uint32_t* s = g_frame.data();
    switch (g_rot) {
    case 0:
        for (int y = 0; y < H; y++) memcpy(dst + (size_t)y * stride, s + (size_t)y * W, (size_t)W * 4);
        break;
    case 1:      // 90 degrees counter clockwise: (sx, sy) -> (sy, W-1-sx)
        for (int sy = 0; sy < H; sy++)
            for (int sx = 0; sx < W; sx++) dst[(size_t)(W - 1 - sx) * stride + sy] = s[(size_t)sy * W + sx];
        break;
    case 2:
        for (int sy = 0; sy < H; sy++)
            for (int sx = 0; sx < W; sx++) dst[(size_t)(H - 1 - sy) * stride + (W - 1 - sx)] = s[(size_t)sy * W + sx];
        break;
    default:     // 270 counter clockwise: (sx, sy) -> (H-1-sy, sx)
        for (int sy = 0; sy < H; sy++)
            for (int sx = 0; sx < W; sx++) dst[(size_t)sx * stride + (H - 1 - sy)] = s[(size_t)sy * W + sx];
        break;
    }
    return 1;
}

void audioStats(long long* batch, long long* sample, long long* frames) {
    std::lock_guard<std::mutex> lk(g_audioLock);
    *batch = g_cbBatch; *sample = g_cbSample; *frames = g_cbFrames;
}

int takeAudio(int16_t* out, int maxShorts) {
    std::lock_guard<std::mutex> lk(g_audioLock);
    int n = (int)g_audio.size();
    if (n > maxShorts) n = maxShorts & ~1;
    if (n > 0) {
        memcpy(out, g_audio.data(), (size_t)n * 2);
        g_audio.erase(g_audio.begin(), g_audio.begin() + n);
    }
    return n;
}

void setButton(int port, int id, bool down) {
    if (port < 0 || port > 1 || id < 0 || id > 15) return;
    g_btn[port][id] = down ? 1 : 0;
}

void setOption(const char* key, const char* value) {
    g_opts[key] = value;
    g_optsDirty = true;
}

void reset() { if (g_lib && g_gameLoaded) p_reset(); }

bool saveState(const char* path) {
    if (!g_lib || !g_gameLoaded) return false;
    size_t n = p_ser_size();
    if (n == 0) return false;
    std::vector<uint8_t> buf(n);
    if (!p_ser(buf.data(), n)) return false;
    FILE* f = fopen(path, "wb");
    if (!f) return false;
    bool ok = fwrite(buf.data(), 1, n, f) == n;
    fclose(f);
    return ok;
}

bool loadState(const char* path) {
    if (!g_lib || !g_gameLoaded) return false;
    FILE* f = fopen(path, "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long n = ftell(f);
    fseek(f, 0, SEEK_SET);
    std::vector<uint8_t> buf((size_t)(n > 0 ? n : 0));
    bool ok = n > 0 && fread(buf.data(), 1, buf.size(), f) == buf.size();
    fclose(f);
    return ok && p_unser(buf.data(), buf.size());
}

std::string lastLog() {
    std::lock_guard<std::mutex> l(g_logLock);
    return g_log;
}

}  // namespace mh
