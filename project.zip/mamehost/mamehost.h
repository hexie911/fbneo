// Minimal libretro frontend used by the "MAME" section. Plain C++ so it can be tested on a desktop too.
#pragma once
#include <stdint.h>
#include <string>
#include <vector>

namespace mh {
bool loadCore(const char* corePath, const char* sysDir, const char* saveDir);
bool loadGame(const char* romPath);
void unload();
bool runFrame();                       // one emulated frame; false when the core asked to shut down
// geometry of the last frame after rotation, and timing
void info(int* w, int* h, double* fps, double* rate, int* rot, double* aspect);
int  copyFrame(uint32_t* dst, int dstStridePixels, int maxW, int maxH);   // RGBA bytes (R,G,B,A) per pixel, rotation applied
int  takeAudio(int16_t* out, int maxShorts);
unsigned frameHash();
void audioStats(long long* batch, long long* sample, long long* frames);
void setButton(int port, int id, bool down);
void setOption(const char* key, const char* value);
void reset();
bool saveState(const char* path);
bool loadState(const char* path);
std::string lastLog();
}
