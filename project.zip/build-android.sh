#!/usr/bin/env bash
# Builds FBNeo + SDL2 for Android arm64 and packages the APK. Meant for GitHub Actions (ubuntu runner with the
# Android SDK/NDK preinstalled), but works on any Linux box with: git, make, gcc/g++, perl, cmake, ninja, gradle 8.7+, JDK 17.
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="${WORK:-$HERE/build}"
FBNEO_COMMIT=3bff6bb6896a54f901d947931c7dd085f3a08786
SDL_TAG=release-2.30.8
API=26
JOBS="$(nproc)"

# ---- NDK ------------------------------------------------------------------------------
NDK="${ANDROID_NDK_ROOT:-${ANDROID_NDK_HOME:-}}"
if [ -z "$NDK" ] || [ ! -d "$NDK" ]; then
    SDK="${ANDROID_HOME:-${ANDROID_SDK_ROOT:-/usr/local/lib/android/sdk}}"
    NDK="$(ls -d "$SDK"/ndk/*/ 2>/dev/null | sort -V | tail -1 || true)"
    NDK="${NDK%/}"
fi
[ -d "$NDK" ] || { echo "Android NDK not found (set ANDROID_NDK_ROOT)"; exit 1; }
TC="$NDK/toolchains/llvm/prebuilt/linux-x86_64"
CLANG="$TC/bin/aarch64-linux-android${API}-clang"
CLANGXX="$TC/bin/aarch64-linux-android${API}-clang++"
STRIP="$TC/bin/llvm-strip"
echo "NDK: $NDK"

mkdir -p "$WORK"
cd "$WORK"

# ---- SDL2 ----------------------------------------------------------------------------
if [ ! -d SDL ]; then
    git clone --depth 1 --branch "$SDL_TAG" https://github.com/libsdl-org/SDL.git SDL
fi
if [ ! -f sdl-out/libSDL2.so ]; then
    cmake -S SDL -B sdl-build -G Ninja \
        -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
        -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-$API \
        -DCMAKE_BUILD_TYPE=Release -DSDL_SHARED=ON -DSDL_STATIC=OFF -DSDL_TESTS=OFF \
        -DCMAKE_ANDROID_STL_TYPE=c++_static -DCMAKE_SHARED_LINKER_FLAGS="-Wl,-z,max-page-size=16384"
    cmake --build sdl-build -j"$JOBS"
    mkdir -p sdl-out
    cp sdl-build/libSDL2.so sdl-out/
fi

# ---- FBNeo ---------------------------------------------------------------------------
if [ ! -d FBNeo ]; then
    mkdir FBNeo
    git -C FBNeo init -q
    git -C FBNeo remote add origin https://github.com/finalburnneo/FBNeo.git
    git -C FBNeo fetch --depth 1 origin "$FBNEO_COMMIT"
    git -C FBNeo checkout -q FETCH_HEAD
    patch -d FBNeo -p1 < "$HERE/patches/fbneo-android.patch"
fi

cd FBNeo
MAKEARGS=(RELEASEBUILD=1 INCLUDE_LUA_SUPPORT=1 FASTCALL= PLATFLAGS=
    "CC=$CLANG" "LD=$CLANGXX" HOST_CC=gcc HOST_CXX=g++
    "SDL_CFLAGS=-I$WORK/SDL/include" "SDL_LIBS=-L$WORK/sdl-out -lSDL2")
make -s -f makefile.android init RELEASEBUILD=1
make -j"$JOBS" android "${MAKEARGS[@]}"
cd "$WORK"

# ---- libretro host for the MAME section ----------------------------------------------
mkdir -p mame-out
"$CLANGXX" -std=c++17 -O2 -fPIC -shared -static-libstdc++ -Wl,-z,max-page-size=16384 \
    -I"$HERE/mamehost" -o mame-out/libmamehost.so \
    "$HERE/mamehost/mamehost.cpp" "$HERE/mamehost/mamejni.cpp" -llog -landroid -ldl

# ---- Flycast Dojo (optional: if it fails to build, the app is built without it) --------
if bash "$HERE/build-flycast.sh" "$NDK" "$WORK" "$HERE"; then
    echo "Flycast Dojo included"
else
    echo "WARNING: Flycast Dojo could not be built - continuing without it"
    rm -rf "$HERE/flycast"
fi

# ---- package -------------------------------------------------------------------------
APP="$HERE/app/src/main"
mkdir -p "$APP/jniLibs/arm64-v8a" "$APP/java/org/libsdl/app"
cp FBNeo/libmain.so sdl-out/libSDL2.so mame-out/libmamehost.so "$APP/jniLibs/arm64-v8a/"
"$STRIP" --strip-unneeded "$APP/jniLibs/arm64-v8a/"*.so
cp SDL/android-project/app/src/main/java/org/libsdl/app/*.java "$APP/java/org/libsdl/app/"
ls -la "$APP/jniLibs/arm64-v8a/"

cd "$HERE"
if ! gradle --no-daemon assembleDebug; then
    if [ -d "$HERE/flycast" ]; then
        echo "WARNING: the build with Flycast Dojo failed - retrying without it"
        rm -rf "$HERE/flycast"
        gradle --no-daemon assembleDebug
    else
        exit 1
    fi
fi
mkdir -p "$HERE/out"
cp app/build/outputs/apk/debug/app-debug.apk "$HERE/out/FBNeo.apk"
echo "APK: $HERE/out/FBNeo.apk"
