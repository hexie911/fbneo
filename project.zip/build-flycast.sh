#!/usr/bin/env bash
# Builds Flycast Dojo's native library with the same NDK and prepares the Java side as a gradle
# library module (flycast/). Any failure leaves no module behind, so the app still builds without Flycast.
# usage: build-flycast.sh <NDK dir> <work dir> <project dir>
set -euo pipefail
NDK="$1"; WORK="$2"; HERE="$3"
JOBS="$(nproc 2>/dev/null || echo 4)"
OUT="$HERE/flycast"
rm -rf "$OUT"

cd "$WORK"
if [ ! -d flycast-src ]; then
    git clone --depth 1 --recurse-submodules --shallow-submodules -j8 \
        https://github.com/blueminder/flycast-dojo.git flycast-src
fi
cd flycast-src

cmake -S . -B "$WORK/flycast-build" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26 -DANDROID_STL=c++_static \
    -DANDROID_ARM_MODE=arm -DCMAKE_BUILD_TYPE=Release -DUSE_BREAKPAD=OFF
cmake --build "$WORK/flycast-build" -j"$JOBS" --target flycast
SO="$(find "$WORK/flycast-build" -name libflycast.so | head -1)"
[ -f "$SO" ] || { echo "libflycast.so was not produced"; exit 1; }

M="$WORK/flycast-src/shell/android-studio/flycast/src/main"
mkdir -p "$OUT/src/main/jniLibs/arm64-v8a" "$OUT/libs"
cp -r "$M/java" "$M/res" "$OUT/src/main/"
cp "$HERE/flycast-template/build.gradle" "$HERE/flycast-template/AndroidManifest.xml" "$OUT/" 
mv "$OUT/AndroidManifest.xml" "$OUT/src/main/AndroidManifest.xml"
cp "$WORK/flycast-src/shell/android-studio/flycast/proguard-rules.pro" "$OUT/" 2>/dev/null || touch "$OUT/proguard-rules.pro"
cp "$WORK/flycast-src/shell/android-studio/flycast/libs/"*.jar "$OUT/libs/" 2>/dev/null || true
cp "$SO" "$OUT/src/main/jniLibs/arm64-v8a/libflycast.so"
"$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip" --strip-unneeded "$OUT/src/main/jniLibs/arm64-v8a/libflycast.so" || true
echo "Flycast Dojo ready: $(ls -la "$OUT/src/main/jniLibs/arm64-v8a/libflycast.so")"
