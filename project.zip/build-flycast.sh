#!/usr/bin/env bash
# Builds Flycast Dojo's native library with the same NDK and prepares the Java side as a gradle
# library module (flycast/). Any failure leaves no module behind, so the app still builds without Flycast.
# usage: build-flycast.sh <NDK dir> <work dir> <project dir>
set -euo pipefail
NDK="$1"; WORK="$2"; HERE="$3"
JOBS="$(nproc 2>/dev/null || echo 4)"
OUT="$HERE/flycast"
rm -rf "$OUT"

cd "$WORK"
if [ ! -d flycast-src ]; then
    git clone --depth 1 --recurse-submodules --shallow-submodules -j8 \
        https://github.com/blueminder/flycast-dojo.git flycast-src
fi
cd flycast-src
# newer NDKs turn these two into errors (-Werror=format-security)
sed -i 's|ImGui::Text(dojo.game_name.c_str());|ImGui::Text("%s", dojo.game_name.c_str());|' core/rend/gui.cpp
sed -i 's|ImGui::TextDisabled(question_txt);|ImGui::TextDisabled("%s", question_txt);|' core/rend/gui_util.cpp

# Android refuses libraries with a writable+executable segment ("W+E load segments are not allowed").
# Flycast keeps its JIT buffers inside .text; put them in plain (anonymous) memory instead,
# they are made executable at run time by virtmem::prepare_jit_block (mprotect) anyway.
for f in core/hw/sh4/dyna/driver.cpp core/hw/arm7/arm7_rec.cpp core/hw/aica/dsp_arm64.cpp core/hw/aica/dsp_arm32.cpp; do
    sed -i 's|__attribute__((section("\.text")))|__attribute__((aligned(4096)))|' "$f"
done
grep -rn 'section("\.text")' core/hw/sh4/dyna/driver.cpp core/hw/arm7/arm7_rec.cpp core/hw/aica/dsp_arm64.cpp && { echo "patch did not apply"; exit 1; }

cmake -S . -B "$WORK/flycast-build" -G Ninja \
    -DCMAKE_TOOLCHAIN_FILE="$NDK/build/cmake/android.toolchain.cmake" \
    -DANDROID_ABI=arm64-v8a -DANDROID_PLATFORM=android-26 -DANDROID_STL=c++_static \
    -DANDROID_ARM_MODE=arm -DCMAKE_BUILD_TYPE=Release -DUSE_BREAKPAD=OFF \
    -DCMAKE_C_FLAGS="-Wno-error -Wno-format-security" -DCMAKE_CXX_FLAGS="-Wno-error -Wno-format-security"
cmake --build "$WORK/flycast-build" -j"$JOBS" --target flycast -- -k 0 || { echo "--- first errors ---"; exit 1; }
SO="$(find "$WORK/flycast-build" -name libflycast.so | head -1)"
[ -f "$SO" ] || { echo "libflycast.so was not produced"; exit 1; }

M="$WORK/flycast-src/shell/android-studio/flycast/src/main"
mkdir -p "$OUT/src/main/jniLibs/arm64-v8a" "$OUT/libs"
cp -r "$M/java" "$M/res" "$OUT/src/main/"
cp "$HERE/flycast-template/build.gradle" "$HERE/flycast-template/AndroidManifest.xml" "$OUT/" 
mv "$OUT/AndroidManifest.xml" "$OUT/src/main/AndroidManifest.xml"
cp "$WORK/flycast-src/shell/android-studio/flycast/proguard-rules.pro" "$OUT/" 2>/dev/null || touch "$OUT/proguard-rules.pro"
cp "$WORK/flycast-src/shell/android-studio/flycast/libs/"*.jar "$OUT/libs/" 2>/dev/null || true
cp "$SO" "$OUT/src/main/jniLibs/arm64-v8a/libflycast.so"
"$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip" --strip-unneeded "$OUT/src/main/jniLibs/arm64-v8a/libflycast.so" || true
if "$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-readelf" -lW "$SO" | grep "LOAD" | grep -q "RWE"; then
    echo "libflycast.so still has a writable+executable segment:"
    "$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-readelf" -lW "$SO" | grep LOAD
    exit 1
fi
echo "Flycast Dojo ready: $(ls -la "$OUT/src/main/jniLibs/arm64-v8a/libflycast.so")"
