# FBNeo for Android (with Lua scripting)

Native Android app: game library, Lua script picker, settings, controller mapping and an in-game pause menu.
It runs the real FBNeo SDL2 frontend with its Lua engine (not the libretro core), so `3rd_training.lua`-style
scripts work.

Build: GitHub Actions compiles it (see the workflow); `build-android.sh` does the work.
FBNeo source is fetched from upstream at a pinned commit and patched with `patches/fbneo-android.patch`.

## Folders on the phone
Default `/storage/emulated/0/fbneo/`: `roms/`, `lua/`, `config/`, `last_run.log`.

## Lua scripts
Big scripts such as 3rd Strike training mode are a *folder* (`3rd_training.lua` plus `src/`, `data/`, `images/`).
Keep the whole folder together, e.g. `fbneo/lua/3rd_training_lua/3rd_training.lua`. In the game sheet the app warns
when files are missing and has a one-tap "Download 3rd Strike training mode" button (needs internet once).
That script is made for `sfiii3nr1` (Japan 990608, no CD) and `sfiii4n`.

## In game
Back (or the "Open pause menu" button you can map) opens the pause menu: resume, save/load state, swap player,
reset, quit, **DIP switches** and **Screen shape** (4:3, 16:9, stretch ...). PS button = swap P1/P2; L1/L2 = Lua hotkeys 1/2 (all rebindable in Controls).

## Performance notes
The emulator loop keeps the CPU busy on purpose (like the desktop build): phones lower their clock speed as soon as a
thread sleeps, which makes heavy games such as 3rd Strike slow. Settings > Performance has "Use the fastest CPU cores"
(on by default) and "Battery saver" (sleep between frames, off by default). The log (Settings > Last game log) gets a
`perf:` line every ~10 seconds with the real fps and how long emulation, drawing and Lua take per frame.

## Controls feel
Settings > Controller: "Arcade input smoothing" queues every quick stick/D-pad change so each step of a half circle
reaches the game on its own frame, and "Stick and D-pad feel" widens the diagonals of the analog stick.

## v1.4 additions
- Pause menu: **Service (test menu)** toggles the arcade test switch (3rd Strike's TEST MENU; navigate with P1 stick and button 1). Also mappable in Controls ("Service / test menu").
- (the quick-start checkbox was removed in this update)
- Pause menu: **Cheats** (switch on/off, Add address/value cheats, Delete your own, Load .ini/.dat files from Download or the cheats folder).
- Both menus scroll in landscape; games start in landscape unless "Rotate with the phone" is on. New launcher icon.
- Service fix: the test switch is the input named "diag" (the Service coin button is "service"); both are bound now. On boards other than CPS3 the game restarts when the switch goes on. Turn it off again from the pause menu.
- On-screen controls: pause menu checkbox + "Edit on-screen controls" (move, resize, add buttons, add macros, delete, reset). Opacity in Settings.
- v1.4+: VSync off by default; Settings > Performance has Frame skip, Faster sound mixing and a "Weak phone preset". Neo Geo games get a "Home console mode (AES)" switch in the game sheet.
- Two controllers: Controller screen has a Player 1 / Player 2 tab; the first pad you touch is player 1, the second is player 2.
- Local multiplayer (pause menu): Wi-Fi or hotspot, host = P1, guest = P2. Lock-step netplay on TCP port 7245 (discovery on UDP 7246): the host's game state is sent to the guest, both restart from it, inputs are exchanged with a small delay. Needs identical ROM sets.
- Fixes: menus no longer freeze the emulator loop during netplay (the cause of the "syncing" hang); menu actions (quit, save, load, reset, swap) are queued commands; touch-layout editing really freezes the game; Neo Geo AES restores the arcade BIOS when switched off; service switch and reset work in netplay; macros per player in Controller; sticks are read as an angle (cleaner straight directions and diagonals), D-pad key and hat count as the same thing.

## v1.5
- Netplay on CPS3: only the small save data (EEPROM) is synced instead of the ~10 MB state; the game resets from the same point on both phones.
- A broken connection no longer lingers: starting a new host/join discards the old one completely.
- Credits: everything credited to Hexie first, FBNeo mentioned afterwards.

## v1.6 - timing, counters, renderer
- Steady frame clock: frames are no longer run in bursts whenever the phone's audio device asks for data. A clock decides when each frame is due and the audio buffer only trims it by a fraction of a percent. Turn off with Settings > Smooth frame timing (classic mode).
- Match the screen's refresh rate: a 59.6 fps arcade game on a 60 Hz screen (or every 2nd refresh of a 120 Hz screen) runs at the screen's rate, so no frame is shown twice.
- Counters (Settings > On-screen counters): FPS, Speed (100% = full speed) and Screen (measured refresh rate of the display).
- Renderer: GPU (OpenGL ES) or Software. Multi-threaded video (experimental): upload, draw and present run on a second thread; it gives the GL context back by itself when the app goes to the background or the window changes shape, and falls back to one thread if the phone refuses the hand-over.
- More options for weak phones: auto frame skip, high thread priority, sustained performance mode, 32 kHz / 22 kHz sound, and the Weak phone preset now includes them.
- The log (Settings > Last game log) shows `pace:` lines (frame interval, skipped frames, audio underruns) every 10 seconds.

## v1.7
- 3rd Strike combo trials (Crystal Cube 99): game sheet > "Download 3rd Strike combo trials". The app downloads the ~140 MB package from Google Drive, unpacks it into `<lua folder>/crystal_cube99_trial/` and puts `sf3_3rd_trial_20220613.lua` (bundled in the app's assets) next to its `resources/` folder.
- Controller defaults: L3 and R3 empty, the PS button opens the pause menu. Saved maps are updated once; buttons you mapped yourself are kept.

## v1.8
- Lua `gd.createFromPng` is lazy: it only reads the picture's size and decodes the pixels the first time the picture is drawn. Scripts that create over a thousand images at start (the 3rd Strike trials) no longer freeze on a black screen while loading.
- `savestate.load` writes a line to the log (`Lua: savestate.load <file> -> ok/failed`).
- Trials download: clearer error messages (shows what Google Drive answered), tolerates non-UTF-8 file names in the zip.

## v1.9
- Touch editor: multi-touch between buttons (Off / 60% / 80% / 100%) presses neighbouring buttons together, e.g. LP+LK.
- Touch editor: Smooth stick on/off (off = knob and direction snap to 8 directions). On by default.

## v1.10
- Netplay: the frame pacer no longer skips frames or rushes to catch up when a frame had to wait for the other phone (this caused the choppiness, mostly on the joining side).

## v1.11
- Save states from another version of the same game (e.g. a no-CD set) now load into the running version instead of being refused. Fixes the Crystal Cube 99 trial on sfiii3r1.

## v1.12
- Lua: savestate.load by name/number also looks for ".fs" files and in savestates/ folders; if a state is missing the log lists the script folder.

## v1.13
- Save state loading: detailed log lines (State: ...) explaining why a state is rejected; states marked older than the driver are now tried instead of refused.

## v1.14
- Save states made by other FBNeo builds (zlib-compressed) can now be loaded. Fixes the Crystal Cube 99 trial states.

## v1.15
- Older untagged save states (as used by the Crystal Cube 99 trial) are loaded area by area.

## v1.16
- Crystal Cube 99 trial states: corrected the 2022 CPS3 state layout (palette offset and CPU block), so the CPU starts from the right place.

## v1.16
- Crystal Cube 99 trial states: layout of the old CPS3 state worked out from the files (extra palette block, shorter SH2 block, fewer driver variables), so the CPU and sprite data now load in the right place.

## v1.17
- Old CPS3 states: SH2 timers/cycle counters are no longer taken from the old state (they hold values from a different build); log is flushed after a state load.

## v1.18
- Log: what the script sees right after a state load, and a count when a script keeps reloading states.

## v1.19
- Removed the Crystal Cube 99 trial download and every change made for it (old-format state loading, state lookup and logging), back to the v1.8 behaviour. Touch editor options (v1.9) and the netplay pacing fix (v1.10) are kept.

## v1.20
- New macro dialog scrolls as a whole in landscape.

## MAME section (v1.21)
The "MAME" button in the header opens a separate section with its own ROM folder (default /storage/emulated/0/Roms/mame/),
its own list, and a core download (libretro buildbot, arm64). It uses a small libretro host (mamehost/ -> libmamehost.so)
that runs the libretro MAME core. FBNeo and its Lua engine are untouched. The ROM set must match the core's MAME version.

MAME local multiplayer (v1.25): lockstep over TCP port 7255, host = player 1; both phones need the same ROM and core.

Signing (v1.26): every build is signed with app/fbneo-key.jks, so updates install over the old app. Keep this file; a different key forces an uninstall.

Online multiplayer (v1.29): no server. STUN (stun.l.google.com / stun.cloudflare.com) finds each phone's public address, codes are swapped by hand, UDP hole punching, reliable stream in src/burner/sdl/rudp.h.

Online rollback (v1.30): per-frame saved states, input prediction, silent re-simulation on a wrong guess (GGPO style). Games with a state over 6 MB (CPS3) use delay-based netplay. Switch in the Online multiplayer menu.

Chat (v1.31): Chat button (touch, mappable) while playing together; messages travel on the netplay connection. Rollback depth is picked from a frame-cost measurement of both phones.

Online multiplayer v1.32 (replaces the code-swap flow): the host taps Host and gets a short room code (like K7M2-QX3); the friend taps Join and types it. No timing, no copy-pasting addresses. Rendezvous goes through a free public MQTT broker (broker.hivemq.com / broker.emqx.io / test.mosquitto.org, src/burner/sdl/mqtt.h), the phones swap public addresses (STUN), try a direct UDP link and, if the networks forbid it (mobile data, strict NAT), relay the game through the same broker (rudp relay mode). Not tested on real networks or real brokers.

v1.33: rollback keeps replays short (max 3 frames, rest covered by input delay; "Input delay" option in the Online menu, 0 = auto), skips snapshots of frames that can never be rolled back to, gentler sync sleep, relay sends from a queue (game thread never waits on the network). The host's room code is now permanent (one per netcode: Rollback / Delay-based); "New code" regenerates it.

v1.34: live adaptive input delay for rollback. Each phone times its real replays; when replay + frame would not fit in ~14.5 ms twice, the local delay grows by one frame (up to +4, max 8) and falls back after ~30 s of cheap replays. A long replay no longer triggers catch-up bursts. Delay can differ between the two phones (frames are numbered).
