# fbn4droid (FBNeo for Android, with Lua scripting)

Native Android app: game library, Lua script picker, settings, controller mapping and an in-game pause menu.
It runs the real FBNeo SDL2 frontend with its Lua engine (not the libretro core), so `3rd_training.lua`-style
scripts work.

Build: GitHub Actions compiles it (see the workflow); `build-android.sh` does the work.
FBNeo source is fetched from upstream at a pinned commit and patched with `patches/fbneo-android.patch`.

## Folders on the phone
Default `/storage/emulated/0/fbneo/`: `roms/`, `lua/`, `config/`, `last_run.log`.

## Lua scripts
Big scripts such as 3rd Strike training mode are a *folder* (`3rd_training.lua` plus `src/`, `data/`, `images/`).
Keep the whole folder together, e.g. `fbneo/lua/3rd_training_lua/3rd_training.lua`. In the game sheet the app warns
when files are missing and has a one-tap "Download 3rd Strike training mode" button (needs internet once).
That script is made for `sfiii3nr1` (Japan 990608, no CD) and `sfiii4n`.

## In game
Back (or the "Open pause menu" button you can map) opens the pause menu: resume, save/load state, swap player,
reset, quit, **DIP switches** and **Screen shape** (4:3, 16:9, stretch ...). PS button = swap P1/P2; L1/L2 = Lua hotkeys 1/2 (all rebindable in Controls).

## Performance notes
The emulator loop keeps the CPU busy on purpose (like the desktop build): phones lower their clock speed as soon as a
thread sleeps, which makes heavy games such as 3rd Strike slow. Settings > Performance has "Use the fastest CPU cores"
(on by default) and "Battery saver" (sleep between frames, off by default). The log (Settings > Last game log) gets a
`perf:` line every ~10 seconds with the real fps and how long emulation, drawing and Lua take per frame.

## Controls feel
Settings > Controller: "Arcade input smoothing" queues every quick stick/D-pad change so each step of a half circle
reaches the game on its own frame, and "Stick and D-pad feel" widens the diagonals of the analog stick.

## v1.4 additions
- Pause menu: **Service (test menu)** toggles the arcade test switch (3rd Strike's TEST MENU; navigate with P1 stick and button 1). Also mappable in Controls ("Service / test menu").
- (the quick-start checkbox was removed in this update)
- Pause menu: **Cheats** (switch on/off, Add address/value cheats, Delete your own, Load .ini/.dat files from Download or the cheats folder).
- Both menus scroll in landscape; games start in landscape unless "Rotate with the phone" is on. New launcher icon.
- Service fix: the test switch is the input named "diag" (the Service coin button is "service"); both are bound now. On boards other than CPS3 the game restarts when the switch goes on. Turn it off again from the pause menu.
- On-screen controls: pause menu checkbox + "Edit on-screen controls" (move, resize, add buttons, add macros, delete, reset). Opacity in Settings.
- v1.4+: VSync off by default; Settings > Performance has Frame skip, Faster sound mixing and a "Weak phone preset". Neo Geo games get a "Home console mode (AES)" switch in the game sheet.
- Two controllers: Controller screen has a Player 1 / Player 2 tab; the first pad you touch is player 1, the second is player 2.
- Local multiplayer (pause menu): Wi-Fi or hotspot, host = P1, guest = P2. Lock-step netplay on TCP port 7245 (discovery on UDP 7246): the host's game state is sent to the guest, both restart from it, inputs are exchanged with a small delay. Needs identical ROM sets.
- Fixes: menus no longer freeze the emulator loop during netplay (the cause of the "syncing" hang); menu actions (quit, save, load, reset, swap) are queued commands; touch-layout editing really freezes the game; Neo Geo AES restores the arcade BIOS when switched off; service switch and reset work in netplay; macros per player in Controller; sticks are read as an angle (cleaner straight directions and diagonals), D-pad key and hat count as the same thing.

## v1.5
- Netplay on CPS3: only the small save data (EEPROM) is synced instead of the ~10 MB state; the game resets from the same point on both phones.
- A broken connection no longer lingers: starting a new host/join discards the old one completely.
- Credits: everything credited to Hexie first, FBNeo mentioned afterwards.

## v1.6 - timing, counters, renderer
- Steady frame clock: frames are no longer run in bursts whenever the phone's audio device asks for data. A clock decides when each frame is due and the audio buffer only trims it by a fraction of a percent. Turn off with Settings > Smooth frame timing (classic mode).
- Match the screen's refresh rate: a 59.6 fps arcade game on a 60 Hz screen (or every 2nd refresh of a 120 Hz screen) runs at the screen's rate, so no frame is shown twice.
- Counters (Settings > On-screen counters): FPS, Speed (100% = full speed) and Screen (measured refresh rate of the display).
- Renderer: GPU (OpenGL ES) or Software. Multi-threaded video (experimental): upload, draw and present run on a second thread; it gives the GL context back by itself when the app goes to the background or the window changes shape, and falls back to one thread if the phone refuses the hand-over.
- More options for weak phones: auto frame skip, high thread priority, sustained performance mode, 32 kHz / 22 kHz sound, and the Weak phone preset now includes them.
- The log (Settings > Last game log) shows `pace:` lines (frame interval, skipped frames, audio underruns) every 10 seconds.

## v1.7
- 3rd Strike combo trials (Crystal Cube 99): game sheet > "Download 3rd Strike combo trials". The app downloads the ~140 MB package from Google Drive, unpacks it into `<lua folder>/crystal_cube99_trial/` and puts `sf3_3rd_trial_20220613.lua` (bundled in the app's assets) next to its `resources/` folder.
- Controller defaults: L3 and R3 empty, the PS button opens the pause menu. Saved maps are updated once; buttons you mapped yourself are kept.

## v1.8
- Lua `gd.createFromPng` is lazy: it only reads the picture's size and decodes the pixels the first time the picture is drawn. Scripts that create over a thousand images at start (the 3rd Strike trials) no longer freeze on a black screen while loading.
- `savestate.load` writes a line to the log (`Lua: savestate.load <file> -> ok/failed`).
- Trials download: clearer error messages (shows what Google Drive answered), tolerates non-UTF-8 file names in the zip.

## v1.9
- Touch editor: multi-touch between buttons (Off / 60% / 80% / 100%) presses neighbouring buttons together, e.g. LP+LK.
- Touch editor: Smooth stick on/off (off = knob and direction snap to 8 directions). On by default.

## v1.10
- Netplay: the frame pacer no longer skips frames or rushes to catch up when a frame had to wait for the other phone (this caused the choppiness, mostly on the joining side).

## v1.11
- Save states from another version of the same game (e.g. a no-CD set) now load into the running version instead of being refused. Fixes the Crystal Cube 99 trial on sfiii3r1.

## v1.12
- Lua: savestate.load by name/number also looks for ".fs" files and in savestates/ folders; if a state is missing the log lists the script folder.

## v1.13
- Save state loading: detailed log lines (State: ...) explaining why a state is rejected; states marked older than the driver are now tried instead of refused.

## v1.14
- Save states made by other FBNeo builds (zlib-compressed) can now be loaded. Fixes the Crystal Cube 99 trial states.

## v1.15
- Older untagged save states (as used by the Crystal Cube 99 trial) are loaded area by area.

## v1.16
- Crystal Cube 99 trial states: corrected the 2022 CPS3 state layout (palette offset and CPU block), so the CPU starts from the right place.

## v1.16
- Crystal Cube 99 trial states: layout of the old CPS3 state worked out from the files (extra palette block, shorter SH2 block, fewer driver variables), so the CPU and sprite data now load in the right place.

## v1.17
- Old CPS3 states: SH2 timers/cycle counters are no longer taken from the old state (they hold values from a different build); log is flushed after a state load.

## v1.18
- Log: what the script sees right after a state load, and a count when a script keeps reloading states.

## v1.19
- Removed the Crystal Cube 99 trial download and every change made for it (old-format state loading, state lookup and logging), back to the v1.8 behaviour. Touch editor options (v1.9) and the netplay pacing fix (v1.10) are kept.

## v1.20
- New macro dialog scrolls as a whole in landscape.

## MAME section (v1.21)
The "MAME" button in the header opens a separate section with its own ROM folder (default /storage/emulated/0/Roms/mame/),
its own list, and a core download (libretro buildbot, arm64). It uses a small libretro host (mamehost/ -> libmamehost.so)
that runs the libretro MAME core. FBNeo and its Lua engine are untouched. The ROM set must match the core's MAME version.

MAME local multiplayer (v1.25): lockstep over TCP port 7255, host = player 1; both phones need the same ROM and core.

Signing (v1.26): every build is signed with app/fbneo-key.jks, so updates install over the old app. Keep this file; a different key forces an uninstall.

Online multiplayer (v1.29): no server. STUN (stun.l.google.com / stun.cloudflare.com) finds each phone's public address, codes are swapped by hand, UDP hole punching, reliable stream in src/burner/sdl/rudp.h.

Online rollback (v1.30): per-frame saved states, input prediction, silent re-simulation on a wrong guess (GGPO style). Games with a state over 6 MB (CPS3) use delay-based netplay. Switch in the Online multiplayer menu.

Chat (v1.31): Chat button (touch, mappable) while playing together; messages travel on the netplay connection. Rollback depth is picked from a frame-cost measurement of both phones.

Online multiplayer v1.32 (replaces the code-swap flow): the host taps Host and gets a short room code (like K7M2-QX3); the friend taps Join and types it. No timing, no copy-pasting addresses. Rendezvous goes through a free public MQTT broker (broker.hivemq.com / broker.emqx.io / test.mosquitto.org, src/burner/sdl/mqtt.h), the phones swap public addresses (STUN), try a direct UDP link and, if the networks forbid it (mobile data, strict NAT), relay the game through the same broker (rudp relay mode). Not tested on real networks or real brokers.

v1.33: rollback keeps replays short (max 3 frames, rest covered by input delay; "Input delay" option in the Online menu, 0 = auto), skips snapshots of frames that can never be rolled back to, gentler sync sleep, relay sends from a queue (game thread never waits on the network). The host's room code is now permanent (one per netcode: Rollback / Delay-based); "New code" regenerates it.

v1.34: live adaptive input delay for rollback. Each phone times its real replays; when replay + frame would not fit in ~14.5 ms twice, the local delay grows by one frame (up to +4, max 8) and falls back after ~30 s of cheap replays. A long replay no longer triggers catch-up bursts. Delay can differ between the two phones (frames are numbered).

v1.35: more slack for network jitter before the game waits (max prediction K+4, at least 6); every 120 frames of online play writes a "[rb-perf]" line to the game log (frame gaps, late frames, waits for the network, replay cost, state size) to find what makes frames late.

v1.36: fixed the adaptive delay: how deep YOUR replays are depends on the FRIEND's input delay, so a phone with slow replays now asks the friend's phone (NM_LD message) to add a frame instead of raising its own. The log says whether the connection is DIRECT or a RELAY.

v1.37: slow links (relay, mobile data): each phone watches the ping and asks the friend for enough input delay (up to 14 frames) so the friend's pads arrive in time instead of the game freezing to wait for them. Two phones on the same Wi-Fi/hotspot connect over their local addresses (probe-based path finding, 6 s). The room code's broker is the one that answers fastest from the host's location.

v1.38: optional Vulkan picture output for FBNeo and MAME (Settings > Renderer > "GPU (Vulkan, beta)", off by default). No shaders: the picture is copied into a mapped buffer, the GPU scales it onto the screen with one blit (nearest/linear, letterboxed, integer scale), a presenter thread waits for the refresh so the emulation never stalls on vsync. Falls back to OpenGL ES by itself when Vulkan is missing or fails. Rotated (vertical) pictures are built in normal memory and copied in order (write-combined memory is slow when written scattered). libmain.so now links -landroid (ANativeWindow_fromSurface). Tested only against a fake Vulkan driver on a desktop.


v1.40: Flycast removed again (menu, section, build step, folder). Online play is rollback only: the "Netcode" and "Input delay" choices are gone and the delay is automatic, now starting at 0 frames when the phones and the connection can afford the replays (before: always at least 1, plus one extra frame of margin). Faster sync: the game state is compressed before it is sent, the speed test uses 10 frames instead of 24 and 4 pings instead of 6. Tested on a desktop with two copies of the game over a simulated 40 ms link: delay 0, no stalls, game checksums equal. Not tested on phones; 3rd Strike's smoothness is not verified.

v1.41: online sync now shows each step ("sending the game", "timing this phone", "waiting for your friend's phone to load the game", "measuring the connection") and gives up with a clear message after 40 s / 60 s instead of waiting for minutes. The two phones must run the same app version: the hello message now carries a protocol number and a mismatch is reported. Desktop test of the whole sync still passes; the hang seen on phones could not be reproduced here.
v1.41: the online screen showed one fixed text for every sync step, so my step messages were hidden; it now shows the real step.
v1.41: every online step (connect, handshake, each sync step) is written to the game log as [net-step <seconds>] ..., with the time.

## v1.42
- New Settings > Language: Auto (follows the phone: Arabic phone = Arabic, anything else = English), English, or Arabic. Changing it restarts the app screens.
- Arabic interface with right-to-left layout. Game and touch-control screens stay left-to-right. Translations live in `app/src/main/assets/lang_ar.tsv` (English text, tab, Arabic text), so they can be corrected without touching code.
- Text shown by the game engine itself (on-screen overlay) stays English.

## v1.43
- Online play: much lower input delay. Rollback is now allowed to replay up to 6 frames (was 3) when the phones can afford it, so at a typical 100 ms ping the delay should be 0-1 frames instead of 4. Slow phones still fall back to more delay automatically.

## v1.44
- Online multiplayer: new "Input delay" choice in the Online menu: Automatic (default), 0 (none), 1-5. The host's choice is used by both phones. A manual choice is kept exactly as set (no automatic raising); with 0 the game relies fully on rollback.

## v1.45
- Fix: online/local multiplayer often stayed on "Syncing the two games (starting)". While a dialog had the window focus, Android paused the game loop (SDL blocks on focus loss), and the sync step runs inside that loop, so a phone with the dialog open never started syncing. The Online and Local multiplayer dialogs now give up the focus as soon as the two phones are connected (they stay visible and their buttons still work).

## v1.46
- Online: the direct connection is now always tried, even when a phone's router looks "strict" (symmetric NAT). Before, it was skipped entirely and the slow relay was used. For a strict friend router the app also probes a small range of nearby ports. The strict-router test now compares two different STUN servers.
- Game log now shows `[net] my public address ...` and `[net] friend's address ...: N direct candidates` so a failed direct connection can be diagnosed.

## v1.47
- New **TAS mode** button in the pause menu. It opens a bar over the game with: pause/resume, frame advance (tap or hold "Step 1 frame"), speed 100/75/50/25/10% (slow motion is silent), 10 save slots with Undo/Redo of the last save or load, re-record counter, movie recording and playback (`.fbm` files in the app's `movies` folder, read-only / read-write toggle, "Take over" to start recording from the current playback frame), auto-fire and auto-hold per button for P1/P2, a live input display, and Memory tools (RAM search, RAM watch shown on the bar, hex viewer/editor).
- Loading a slot while recording cuts the movie at that frame and adds one re-record. Starting or playing a movie clears the slots.
- TAS tools are disabled during local/online multiplayer. Slow motion only works with the smooth frame pacing setting.
- Memory tools depend on the game exposing its CPU memory (the same access the Lua scripts use); open the Memory window while the game is paused, since the game is stopped while it is on screen.

## v1.48
- CPS3 romhacks (SSF3 Infinite 1.08): the program and graphics files that come in the hack's own zip are now always used. Before, a file of the right size but a different checksum was replaced by the original file from the parent zip (`sfiii3.zip`) whenever the parent had it, so the hack's new SIMMs 2-6 could be silently swapped for the originals. That would explain a game that boots and plays but has no INFINITE settings page. The game log now lists every ROM file whose checksum differs from the driver's list: `[rom] <file> from <zip>: CRC ...`.

## v1.49
- **Rewind history** in the TAS bar. "Rewind history: ON" keeps the last minute of the game. "Every N frames" picks how often a state is kept (every frame, 2, 3, 5, 10, or any number from 1 to 600). "Show states" opens a strip of thumbnails (oldest on the left, newest on the right, swipe to scroll); tapping one puts the game back in exactly that frame. If a movie is being recorded, going back cuts it there and counts as a re-record, like loading a slot. Undo still brings you back to where you were.
- Only what changed between two frames is stored (about 10 KB per frame in the games tried), so a minute of every frame is a few dozen MB. The history is capped at 256 MB. Each capture costs a little emulation time (under 1 ms on a PC for a CPS3 game); a bigger "every N" lowers it.
- Going back and then playing on drops the old future, as a new branch starts. While the game is paused you can jump between thumbnails freely.
- The history is cleared when you turn it off, start or play a movie, or change the game. It is off during online and local multiplayer.

## v1.50
- The TAS panel can now be moved, resized and made see-through. Drag the "⠿ TAS" bar at its top to move it anywhere; drag the ◢ corner at the bottom to make the whole panel (buttons and text) bigger or smaller; open "⚙ Window" for Opacity (25–100%) and Size (40–160%) sliders and a Reset. The whole panel fades as one, buttons and words included. Position, size and opacity are remembered. The history strip uses the same opacity and its title can be dragged up and down.

### v1.51
- MAME pause menu: "DIP settings" (opens MAME menu with Tab; pick Dip Switches with the D-pad) and "Service menu" (F2). Keyboard input added to the libretro host. Untested on a phone.
- Dialogs: more compact/wider in landscape.
- TAS Pause button freezes on the current frame (no emulation, no history capture).

### v1.52
- TAS panel: big full-width "Freeze game"/"Resume game" button at the top (stops emulation on the current frame).
- Settings and controller pages: content capped to 640dp and centered in landscape.

### v1.53
- Fix: TAS button crashed (new Freeze button was added before it was created).
- Smaller, denser UI: buttons, rows, headers, MAME pause menu.

### v1.54
- TAS: original Pause button restored; new "Freeze game"/"Resume game" button stops all emulation, video and input processing until resumed (auto-resumes if the panel is closed).
- Launchers (FBNeo, MAME): compact header; in landscape the header hides when you scroll the game list down and returns at the top.

### v1.55
- TAS: Freeze game button now has its own full-width row at the top of the panel (was in the scrolling button row).

### v1.56
- Launchers: search bar hidden behind a magnifier button (header); FBNeo Controls/Settings and MAME Core/ROM folder/Controller/Game log moved into each section's side menu (three dots).
- Smaller game tiles (more per row in landscape), compact MAME rows.
- Keyboard/controller: visible focus ring, D-pad moves between games, A opens, B back, Y toggles search, Start opens the side menu.

### v1.57
- Game sheet (script chooser): in landscape a centered two-pane dialog (game info, Play and "Remember" on the left, scripts list on the right), smaller rows; focus rings; controller A/B work; Play focused at start.

### v1.58
- Settings reorganised into 6 sections (Games and files, Controls, Video and audio, Performance, Appearance and language, Help and about); each opens its own page, back returns to the list.
- Themes: 11 ready-made color themes (dark and light) plus custom background and accent colors (swatches or hex). Whole app recolors; system bars follow.

### v1.59
- Game tiles all the same height (two-line title slot), no uneven rows while scrolling.
- Header button switches the game list between boxes and strips (remembered).
- About shows the real app version.

### v1.60
- Game covers: stored in <FBNeo data folder>/covers/<rom>.jpg. Game sheet has a Game cover section under Lua (thumbnail, Download from the internet, From phone, Remove). Covers show on the boxes and strips.
- Settings > Games and files > Game covers: "Download all game covers" and an automatic missing-covers switch. Source: libretro thumbnail server, FBNeo - Arcade Games (box art, then title screen, then snapshot).

### v1.61
- Game sheet: cover thumbnail moved next to the title; cover buttons (Download / From phone / Remove) in one even row; drag the sheet down by the top bar or title area to close it (follows the finger, springs back or flings away).

### v1.62
- Continue card shows the game cover.
- JoJo games (jojo*): Download JoJo training mode in the script list; looks up the 0.8.0 release of maximusmaxy/JoJoban-Training-Mode-Menu-FBNeo through the GitHub API, downloads the zip, unpacks to <Lua folder>/jojoban_training and selects the script. Untested against the live release.

### v1.63
- Game sheet: dragging by the top bar works when the sheet is tall (parent scroll no longer steals the gesture); the script list scrolls inside its own box in portrait so the sheet stays compact.

### v1.64
- Settings > Help and about > Online connection log: shows the [net] connection lines (direct or relay, STUN, broker) from the start of the last session, not only the end.

### v1.65
- Game sheet: turning the phone while it is open rebuilds it for the new orientation (script choice kept). Landscape sheet is smaller (680dp wide, shorter, smaller cover) with rounder corners.

### v1.66
- Fix: crash when turning the phone with the game sheet open (the rebuilt sheet touched its views before they existed).
- Landscape game sheet: only the script list scrolls (the whole sheet no longer wiggles); draggable down to close in landscape too.
- Landscape: Android status bar hidden on launcher, settings and dialogs (swipe from the top edge to peek).

### v1.67
- Settings > Appearance and language > Screen: "Full screen interface" (on by default): hides the status and navigation bars and draws under the camera cutout on the launcher, settings and menus, in portrait and landscape; content is kept clear of the cutout. Off = normal Android bars. Replaces the landscape-only status bar hiding.

### v1.68
- Full screen interface: no top padding under the camera; windows are allowed under the cutout from the theme (shortEdges), so landscape content reaches the screen edges. With the option off, the sides stay clear of the cutout.
- Landscape game sheet: docked to the bottom (rounded top corners like portrait), narrower, shorter list, smaller cover.

### v1.69
- Renamed to fbn4droid: app name, header, section switcher, dialogs and messages (the FBNeo engine credit and the data folder path Emulators/fbneo stay as they are so your saves are kept). New launcher icon from the supplied picture (adaptive icon, white lettering on blue).

### v1.70
- Emulator switcher in the side menu lists "Final Burn Neo" and "MAME".

### v1.71
- Covers folder gets a .nomedia file so they no longer show up in the Gallery.

### v1.72
- Portuguese (Brazil) added. "Auto" now picks Portuguese, Arabic or English from the phone's language; it can also be chosen under Settings → Appearance and language.
- Game list filters (▾ button in the header): by system (CPS-1, CPS-2, CPS-3, Neo Geo, Sega, Toaplan, Cave, Taito...) and by genre (Fighting, Beat 'em up, Shooter, Run and gun, Platform, Puzzle, Racing, Sports...). They combine with search. The button turns to the accent colour while a filter is on.
- In-app updates: Settings → Help and about → Check for updates (and an automatic check, which can be turned off). It reads the GitHub "latest" release, downloads the APK and hands it to the Android installer. The first time Android asks you to allow installs from fbn4droid. The build workflow now writes the version into the release notes so the app can compare.

### v1.73
- 3rd Strike combo trials (Crystal Cube 99): in the Lua menu of a 3rd Strike game, "Download 3rd Strike combo trials" fetches the script, its pictures and the start states (about 140 MB) into `<lua folder>/sf3_3rd_trial_lua`.
- Lua `savestate.create(n)` with n of 1000 or more now uses a plain numbered file next to the script (this is how the trial pack ships its states). Smaller slot numbers behave as before.

### v1.74
- 3rd Strike trials: the pack's start states were recorded with a 2022 Fightcade core whose CPS3 state layout differs from the current core, so they could not load. They are now converted once into the current layout (automatically after the download, or the first time you press Play for a pack you already downloaded). Trials need the `sfiii3nr1` set (3rd Strike Japan 990512, NO CD).
- The Lua log now says why a `savestate.load` failed (return code, whether the file was found, and the folder it looked in).

### v1.75
- 3rd Strike trial states: the first converter (v1.74) was incomplete. The current core stores states as named blocks rather than a plain compressed stream, and its SH-2 state has one extra array. The converter now writes that format and splices the SH-2 field in. States already converted by v1.74 are converted again automatically the next time you press Play on the trial script.

### v1.76
- Cheat menu rebuilt: the window no longer closes and reopens when you tap a cheat. Active cheats are highlighted with an ON/OFF badge, the title shows how many are on, "All off" switches them all off, and lists of more than 8 cheats get a search box. Multi-option cheats show their current option with a ▾ and open a picker. Rows have a focus ring for keyboard and controller.
