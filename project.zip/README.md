# FBNeo for Android (with Lua scripting)

Native Android app: game library, Lua script picker, settings, controller mapping and an in-game pause menu.
It runs the real FBNeo SDL2 frontend with its Lua engine (not the libretro core), so `3rd_training.lua`-style
scripts work.

Build: GitHub Actions compiles it (see the workflow); `build-android.sh` does the work.
FBNeo source is fetched from upstream at a pinned commit and patched with `patches/fbneo-android.patch`.

## Folders on the phone
Default `/storage/emulated/0/fbneo/`: `roms/`, `lua/`, `config/`, `last_run.log`.

## Lua scripts
Big scripts such as 3rd Strike training mode are a *folder* (`3rd_training.lua` plus `src/`, `data/`, `images/`).
Keep the whole folder together, e.g. `fbneo/lua/3rd_training_lua/3rd_training.lua`. In the game sheet the app warns
when files are missing and has a one-tap "Download 3rd Strike training mode" button (needs internet once).
That script is made for `sfiii3nr1` (Japan 990608, no CD) and `sfiii4n`.

## In game
Back (or the "Open pause menu" button you can map) opens the pause menu: resume, save/load state, swap player,
reset, quit, **DIP switches** and **Screen shape** (4:3, 16:9, stretch ...). PS button = swap P1/P2; L1/L2 = Lua hotkeys 1/2 (all rebindable in Controls).

## Performance notes
The emulator loop keeps the CPU busy on purpose (like the desktop build): phones lower their clock speed as soon as a
thread sleeps, which makes heavy games such as 3rd Strike slow. Settings > Performance has "Use the fastest CPU cores"
(on by default) and "Battery saver" (sleep between frames, off by default). The log (Settings > Last game log) gets a
`perf:` line every ~10 seconds with the real fps and how long emulation, drawing and Lua take per frame.

## Controls feel
Settings > Controller: "Arcade input smoothing" queues every quick stick/D-pad change so each step of a half circle
reaches the game on its own frame, and "Stick and D-pad feel" widens the diagonals of the analog stick.

## v1.4 additions
- Pause menu: **Service (test menu)** toggles the arcade test switch (3rd Strike's TEST MENU; navigate with P1 stick and button 1). Also mappable in Controls ("Service / test menu").
- (the quick-start checkbox was removed in this update)
- Pause menu: **Cheats** (switch on/off, Add address/value cheats, Delete your own, Load .ini/.dat files from Download or the cheats folder).
- Both menus scroll in landscape; games start in landscape unless "Rotate with the phone" is on. New launcher icon.
- Service fix: the test switch is the input named "diag" (the Service coin button is "service"); both are bound now. On boards other than CPS3 the game restarts when the switch goes on. Turn it off again from the pause menu.
- On-screen controls: pause menu checkbox + "Edit on-screen controls" (move, resize, add buttons, add macros, delete, reset). Opacity in Settings.
- v1.4+: VSync off by default; Settings > Performance has Frame skip, Faster sound mixing and a "Weak phone preset". Neo Geo games get a "Home console mode (AES)" switch in the game sheet.
- Two controllers: Controller screen has a Player 1 / Player 2 tab; the first pad you touch is player 1, the second is player 2.
- Local multiplayer (pause menu): Wi-Fi or hotspot, host = P1, guest = P2. Lock-step netplay on TCP port 7245 (discovery on UDP 7246): the host's game state is sent to the guest, both restart from it, inputs are exchanged with a small delay. Needs identical ROM sets.
